// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('Spartan Community India Application Tests', () => {
  test('Homepage loads correctly', async ({ page }) => {
    await page.goto('http://localhost:3000');
    await expect(page).toHaveTitle(/Spartan Community|DirectGrowHub/);
    // Check if the page has loaded properly
    await expect(page.locator('body')).not.toContainText('Error');
  });

  test('Admin login functionality', async ({ page }) => {
    // Navigate to admin login page
    await page.goto('http://localhost:3000/auth/admin-login');
    
    // Fill in login credentials
    await page.fill('input[type="email"]', 'Dishantasclepius@gmail.com');
    await page.fill('input[type="password"]', 'Dishu@1997');
    
    // Click login button
    await page.click('button[type="submit"]');
    
    // Wait for navigation to complete
    await page.waitForURL('**/admin/dashboard');
    
    // Verify we're on the admin dashboard
    await expect(page.url()).toContain('/admin/dashboard');
  });

  test('Navigation within admin panel', async ({ page }) => {
    // Login first
    await page.goto('http://localhost:3000/auth/admin-login');
    await page.fill('input[type="email"]', 'Dishantasclepius@gmail.com');
    await page.fill('input[type="password"]', 'Dishu@1997');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/admin/dashboard');
    
    // Test navigation to different admin sections
    const sections = [
      { name: 'Users', url: '/admin/users' },
      { name: 'Content', url: '/admin/content' },
      { name: 'Referrals', url: '/admin/referrals' },
      { name: 'Videos', url: '/admin/videos' },
      { name: 'Testimonials', url: '/admin/testimonials' },
      { name: 'Security', url: '/admin/security' },
      { name: 'Help', url: '/admin/help' }
    ];
    
    for (const section of sections) {
      // Navigate to section
      await page.goto(`http://localhost:3000${section.url}`);
      
      // Verify page loaded without errors
      await expect(page.locator('body')).not.toContainText('Error');
      await expect(page.url()).toContain(section.url);
    }
  });

  test('User registration flow', async ({ page }) => {
    // Navigate to registration page
    await page.goto('http://localhost:3000/auth/register');
    
    // Check if registration form is present
    await expect(page.locator('form')).toBeVisible();
    
    // Fill in registration details with a unique email
    const uniqueEmail = `test_user_${Date.now()}@example.com`;
    await page.fill('input[name="name"]', 'Test User');
    await page.fill('input[name="email"]', uniqueEmail);
    await page.fill('input[name="password"]', 'TestPassword123!');
    await page.fill('input[name="confirmPassword"]', 'TestPassword123!');
    
    // Submit form (but don't actually submit to avoid creating test users)
    // Instead, just verify the form is valid
    const submitButton = page.locator('button[type="submit"]');
    await expect(submitButton).toBeEnabled();
  });

  test('API endpoints respond correctly', async ({ request }) => {
    // Test session endpoint
    const sessionResponse = await request.get('http://localhost:3000/api/auth/session');
    expect(sessionResponse.status()).toBe(200);
    
    // Test login endpoint with invalid credentials (should return 401)
    const loginResponse = await request.post('http://localhost:3000/api/auth/login', {
      data: {
        email: 'invalid@example.com',
        password: 'wrongpassword'
      }
    });
    expect(loginResponse.status()).toBe(401);
  });
});
