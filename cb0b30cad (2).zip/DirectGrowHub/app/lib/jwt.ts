import { SignJWT, jwtVerify } from "jose";

// Secret key for JWT
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "spartan_community_india_secret_key_change_in_production"
);

// JWT token expiration (in seconds)
const TOKEN_EXPIRATION = 60 * 60 * 24 * 7; // 7 days

/**
 * Generate a JWT token
 * @param payload - Data to include in the token
 * @returns JWT token string
 */
export async function generateToken(payload: any): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + TOKEN_EXPIRATION)
    .sign(JWT_SECRET);
}

/**
 * Verify a JWT token
 * @param token - JWT token to verify
 * @returns Decoded payload or null if invalid
 */
export async function verifyToken(token: string): Promise<any | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload;
  } catch (error) {
    console.error("JWT verification error:", error);
    return null;
  }
}