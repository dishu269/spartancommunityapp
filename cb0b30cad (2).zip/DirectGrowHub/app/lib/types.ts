// Define user roles
export enum UserRole {
  DISTRIBUTOR = "DISTRIBUTOR",
  LEADER = "LEADER",
  ADMIN = "ADMIN"
}

// User interface
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  onboardingComplete?: boolean;
  phone?: string | null;
  profileImage?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  pincode?: string | null;
  company?: string | null;
  referralCode?: string | null;
  preferredLanguage?: string;
  createdAt?: Date;
  updatedAt?: Date;
  leaderId?: string | null;
}

// Registration data interface
export interface RegisterData {
  name: string;
  email: string;
  phone?: string;
  password: string;
  referralCode?: string;
}

// Content type enum
export enum ContentType {
  DOCUMENT = "DOCUMENT",
  VIDEO = "VIDEO",
  IMAGE = "IMAGE",
  LINK = "LINK",
  SPREADSHEET = "SPREADSHEET",
  PRESENTATION = "PRESENTATION"
}

// Referral type
export interface Referral {
  id: string;
  code: string;
  clicks: number;
  conversions: number;
  referrerId: string;
  referredUserId?: string | null;
  createdAt: Date;
  updatedAt: Date;
  referrer?: User;
  referredUser?: User | null;
}