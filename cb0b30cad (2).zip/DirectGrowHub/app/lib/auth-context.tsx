"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/use-toast";
import { UserRole } from "@/lib/types";

// User interface
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  onboardingComplete?: boolean;
}

// Registration data interface
export interface RegisterData {
  name: string;
  email: string;
  phone?: string;
  password: string;
  referralCode?: string;
}

// Auth context interface
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<boolean>;
  logout: () => Promise<void>;
  checkSession: () => Promise<void>;
  register: (data: RegisterData) => Promise<boolean>;
  completeOnboarding: () => Promise<void>;
}

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const router = useRouter();
  const { toast } = useToast();

  // Debug logging
  console.log("AuthProvider initializing");

  // Check for existing session on mount
  useEffect(() => {
    checkSession();
  }, []);

  // Check session
  const checkSession = async () => {
    console.log("Checking session");
    setIsLoading(true);
    
    try {
      const response = await fetch("/api/auth/session", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      const data = await response.json();
      
      if (response.ok && data.authenticated) {
        console.log("Session valid, user:", data.user);
        setUser(data.user);
      } else {
        console.log("No valid session");
        setUser(null);
      }
    } catch (error) {
      console.error("Failed to check session:", error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Login function
  const login = async (email: string, password: string, rememberMe: boolean = false): Promise<boolean> => {
    console.log("Login attempt:", { email, rememberMe });
    setIsLoading(true);
    
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password, rememberMe }),
      });
      
      const data = await response.json();
      
      if (!response.ok || !data.success) {
        console.log("Login failed:", data);
        
        toast({
          title: "Login failed",
          description: data.message || "Invalid email or password. Please try again.",
          variant: "destructive",
        });
        
        setIsLoading(false);
        return false;
      }
      
      // Login successful
      console.log("Login successful:", data);
      
      setUser(data.user);
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.user.name}!`,
        variant: "success",
      });
      
      // Redirect based on user role
      if (data.redirectTo) {
        console.log("Redirecting to:", data.redirectTo);
        router.push(data.redirectTo);
      } else {
        // Fallback redirect
        const dashboardPath = data.user.role === UserRole.ADMIN ? "/admin/dashboard" : "/dashboard";
        console.log("Fallback redirecting to:", dashboardPath);
        router.push(dashboardPath);
      }
      
      setIsLoading(false);
      return true;
    } catch (error) {
      console.error("Login error:", error);
      
      toast({
        title: "Login error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      
      setIsLoading(false);
      return false;
    }
  };

  // Register function
  const register = async (data: RegisterData): Promise<boolean> => {
    console.log("Register attempt:", { email: data.email });
    setIsLoading(true);
    
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        console.log("Registration failed:", result);
        
        toast({
          title: "Registration failed",
          description: result.message || "Failed to create account. Please try again.",
          variant: "destructive",
        });
        
        setIsLoading(false);
        return false;
      }
      
      // Registration successful
      console.log("Registration successful:", result);
      
      setUser(result.user);
      
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully!",
        variant: "success",
      });
      
      // Redirect to onboarding
      if (result.redirectTo) {
        router.push(result.redirectTo);
      } else {
        router.push("/auth/onboarding");
      }
      
      setIsLoading(false);
      return true;
    } catch (error) {
      console.error("Registration error:", error);
      
      toast({
        title: "Registration error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      
      setIsLoading(false);
      return false;
    }
  };

  // Complete onboarding function
  const completeOnboarding = async (): Promise<void> => {
    console.log("Completing onboarding");
    
    try {
      // In a real app, we would make an API call to update the user's onboarding status
      // For now, we'll just show a toast and redirect to the dashboard
      
      toast({
        title: "Onboarding complete",
        description: "Welcome to Spartan Community India!",
        variant: "success",
      });
      
      // Redirect to dashboard
      router.push("/dashboard");
    } catch (error) {
      console.error("Onboarding completion error:", error);
      
      toast({
        title: "Error",
        description: "Failed to complete onboarding. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Logout function
  const logout = async () => {
    console.log("Logging out");
    setIsLoading(true);
    
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      setUser(null);
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
        variant: "success",
      });
      
      router.push("/");
    } catch (error) {
      console.error("Logout error:", error);
      
      toast({
        title: "Logout error",
        description: "An error occurred while logging out.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Debug logging for auth state changes
  useEffect(() => {
    console.log("Auth state changed:", { user, isLoading });
  }, [user, isLoading]);

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      login, 
      logout, 
      checkSession,
      register,
      completeOnboarding
    }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};