/**
 * Utility function to copy text to clipboard
 * @param text - The text to copy to clipboard
 * @returns A promise that resolves to a boolean indicating success or failure
 */
export const copyToClipboard = async (text: string): Promise<boolean> => {
  try {
    // Use the modern Clipboard API if available
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    
    // Make the textarea out of viewport
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    
    textArea.focus();
    textArea.select();
    
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    
    return successful;
  } catch (error) {
    console.error('Failed to copy text: ', error);
    return false;
  }
};

/**
 * Generate a unique referral code for a user
 * @param userId - The user's ID
 * @param username - The user's name or username
 * @returns A unique referral code
 */
export const generateReferralCode = (userId: string, username: string): string => {
  // Take first 4 characters of userId and combine with sanitized username
  const userIdPrefix = userId.substring(0, 4);
  const nameSuffix = username.replace(/[^a-zA-Z0-9]/g, "").substring(0, 6).toUpperCase();
  
  return `${userIdPrefix}${nameSuffix}`;
};

/**
 * Create a referral link with the user's referral code
 * @param referralCode - The user's referral code
 * @returns A complete referral link
 */
export const createReferralLink = (referralCode: string): string => {
  const baseUrl = typeof window !== 'undefined' 
    ? `${window.location.protocol}//${window.location.host}`
    : 'https://spartancommunityindia.com';
  
  return `${baseUrl}/ref/${referralCode}`;
};