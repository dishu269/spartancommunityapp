import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";

// Define user roles
export enum UserRole {
  DISTRIBUTOR = "DISTRIBUTOR",
  LEADER = "LEADER",
  ADMIN = "ADMIN"
}

// User interface
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

// Secret key for JWT
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "default_secret_key_change_in_production"
);

// Generate JWT token
export async function signToken(payload: any): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(JWT_SECRET);
}

// Verify JWT token
export async function verifyToken(token: string): Promise<any> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload;
  } catch (error) {
    return null;
  }
}

// Get current user from cookies
export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = cookies();
  const token = cookieStore.get("auth-token")?.value;
  
  if (!token) return null;
  
  try {
    const payload = await verifyToken(token);
    if (!payload) return null;
    
    return {
      id: payload.id as string,
      name: payload.name as string,
      email: payload.email as string,
      role: payload.role as UserRole
    };
  } catch (error) {
    return null;
  }
}

// Check if user has required role
export async function hasRole(requiredRole: UserRole): Promise<boolean> {
  const user = await getCurrentUser();
  if (!user) return false;
  
  // Admin has access to everything
  if (user.role === UserRole.ADMIN) return true;
  
  // Leader has access to distributor content
  if (user.role === UserRole.LEADER && requiredRole === UserRole.DISTRIBUTOR) return true;
  
  // Otherwise, check exact role match
  return user.role === requiredRole;
}

// Middleware to protect routes based on role
export async function withRoleProtection(
  request: NextRequest,
  requiredRole: UserRole
): Promise<NextResponse | null> {
  const user = await getCurrentUser();
  
  if (!user) {
    return NextResponse.redirect(new URL("/auth/login", request.url));
  }
  
  // Check if user has the required role
  const hasRequiredRole = await hasRole(requiredRole);
  if (!hasRequiredRole) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }
  
  return null; // Continue with the request
}

// Generate a unique referral code for a user
export function generateReferralCode(userId: string, name: string): string {
  // Take first 4 characters of userId and combine with sanitized name
  const userIdPrefix = userId.substring(0, 4);
  const nameSuffix = name.replace(/[^a-zA-Z0-9]/g, "").substring(0, 6).toUpperCase();
  
  return `${userIdPrefix}${nameSuffix}`;
}

// Create a referral link
export function createReferralLink(referralCode: string): string {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "https://directgrowhub.com";
  return `${baseUrl}/ref/${referralCode}`;
}