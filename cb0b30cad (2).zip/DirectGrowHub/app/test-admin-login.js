const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

async function testAdminLogin() {
  const email = 'Dishantasclepius@gmail.com';
  const password = 'Dishu@1997';
  
  try {
    // 1. Find user by email
    const client = await pool.connect();
    const userResult = await client.query(
      'SELECT * FROM "User" WHERE LOWER(email) = LOWER($1)',
      [email]
    );
    
    if (userResult.rows.length === 0) {
      console.log('User not found');
      client.release();
      return;
    }
    
    const user = userResult.rows[0];
    console.log('User found:', {
      id: user.id,
      email: user.email,
      role: user.role,
      passwordHash: user.password
    });
    
    // 2. Verify password
    const passwordValid = await bcrypt.compare(password, user.password);
    console.log('Password valid:', passwordValid);
    
    // 3. Check if user is admin
    const isAdmin = user.role === 'ADMIN';
    console.log('Is admin:', isAdmin);
    
    // 4. Overall login result
    console.log('Login successful:', passwordValid && isAdmin);
    
    client.release();
  } catch (err) {
    console.error('Error testing admin login:', err);
  } finally {
    pool.end();
  }
}

testAdminLogin();
