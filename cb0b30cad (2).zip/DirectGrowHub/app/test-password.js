const bcrypt = require('bcryptjs');

async function main() {
  const plainPassword = 'Dishu@1997';
  
  // Hash the password
  const hashedPassword = await bcrypt.hash(plainPassword, 10);
  console.log('Hashed password:', hashedPassword);
  
  // Compare with the stored password from the database
  const storedPassword = 'Dishu@1997'; // This is what we found in the database
  const isMatch = await bcrypt.compare(plainPassword, storedPassword);
  console.log('Password match:', isMatch);
  
  // Try to compare with the password directly
  console.log('Direct comparison:', plainPassword === storedPassword);
}

main().catch(console.error);
