const fetch = require('node-fetch');

async function testLogin() {
  try {
    console.log('Testing login flow...');
    
    // Step 1: Login with admin credentials
    console.log('\nStep 1: Login with admin credentials');
    const loginResponse = await fetch('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'Dishantasclepius@gmail.com',
        password: 'Dishu@1997',
        rememberMe: true,
      }),
    });
    
    const loginData = await loginResponse.json();
    console.log('Login response:', loginData);
    
    // Extract cookies from response headers
    const cookies = loginResponse.headers.get('set-cookie');
    console.log('Cookies:', cookies);
    
    // Step 2: Login with regular user credentials
    console.log('\nStep 2: Login with regular user credentials');
    const regularLoginResponse = await fetch('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'testuser@example.com',
        password: 'testuser123',
        rememberMe: true,
      }),
    });
    
    const regularLoginData = await regularLoginResponse.json();
    console.log('Regular user login response:', regularLoginData);
    
    // Extract cookies from response headers
    const regularCookies = regularLoginResponse.headers.get('set-cookie');
    console.log('Regular user cookies:', regularCookies);
    
  } catch (error) {
    console.error('Error testing login flow:', error);
  }
}

testLogin();
