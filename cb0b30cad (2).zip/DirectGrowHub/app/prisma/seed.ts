import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, 10);
}

async function main() {
  console.log('Seeding database...');

  // Create admin user
  const adminPassword = await hashPassword('Dishu@1997');
  const admin = await prisma.user.upsert({
    where: { email: 'dishantparihar00@gmail.com' },
    update: {},
    create: {
      id: 'admin1',
      name: 'Dishant Parihar',
      email: 'dishantparihar00@gmail.com',
      password: adminPassword,
      role: 'ADMIN',
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'ADM1DISHANT',
    },
  });
  console.log('Admin user created:', admin.email);

  // Create test user
  const userPassword = await hashPassword('password123');
  const user = await prisma.user.upsert({
    where: { email: 'user@example.com' },
    update: {},
    create: {
      id: 'user1',
      name: 'Riya Sharma',
      email: 'user@example.com',
      password: userPassword,
      role: 'DISTRIBUTOR',
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'USR1RIYASH',
    },
  });
  console.log('Test user created:', user.email);

  // Create team leader
  const leaderPassword = await hashPassword('password123');
  const leader = await prisma.user.upsert({
    where: { email: 'leader@example.com' },
    update: {},
    create: {
      id: 'leader1',
      name: 'Arjun Singh',
      email: 'leader@example.com',
      password: leaderPassword,
      role: 'LEADER',
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'LDR1ARJUNS',
    },
  });
  console.log('Team leader created:', leader.email);

  // Create testimonials
  const testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Team Leader',
      content: 'Joining Spartan Community India was the best decision I\'ve made. In just 6 months, I built a team of 30 distributors and doubled my monthly income!',
      imageUrl: 'https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg',
      rating: 5,
      isActive: true,
    },
    {
      name: 'Rajesh Kumar',
      role: 'Distributor',
      content: 'The training and support I received helped me understand the business quickly. Now I\'m earning a steady income while working flexible hours.',
      imageUrl: 'https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg',
      rating: 5,
      isActive: true,
    },
    {
      name: 'Ananya Patel',
      role: 'New Distributor',
      content: 'As a college student, I was looking for a part-time opportunity. Spartan Community India provided me with the perfect platform to earn while I learn.',
      imageUrl: 'https://cdn.pixabay.com/photo/2024/01/06/09/38/indian-8490981_1280.jpg',
      rating: 4,
      isActive: true,
    },
  ];

  for (const testimonial of testimonials) {
    await prisma.testimonial.upsert({
      where: { id: `testimonial_${testimonial.name.replace(/\s+/g, '_').toLowerCase()}` },
      update: testimonial,
      create: {
        id: `testimonial_${testimonial.name.replace(/\s+/g, '_').toLowerCase()}`,
        ...testimonial,
      },
    });
  }
  console.log('Testimonials created');

  // Create achievements
  const achievements = [
    {
      title: '5,000+ Active Distributors',
      description: 'Join our growing community of successful entrepreneurs across India',
      order: 1,
      isActive: true,
    },
    {
      title: '₹10 Crore+ Monthly Sales',
      description: 'Be part of our success story with impressive monthly revenue',
      order: 2,
      isActive: true,
    },
    {
      title: '100+ Training Modules',
      description: 'Access comprehensive training to develop your skills and knowledge',
      order: 3,
      isActive: true,
    },
    {
      title: 'Pan-India Presence',
      description: 'Connect with distributors and customers across the country',
      order: 4,
      isActive: true,
    },
  ];

  for (const achievement of achievements) {
    await prisma.achievement.upsert({
      where: { id: `achievement_${achievement.title.replace(/\s+/g, '_').toLowerCase()}` },
      update: achievement,
      create: {
        id: `achievement_${achievement.title.replace(/\s+/g, '_').toLowerCase()}`,
        ...achievement,
      },
    });
  }
  console.log('Achievements created');

  // Create landing page content
  await prisma.landingPageContent.upsert({
    where: { id: 'default_landing_page' },
    update: {},
    create: {
      id: 'default_landing_page',
      heroTitle: 'Join Spartan Community India',
      heroSubtitle: 'Start your journey to financial freedom with India\'s fastest growing direct selling community',
      heroImageUrl: 'https://img.freepik.com/premium-photo/diverse-group-business-people-celebrate-success-cheering-with-their-arms-raised_14117-784329.jpg',
      aboutTitle: 'Why Join Our Community?',
      aboutContent: 'Spartan Community India provides you with the tools, training, and support you need to succeed in the direct selling industry. Join thousands of successful distributors who are building their financial future with us.',
      aboutImageUrl: 'https://c8.alamy.com/comp/PXR7YX/happy-business-people-celebrate-success-looking-at-laptop-screen-in-the-office-successful-corporate-partners-and-coworkers-winners-excited-of-victor-PXR7YX.jpg',
      ctaTitle: 'Ready to Start Your Journey?',
      ctaContent: 'Join our community today and take the first step towards financial independence. Our proven system and supportive community will help you achieve your goals.',
      ctaButtonText: 'Register Now',
      isActive: true,
    },
  });
  console.log('Landing page content created');

  console.log('Database seeding completed.');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });