import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import { UserRole } from '../lib/types';

const prisma = new PrismaClient();

async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, 10);
}

async function main() {
  console.log('Seeding database...');

  // Create admin user
  const adminPassword = await hashPassword('Dishu@1997');
  const admin = await prisma.user.upsert({
    where: { email: 'dishantparihar00@gmail.com' },
    update: {},
    create: {
      id: 'admin1',
      name: 'Dishant Parihar',
      email: 'dishantparihar00@gmail.com',
      password: adminPassword,
      role: UserRole.ADMIN,
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'ADM1DISHANT',
    },
  });
  console.log('Admin user created:', admin.email);

  // Create test user
  const userPassword = await hashPassword('password123');
  const user = await prisma.user.upsert({
    where: { email: 'user@example.com' },
    update: {},
    create: {
      id: 'user1',
      name: 'Riya Sharma',
      email: 'user@example.com',
      password: userPassword,
      role: UserRole.DISTRIBUTOR,
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'USR1RIYASH',
    },
  });
  console.log('Test user created:', user.email);

  // Create team leader
  const leaderPassword = await hashPassword('password123');
  const leader = await prisma.user.upsert({
    where: { email: 'leader@example.com' },
    update: {},
    create: {
      id: 'leader1',
      name: 'Arjun Singh',
      email: 'leader@example.com',
      password: leaderPassword,
      role: UserRole.LEADER,
      onboardingComplete: true,
      preferredLanguage: 'en',
      referralCode: 'LDR1ARJUNS',
    },
  });
  console.log('Team leader created:', leader.email);

  console.log('Database seeding completed.');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });