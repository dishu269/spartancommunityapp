const { Client } = require('pg');
const bcrypt = require('bcryptjs');

async function hashAndUpdatePassword(userId, plainPassword) {
  console.log(`Updating password for user ID: ${userId}`);
  
  const client = new Client({
    host: 'db-10a4e1c1cc.db001.hosteddb.reai.io',
    port: 5432,
    database: '10a4e1c1cc',
    user: 'role_10a4e1c1cc',
    password: 'MfSkhVLRdvL8sYYw24QuCK_M2s0R5TF_'
  });
  
  try {
    await client.connect();
    
    // Hash the password
    const hashedPassword = await bcrypt.hash(plainPassword, 10);
    console.log(`Original password: ${plainPassword}`);
    console.log(`Hashed password: ${hashedPassword}`);
    
    // Update the user's password in the database
    const result = await client.query(
      'UPDATE "User" SET password = $1 WHERE id = $2 RETURNING id, name, email',
      [hashedPassword, userId]
    );
    
    if (result.rows.length === 0) {
      console.log('User not found');
      return false;
    }
    
    console.log('Password updated successfully for user:', result.rows[0]);
    return true;
  } catch (error) {
    console.error('Error updating password:', error);
    return false;
  } finally {
    await client.end();
  }
}

// Update admin password
hashAndUpdatePassword('admin1', 'admin123')
  .then(result => {
    console.log('Admin password update result:', result);
    
    // Update user password
    return hashAndUpdatePassword('user1', 'password123');
  })
  .then(result => {
    console.log('User password update result:', result);
  })
  .catch(error => {
    console.error('Script error:', error);
  });
