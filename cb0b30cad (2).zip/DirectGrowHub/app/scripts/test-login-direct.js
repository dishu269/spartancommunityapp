const { Client } = require('pg');

async function testLogin(email, password) {
  console.log(`Testing login for email: ${email}`);
  
  const client = new Client({
    host: 'db-10a4e1c1cc.db001.hosteddb.reai.io',
    port: 5432,
    database: '10a4e1c1cc',
    user: 'role_10a4e1c1cc',
    password: 'MfSkhVLRdvL8sYYw24QuCK_M2s0R5TF_'
  });
  
  try {
    await client.connect();
    
    // Find user in database
    const result = await client.query(
      'SELECT * FROM "User" WHERE email = $1',
      [email.toLowerCase()]
    );
    
    if (result.rows.length === 0) {
      console.log('User not found in database');
      return false;
    }
    
    const user = result.rows[0];
    
    console.log('User found:', {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      password: user.password // Just for debugging
    });
    
    // For testing purposes, we'll do a direct comparison since we didn't hash the passwords
    const passwordValid = password === user.password;
    
    if (passwordValid) {
      console.log('Password is valid');
      return true;
    } else {
      console.log('Password is invalid');
      return false;
    }
  } catch (error) {
    console.error('Error during login test:', error);
    return false;
  } finally {
    await client.end();
  }
}

// Test with admin credentials
testLogin('admin@example.com', 'admin123')
  .then(result => {
    console.log('Admin login result:', result);
    
    // Test with user credentials
    return testLogin('user@example.com', 'password123');
  })
  .then(result => {
    console.log('User login result:', result);
  })
  .catch(error => {
    console.error('Test script error:', error);
  });
