const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

async function updateAdminPassword() {
  try {
    console.log('Updating admin password...');
    
    // Connect to the database
    const client = await pool.connect();
    
    try {
      // Find the admin user
      const findResult = await client.query(
        'SELECT id, name, email, password, role FROM "User" WHERE LOWER(email) = LOWER($1)',
        ['dishantasclepius@gmail.com']
      );
      
      if (findResult.rows.length === 0) {
        console.log('Admin user not found. Creating new admin user...');
        
        // Hash the password
        const hashedPassword = await bcrypt.hash('Dishu@1997', 10);
        
        // Create a new admin user
        await client.query(
          'INSERT INTO "User" (id, name, email, password, role, onboardingComplete, preferredLanguage, "createdAt", "updatedAt") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
          [
            'cuid_admin_user',
            'Dishant Parihar',
            'Dishantasclepius@gmail.com',
            hashedPassword,
            'ADMIN',
            true,
            'en',
            new Date(),
            new Date()
          ]
        );
        
        console.log('Admin user created successfully!');
      } else {
        console.log('Admin user found. Updating password...');
        
        // Hash the password
        const hashedPassword = await bcrypt.hash('Dishu@1997', 10);
        
        // Update the admin user's password
        await client.query(
          'UPDATE "User" SET password = $1, "updatedAt" = $2 WHERE id = $3',
          [hashedPassword, new Date(), findResult.rows[0].id]
        );
        
        console.log('Admin password updated successfully!');
      }
      
      // Verify the update
      const verifyResult = await client.query(
        'SELECT id, name, email, password, role FROM "User" WHERE LOWER(email) = LOWER($1)',
        ['dishantasclepius@gmail.com']
      );
      
      if (verifyResult.rows.length > 0) {
        const admin = verifyResult.rows[0];
        console.log('Admin user details:');
        console.log(`ID: ${admin.id}`);
        console.log(`Name: ${admin.name}`);
        console.log(`Email: ${admin.email}`);
        console.log(`Role: ${admin.role}`);
        
        // Verify the password
        const passwordValid = await bcrypt.compare('Dishu@1997', admin.password);
        console.log(`Password valid: ${passwordValid}`);
      }
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error updating admin password:', error);
  }
}

// Run the update
updateAdminPassword();
