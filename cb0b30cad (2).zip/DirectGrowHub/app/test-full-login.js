const fetch = require('node-fetch');
const { CookieJar } = require('tough-cookie');
const fetchCookieFactory = require('fetch-cookie');

async function testLogin() {
  try {
    console.log('Testing full login flow...');
    
    // Create a cookie jar to store cookies
    const cookieJar = new CookieJar();
    const fetchWithCookies = fetchCookieFactory(fetch, cookieJar);
    
    // Step 1: Login with admin credentials
    console.log('\nStep 1: Login with admin credentials');
    const loginResponse = await fetchWithCookies('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'Dishantasclepius@gmail.com',
        password: 'Dishu@1997',
        rememberMe: true,
      }),
    });
    
    const loginData = await loginResponse.json();
    console.log('Login response:', loginData);
    
    // Step 2: Check session
    console.log('\nStep 2: Check session');
    const sessionResponse = await fetchWithCookies('http://localhost:3001/api/auth/session', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    const sessionData = await sessionResponse.json();
    console.log('Session response:', sessionData);
    
    // Step 3: Logout
    console.log('\nStep 3: Logout');
    const logoutResponse = await fetchWithCookies('http://localhost:3001/api/auth/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    const logoutData = await logoutResponse.json();
    console.log('Logout response:', logoutData);
    
    // Step 4: Check session after logout
    console.log('\nStep 4: Check session after logout');
    const sessionAfterLogoutResponse = await fetchWithCookies('http://localhost:3001/api/auth/session', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    const sessionAfterLogoutData = await sessionAfterLogoutResponse.json();
    console.log('Session after logout response:', sessionAfterLogoutData);
    
    // Step 5: Login with regular user credentials
    console.log('\nStep 5: Login with regular user credentials');
    const regularLoginResponse = await fetchWithCookies('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'testuser@example.com',
        password: 'testuser123',
        rememberMe: true,
      }),
    });
    
    const regularLoginData = await regularLoginResponse.json();
    console.log('Regular user login response:', regularLoginData);
    
    // Step 6: Check session for regular user
    console.log('\nStep 6: Check session for regular user');
    const regularSessionResponse = await fetchWithCookies('http://localhost:3001/api/auth/session', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    const regularSessionData = await regularSessionResponse.json();
    console.log('Regular user session response:', regularSessionData);
    
  } catch (error) {
    console.error('Error testing login flow:', error);
  }
}

testLogin();
