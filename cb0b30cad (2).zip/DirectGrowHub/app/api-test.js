const fetch = require('node-fetch');
const { CookieJar } = require('tough-cookie');
const fetchCookieFactory = require('fetch-cookie');
const fetchCookie = fetchCookieFactory;

const BASE_URL = 'http://localhost:3000';
const API_ENDPOINTS = [
  { method: 'GET', url: '/api/auth/session', name: 'Get Session' },
  { method: 'POST', url: '/api/auth/login', name: 'Login', body: { email: 'Dishantasclepius@gmail.com', password: 'Dishu@1997' } },
  { method: 'GET', url: '/api/admin/users', name: 'Get Users' },
  { method: 'GET', url: '/api/admin/referrals', name: 'Get Referrals' },
  { method: 'GET', url: '/api/admin/content', name: 'Get Content' },
];

async function testEndpoints() {
  console.log('Starting API endpoint tests...');
  
  const jar = new CookieJar();
  const fetchWithCookies = fetchCookie(fetch, jar);
  
  const results = [];
  
  // First login to get authenticated
  try {
    console.log('Attempting login...');
    const loginResponse = await fetchWithCookies(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'Dishantasclepius@gmail.com', password: 'Dishu@1997' }),
    });
    
    const loginData = await loginResponse.json().catch(() => ({}));
    console.log(`Login status: ${loginResponse.status}`);
    console.log('Login response:', JSON.stringify(loginData, null, 2));
    
    results.push({
      endpoint: '/api/auth/login',
      status: loginResponse.status,
      success: loginResponse.status >= 200 && loginResponse.status < 300,
      data: loginData
    });
    
    // Now test other endpoints
    for (const endpoint of API_ENDPOINTS) {
      if (endpoint.url === '/api/auth/login') continue; // Skip login as we already did it
      
      console.log(`Testing ${endpoint.name} (${endpoint.url})...`);
      
      try {
        const response = await fetchWithCookies(`${BASE_URL}${endpoint.url}`, {
          method: endpoint.method,
          headers: { 'Content-Type': 'application/json' },
          body: endpoint.body ? JSON.stringify(endpoint.body) : undefined,
        });
        
        const data = await response.json().catch(() => ({}));
        console.log(`${endpoint.name} status: ${response.status}`);
        
        results.push({
          endpoint: endpoint.url,
          status: response.status,
          success: response.status >= 200 && response.status < 300,
          data: data
        });
      } catch (error) {
        console.error(`Error testing ${endpoint.name}:`, error.message);
        results.push({
          endpoint: endpoint.url,
          status: 'Error',
          success: false,
          error: error.message
        });
      }
    }
  } catch (error) {
    console.error('Error during login:', error.message);
    results.push({
      endpoint: '/api/auth/login',
      status: 'Error',
      success: false,
      error: error.message
    });
  }
  
  // Print summary
  console.log('\nAPI Test Results:');
  console.log('=================');
  
  for (const result of results) {
    console.log(`${result.endpoint}: ${result.success ? 'SUCCESS' : 'FAILED'} (Status: ${result.status})`);
  }
  
  return results;
}

testEndpoints().catch(console.error);
