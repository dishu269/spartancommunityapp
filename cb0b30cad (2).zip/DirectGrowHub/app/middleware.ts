import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "./lib/jwt";

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  
  // Define protected routes
  const adminRoutes = path.startsWith("/admin");
  const dashboardRoutes = path.startsWith("/dashboard");
  const authRoutes = path.startsWith("/auth");
  
  // Get token from cookies
  const token = request.cookies.get("auth-token")?.value;
  
  // If accessing admin routes
  if (adminRoutes) {
    // If no token, redirect to admin login
    if (!token) {
      console.log("No token found, redirecting to admin login");
      return NextResponse.redirect(new URL("/auth/admin-login", request.url));
    }
    
    try {
      // Verify token
      const payload = await verifyToken(token);
      
      // If token is invalid or user is not admin, redirect to admin login
      if (!payload || payload.role !== "ADMIN") {
        console.log("Invalid token or not admin, redirecting to admin login");
        return NextResponse.redirect(new URL("/auth/admin-login", request.url));
      }
    } catch (error) {
      console.error("Token verification error:", error);
      return NextResponse.redirect(new URL("/auth/admin-login", request.url));
    }
  }
  
  // If accessing dashboard routes
  if (dashboardRoutes) {
    // If no token, redirect to login
    if (!token) {
      console.log("No token found, redirecting to login");
      return NextResponse.redirect(new URL("/auth/login", request.url));
    }
    
    try {
      // Verify token
      const payload = await verifyToken(token);
      
      // If token is invalid, redirect to login
      if (!payload) {
        console.log("Invalid token, redirecting to login");
        return NextResponse.redirect(new URL("/auth/login", request.url));
      }
    } catch (error) {
      console.error("Token verification error:", error);
      return NextResponse.redirect(new URL("/auth/login", request.url));
    }
  }
  
  // If accessing auth routes and already authenticated
  if (authRoutes && token) {
    try {
      // Verify token
      const payload = await verifyToken(token);
      
      // If token is valid, redirect to appropriate dashboard
      if (payload) {
        if (payload.role === "ADMIN") {
          console.log("Admin already authenticated, redirecting to admin dashboard");
          return NextResponse.redirect(new URL("/admin/dashboard", request.url));
        } else {
          console.log("User already authenticated, redirecting to dashboard");
          return NextResponse.redirect(new URL("/dashboard", request.url));
        }
      }
    } catch (error) {
      // If token verification fails, continue to auth routes
      console.error("Token verification error:", error);
    }
  }
  
  return NextResponse.next();
}

// Configure which routes use this middleware
export const config = {
  matcher: [
    "/admin/:path*",
    "/dashboard/:path*",
    "/auth/login",
    "/auth/admin-login",
    "/auth/register",
  ],
};