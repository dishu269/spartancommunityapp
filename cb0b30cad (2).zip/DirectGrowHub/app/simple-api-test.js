const fetch = require('node-fetch');

const BASE_URL = 'http://localhost:3000';
const API_ENDPOINTS = [
  { method: 'GET', url: '/api/auth/session', name: 'Get Session' },
  { method: 'POST', url: '/api/auth/login', name: 'Login', body: { email: 'Dishantasclepius@gmail.com', password: 'Dishu@1997' } },
  { method: 'GET', url: '/api/auth/session', name: 'Get Session After Login' },
];

async function testEndpoints() {
  console.log('Starting API endpoint tests...');
  
  const results = [];
  let sessionCookie = '';
  
  for (const endpoint of API_ENDPOINTS) {
    console.log(`Testing ${endpoint.name} (${endpoint.url})...`);
    
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (sessionCookie) {
        headers['Cookie'] = sessionCookie;
      }
      
      const response = await fetch(`${BASE_URL}${endpoint.url}`, {
        method: endpoint.method,
        headers: headers,
        body: endpoint.body ? JSON.stringify(endpoint.body) : undefined,
      });
      
      // Save cookies for next requests
      const cookies = response.headers.get('set-cookie');
      if (cookies) {
        sessionCookie = cookies;
        console.log('Received cookies:', cookies);
      }
      
      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        data = { text: responseText };
      }
      
      console.log(`${endpoint.name} status: ${response.status}`);
      console.log(`${endpoint.name} response:`, JSON.stringify(data, null, 2));
      
      results.push({
        endpoint: endpoint.url,
        status: response.status,
        success: response.status >= 200 && response.status < 300,
        data: data
      });
    } catch (error) {
      console.error(`Error testing ${endpoint.name}:`, error.message);
      results.push({
        endpoint: endpoint.url,
        status: 'Error',
        success: false,
        error: error.message
      });
    }
  }
  
  // Print summary
  console.log('\nAPI Test Results:');
  console.log('=================');
  
  for (const result of results) {
    console.log(`${result.endpoint}: ${result.success ? 'SUCCESS' : 'FAILED'} (Status: ${result.status})`);
  }
  
  return results;
}

testEndpoints().catch(console.error);
