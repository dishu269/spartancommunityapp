const bcrypt = require('bcryptjs');

async function testPasswordComparison() {
  const storedHash = '$2a$10$Cl6U7qQU7xScGlP0eyb1pOWcwZb09h9c.ZaTRtb5/CSUgUOpa1GHK';
  const inputPassword = 'Dishu@1997';
  
  try {
    const isMatch = await bcrypt.compare(inputPassword, storedHash);
    console.log(`Password comparison result: ${isMatch}`);
    
    // If not matching, let's try to hash the input password to see what it should be
    if (!isMatch) {
      const newHash = await bcrypt.hash(inputPassword, 10);
      console.log(`New hash for '${inputPassword}': ${newHash}`);
      
      // Let's also try with some variations in case there's a case sensitivity issue
      const variations = [
        'dishu@1997',
        'DISHU@1997',
        'Dishu@1997 ', // with trailing space
        ' Dishu@1997', // with leading space
      ];
      
      for (const variation of variations) {
        const variationMatch = await bcrypt.compare(variation, storedHash);
        console.log(`Password '${variation}' comparison result: ${variationMatch}`);
      }
    }
  } catch (error) {
    console.error('Error during password comparison:', error);
  }
}

testPasswordComparison();
