# Spartan Community India

Spartan Community India is a mobile-first SaaS application designed to streamline the distributor journey for direct-selling/MLM teams in India. The application targets three primary personas: New Distributors, Team Leaders, and Admins/Company Ops.

## Features

- **Automated Onboarding**: Mobile-optimized signup form with post-signup auto-sequence
- **Personal Dashboard**: Quick access to training, progress tracking, and prospect invitations
- **Structured Training**: Micro-learning content with videos, PDFs, infographics, and quizzes
- **Engagement Features**: Motivational content, gamification elements, and discussion boards
- **Progress Tracking**: Individual and team metrics with data export functionality
- **Lead Generation**: Shareable referral links, QR codes, and simple landing page builder
- **Compliance & Ethics**: Mandatory compliance lessons and policy update alerts
- **Multilingual Support**: English and Hindi with externalized UI text for localization

## Getting Started

### Prerequisites

- Node.js 18.x or higher
- npm or yarn
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/spartan-community-india.git
cd spartan-community-india
```

2. Install dependencies:
```bash
npm install
# or
yarn install
```

3. Set up environment variables:
Create a `.env` file in the root directory with the following variables:
```
DATABASE_URL="postgresql://username:password@localhost:5432/spartan_community_india"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

4. Set up the database:
```bash
npx prisma db push
```

5. Start the development server:
```bash
npm run dev
# or
yarn dev
```

6. Open [http://localhost:3000](http://localhost:3000) in your browser to see the application.

## Tech Stack

- **Frontend**: Next.js 14, React 18, Tailwind CSS
- **State Management**: React Hooks
- **Animations**: Framer Motion
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: NextAuth.js
- **UI Components**: Custom components with Radix UI primitives
- **Icons**: Lucide React

## Project Structure

- `/app`: Next.js app directory with pages and API routes
- `/components`: Reusable React components
- `/lib`: Utility functions and helpers
- `/prisma`: Database schema and migrations
- `/public`: Static assets

## License

This project is licensed under the MIT License - see the LICENSE file for details.