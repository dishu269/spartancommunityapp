const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
const jwt = require('jsonwebtoken');

const app = express();
const prisma = new PrismaClient();
const PORT = 3001;

// Middleware
app.use(bodyParser.json());

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
  try {
    console.log('Login API called');
    const { email, password, rememberMe } = req.body;
    
    console.log(`Login attempt for email: ${email}`);
    
    // Find user by email (case insensitive)
    const user = await prisma.user.findFirst({
      where: {
        email: {
          equals: email,
          mode: 'insensitive'
        }
      }
    });
    
    if (!user) {
      console.log('User not found');
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials',
        message: 'The email or password you entered is incorrect.'
      });
    }
    
    // Verify password
    const passwordValid = await bcrypt.compare(password, user.password);
    
    if (!passwordValid) {
      console.log('Invalid password');
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials',
        message: 'The email or password you entered is incorrect.'
      });
    }
    
    console.log('Password verified successfully');
    
    // Create user object without password
    const userWithoutPassword = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      onboardingComplete: user.onboardingComplete
    };
    
    // Generate JWT token
    const token = jwt.sign(
      {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      },
      'your-secret-key',
      { expiresIn: rememberMe ? '30d' : '1d' }
    );
    
    console.log('User authenticated, token generated');
    
    // Determine redirect path based on onboarding status and role
    let redirectTo = user.role === 'ADMIN' ? '/admin/dashboard' : '/dashboard';
    
    if (!user.onboardingComplete && user.role !== 'ADMIN') {
      redirectTo = '/auth/onboarding';
    }
    
    // Return user data and redirect path
    return res.json({
      success: true,
      user: userWithoutPassword,
      token,
      redirectTo
    });
  } catch (error) {
    console.error('Login API error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error',
      message: 'An unexpected error occurred. Please try again later.'
    });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Login server running on port ${PORT}`);
});
