const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    console.log('Connecting to database...');
    
    // Try to find the admin user with exact email
    const adminUser = await prisma.user.findFirst({
      where: { 
        role: 'ADMIN',
        email: 'Dishantasclepius@gmail.com'
      }
    });
    
    console.log('Admin user with exact email match:', adminUser);
    
    // Try to find the admin user with case-insensitive email
    const adminUserCaseInsensitive = await prisma.user.findFirst({
      where: { 
        role: 'ADMIN',
        email: { 
          contains: 'dishantasclepius',
          mode: 'insensitive'
        }
      }
    });
    
    console.log('Admin user with case-insensitive email match:', adminUserCaseInsensitive);
    
    // Try direct SQL query to find the admin user
    const result = await prisma.$queryRaw`SELECT * FROM "User" WHERE LOWER(email) = LOWER('Dishantasclepius@gmail.com')`;
    console.log('Admin user with direct SQL query:', result);
    
  } catch (error) {
    console.error('Error querying database:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
