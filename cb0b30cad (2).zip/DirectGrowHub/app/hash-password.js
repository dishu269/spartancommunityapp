const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  try {
    console.log('Connecting to database...');
    
    // Find the admin user
    const adminUser = await prisma.user.findFirst({
      where: { role: 'ADMIN' }
    });
    
    if (!adminUser) {
      console.log('Admin user not found');
      return;
    }
    
    console.log('Found admin user:', adminUser.email);
    
    // Hash the password
    const plainPassword = adminUser.password; // Current plain text password
    const hashedPassword = await bcrypt.hash(plainPassword, 10);
    
    console.log('Original password:', plainPassword);
    console.log('Hashed password:', hashedPassword);
    
    // Update the user with the hashed password
    const updatedUser = await prisma.user.update({
      where: { id: adminUser.id },
      data: { password: hashedPassword }
    });
    
    console.log('Updated admin user password successfully');
    
  } catch (error) {
    console.error('Error updating password:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
