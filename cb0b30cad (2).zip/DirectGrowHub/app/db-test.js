const { PrismaClient } = require('@prisma/client');

async function testDatabase() {
  console.log('Starting database connection test...');
  
  try {
    // Initialize Prisma client
    const prisma = new PrismaClient();
    
    console.log('Prisma client initialized');
    
    // Test connection by querying users
    console.log('Testing user query...');
    const users = await prisma.user.findMany({
      take: 5,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        onboardingComplete: true,
        createdAt: true
      }
    });
    
    console.log(`Found ${users.length} users`);
    if (users.length > 0) {
      console.log('Sample user:', JSON.stringify(users[0], null, 2));
    }
    
    // Test other models
    console.log('\nTesting content query...');
    const content = await prisma.content.findMany({
      take: 5
    });
    console.log(`Found ${content.length} content items`);
    
    console.log('\nTesting referrals query...');
    const referrals = await prisma.referral.findMany({
      take: 5,
      include: {
        referrer: {
          select: {
            name: true,
            email: true
          }
        }
      }
    });
    console.log(`Found ${referrals.length} referrals`);
    
    console.log('\nTesting testimonials query...');
    const testimonials = await prisma.testimonial.findMany({
      take: 5
    });
    console.log(`Found ${testimonials.length} testimonials`);
    
    // Test database schema validation
    console.log('\nValidating database schema...');
    
    // Check if all required tables exist by querying them
    const tables = [
      { name: 'User', query: prisma.user.findFirst() },
      { name: 'Content', query: prisma.content.findFirst() },
      { name: 'Referral', query: prisma.referral.findFirst() },
      { name: 'Testimonial', query: prisma.testimonial.findFirst() },
      { name: 'Lead', query: prisma.lead.findFirst() },
      { name: 'Prospect', query: prisma.prospect.findFirst() },
      { name: 'TrainingModule', query: prisma.trainingModule.findFirst() },
      { name: 'Badge', query: prisma.badge.findFirst() }
    ];
    
    for (const table of tables) {
      try {
        await table.query;
        console.log(`✓ Table ${table.name} exists and is accessible`);
      } catch (error) {
        console.error(`✗ Error accessing table ${table.name}:`, error.message);
      }
    }
    
    // Close the Prisma client
    await prisma.$disconnect();
    console.log('\nDatabase connection test completed successfully');
    
    return {
      success: true,
      userCount: users.length,
      contentCount: content.length,
      referralCount: referrals.length,
      testimonialCount: testimonials.length
    };
  } catch (error) {
    console.error('Database connection test failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

testDatabase().catch(console.error);
