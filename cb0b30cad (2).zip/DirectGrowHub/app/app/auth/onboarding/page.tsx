"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight, ArrowLeft, Play, User, Mail, Phone, Building, MapPin, Upload, Link as LinkIcon } from "lucide-react";
import Image from "next/image";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/auth-context";

interface Task {
  id: string;
  title: string;
  description: string;
}

interface Step {
  id: string;
  title: string;
  description: string;
  image?: string;
  videoThumbnail?: string;
  videoDuration?: string;
  videoUrl?: string;
  tasks?: Task[];
}

// This would come from the admin panel in a real implementation
const introVideoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";

const steps: Step[] = [
  {
    id: "welcome",
    title: "Welcome to Spartan Community India!",
    description: "We're excited to have you join our community of successful distributors. Let's get you set up for success!",
    image: "https://img.freepik.com/premium-photo/diverse-group-business-people-celebrate-success-cheering-with-their-arms-raised_14117-784329.jpg",
  },
  {
    id: "profile",
    title: "Complete Your Profile",
    description: "Tell us a bit about yourself so we can personalize your experience.",
  },
  {
    id: "video",
    title: "Watch Our Introduction",
    description: "Learn about our company, products, and how Spartan Community India will help you succeed.",
    videoThumbnail: "https://i.pinimg.com/736x/fb/74/fc/fb74fc55ae804030d2c1fb1bb6d140d2.jpg",
    videoDuration: "2:45",
    videoUrl: introVideoUrl,
  },
  {
    id: "prospect",
    title: "Add Your First Prospect",
    description: "Start building your business by adding your first prospect.",
  },
  {
    id: "complete",
    title: "You're All Set!",
    description: "Your account is now ready. Let's start growing together!",
    image: "https://c8.alamy.com/comp/PXR7YX/happy-business-people-celebrate-success-looking-at-laptop-screen-in-the-office-successful-corporate-partners-and-coworkers-winners-excited-of-victor-PXR7YX.jpg",
  },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoCompleted, setVideoCompleted] = useState(false);
  const { toast } = useToast();
  const { user, completeOnboarding } = useAuth();
  
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    company: "",
    profileImage: "",
    prospectName: "",
    prospectEmail: "",
    prospectPhone: "",
    prospectRelation: "",
  });

  // Pre-fill form with user data if available
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        fullName: user.name || prev.fullName,
        email: user.email || prev.email,
      }));
    }
  }, [user]);

  // Fetch intro video URL from API or context
  useEffect(() => {
    // In a real implementation, this would fetch from an API
    // For now, we're using the hardcoded value
    const updatedSteps = [...steps];
    const videoStep = updatedSteps.find(step => step.id === "video");
    if (videoStep) {
      videoStep.videoUrl = introVideoUrl;
    }
  }, []);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
      
      // Show toast when moving to next step
      toast({
        title: "Progress saved",
        description: "Your information has been saved successfully",
        variant: "success",
      });
    } else {
      // Complete onboarding and redirect to dashboard
      completeOnboarding();
      
      // Explicitly redirect to the correct dashboard based on user role
      if (user && user.role === "ADMIN") {
        router.push("/admin/dashboard");
      } else {
        router.push("/dashboard");
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const toggleTask = (taskId: string) => {
    if (completedTasks.includes(taskId)) {
      setCompletedTasks(completedTasks.filter(id => id !== taskId));
    } else {
      setCompletedTasks([...completedTasks, taskId]);
    }
  };

  const toggleVideo = () => {
    setIsVideoPlaying(!isVideoPlaying);
    
    // Simulate video completion after 3 seconds
    if (!isVideoPlaying && !videoCompleted) {
      setTimeout(() => {
        setVideoCompleted(true);
        toast({
          title: "Video completed",
          description: "Great job! You've completed the introduction video.",
          variant: "success",
        });
      }, 3000);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const isProfileComplete = () => {
    const requiredFields = ['fullName', 'email', 'phone'];
    return requiredFields.every(field => formData[field as keyof typeof formData]);
  };

  const isProspectComplete = () => {
    const requiredFields = ['prospectName', 'prospectPhone'];
    return requiredFields.every(field => formData[field as keyof typeof formData]);
  };

  const currentStepData = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto w-full">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-muted rounded-lg shadow-lg overflow-hidden"
        >
          {/* Progress bar */}
          <div className="h-1 bg-muted">
            <motion.div
              className="h-full bg-primary"
              initial={{ width: `${((currentStep) / steps.length) * 100}%` }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            ></motion.div>
          </div>

          <div className="p-6 md:p-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-primary">
                {currentStepData.title}
              </h2>
              <span className="text-sm text-muted-foreground">
                Step {currentStep + 1} of {steps.length}
              </span>
            </div>

            <p className="text-muted-foreground mb-8">
              {currentStepData.description}
            </p>

            {/* Step content */}
            <div className="mb-8">
              {currentStepData.id === "welcome" && currentStepData.image && (
                <div className="relative h-64 rounded-lg overflow-hidden">
                  <Image
                    src={currentStepData.image}
                    alt="Welcome"
                    fill
                    className="object-cover"
                  />
                </div>
              )}

              {currentStepData.id === "profile" && (
                <div className="space-y-4">
                  <div className="flex justify-center mb-6">
                    <div className="relative">
                      <div className="h-24 w-24 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                        {formData.profileImage ? (
                          <Image
                            src={formData.profileImage}
                            alt="Profile"
                            fill
                            className="object-cover"
                          />
                        ) : (
                          <User className="h-12 w-12 text-muted-foreground" />
                        )}
                      </div>
                      <button className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full hover:bg-primary-light transition-colors duration-200">
                        <Upload className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-medium mb-1">
                        Full Name*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <User className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="fullName"
                          name="fullName"
                          type="text"
                          className="input pl-10"
                          placeholder="Your full name"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium mb-1">
                        Email Address*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="email"
                          name="email"
                          type="email"
                          className="input pl-10"
                          placeholder="you@example.com"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium mb-1">
                        Phone Number*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Phone className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="phone"
                          name="phone"
                          type="tel"
                          className="input pl-10"
                          placeholder="+91 9876543210"
                          value={formData.phone}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="company" className="block text-sm font-medium mb-1">
                        Company/Business (Optional)
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Building className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="company"
                          name="company"
                          type="text"
                          className="input pl-10"
                          placeholder="Your company name"
                          value={formData.company}
                          onChange={handleInputChange}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="address" className="block text-sm font-medium mb-1">
                      Address (Optional)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <input
                        id="address"
                        name="address"
                        type="text"
                        className="input pl-10"
                        placeholder="Your street address"
                        value={formData.address}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium mb-1">
                        City (Optional)
                      </label>
                      <input
                        id="city"
                        name="city"
                        type="text"
                        className="input"
                        placeholder="City"
                        value={formData.city}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="state" className="block text-sm font-medium mb-1">
                        State (Optional)
                      </label>
                      <input
                        id="state"
                        name="state"
                        type="text"
                        className="input"
                        placeholder="State"
                        value={formData.state}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="pincode" className="block text-sm font-medium mb-1">
                        PIN Code (Optional)
                      </label>
                      <input
                        id="pincode"
                        name="pincode"
                        type="text"
                        className="input"
                        placeholder="PIN Code"
                        value={formData.pincode}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentStepData.id === "video" && currentStepData.videoThumbnail && (
                <div className="space-y-4">
                  <div className="relative h-64 rounded-lg overflow-hidden bg-black">
                    <Image
                      src={currentStepData.videoThumbnail}
                      alt="Video thumbnail"
                      fill
                      className={`object-cover transition-opacity duration-300 ${isVideoPlaying ? 'opacity-50' : 'opacity-100'}`}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <button
                        onClick={toggleVideo}
                        className="bg-white/90 dark:bg-background/90 rounded-full p-4 shadow-lg hover:bg-white dark:hover:bg-background transition-all duration-200 hover:scale-105"
                      >
                        <Play className="h-8 w-8 text-primary" />
                      </button>
                    </div>
                    {!isVideoPlaying && currentStepData.videoDuration && (
                      <div className="absolute bottom-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-sm">
                        {currentStepData.videoDuration}
                      </div>
                    )}
                  </div>
                  
                  {isVideoPlaying && (
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Video Progress</span>
                        <span className="text-sm">{videoCompleted ? "100%" : "45%"}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full transition-all duration-1000" 
                          style={{ width: videoCompleted ? "100%" : "45%" }}
                        ></div>
                      </div>
                    </div>
                  )}
                  
                  {videoCompleted && (
                    <div className="bg-success/10 p-4 rounded-lg flex items-center">
                      <CheckCircle className="h-5 w-5 text-success mr-2" />
                      <span className="text-success font-medium">Video completed!</span>
                    </div>
                  )}
                  
                  <div className="bg-primary/10 p-4 rounded-lg">
                    <div className="flex items-start">
                      <LinkIcon className="h-5 w-5 text-primary mt-0.5 mr-2" />
                      <div>
                        <p className="font-medium text-sm">Video URL</p>
                        <p className="text-xs text-muted-foreground mb-2">
                          You can watch this video again later
                        </p>
                        <div className="flex">
                          <input
                            type="text"
                            className="input text-sm py-1.5 rounded-r-none flex-1"
                            value={currentStepData.videoUrl || ""}
                            readOnly
                          />
                          <a 
                            href={currentStepData.videoUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="bg-primary text-white px-3 py-1.5 rounded-r-md text-sm"
                          >
                            Open
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentStepData.id === "prospect" && (
                <div className="space-y-4">
                  <div className="bg-muted/50 p-4 rounded-lg mb-4">
                    <p className="text-sm">
                      Adding your first prospect is an important step in building your business. 
                      This person could be a friend, family member, or colleague who might be 
                      interested in your products or business opportunity.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="prospectName" className="block text-sm font-medium mb-1">
                        Prospect Name*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <User className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="prospectName"
                          name="prospectName"
                          type="text"
                          className="input pl-10"
                          placeholder="Prospect's name"
                          value={formData.prospectName}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="prospectRelation" className="block text-sm font-medium mb-1">
                        Relationship (Optional)
                      </label>
                      <select
                        id="prospectRelation"
                        name="prospectRelation"
                        className="input"
                        value={formData.prospectRelation}
                        onChange={handleInputChange}
                      >
                        <option value="">Select relationship</option>
                        <option value="Friend">Friend</option>
                        <option value="Family">Family</option>
                        <option value="Colleague">Colleague</option>
                        <option value="Acquaintance">Acquaintance</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="prospectPhone" className="block text-sm font-medium mb-1">
                        Phone Number*
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Phone className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="prospectPhone"
                          name="prospectPhone"
                          type="tel"
                          className="input pl-10"
                          placeholder="+91 9876543210"
                          value={formData.prospectPhone}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="prospectEmail" className="block text-sm font-medium mb-1">
                        Email Address (Optional)
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <input
                          id="prospectEmail"
                          name="prospectEmail"
                          type="email"
                          className="input pl-10"
                          placeholder="prospect@example.com"
                          value={formData.prospectEmail}
                          onChange={handleInputChange}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-primary/10 p-4 rounded-lg mt-4">
                    <div className="flex items-start">
                      <LinkIcon className="h-5 w-5 text-primary mt-0.5 mr-2" />
                      <div>
                        <p className="font-medium text-sm">Your Referral Link</p>
                        <p className="text-xs text-muted-foreground mb-2">
                          Share this link with your prospect to invite them to join
                        </p>
                        <div className="flex">
                          <input
                            type="text"
                            className="input text-sm py-1.5 rounded-r-none flex-1"
                            value="https://spartancommunityindia.com/ref/usr1RIYASH"
                            readOnly
                          />
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText("https://spartancommunityindia.com/ref/usr1RIYASH");
                              toast({
                                title: "Link copied!",
                                description: "Referral link has been copied to clipboard",
                                variant: "success",
                              });
                            }}
                            className="bg-primary text-white px-3 py-1.5 rounded-r-md text-sm"
                          >
                            Copy
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentStepData.id === "complete" && currentStepData.image && (
                <div className="text-center">
                  <div className="relative h-48 w-48 mx-auto mb-6">
                    <Image
                      src={currentStepData.image}
                      alt="Complete"
                      fill
                      className="object-cover rounded-lg"
                    />
                  </div>
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-success/20 text-success mb-4">
                    <CheckCircle className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">
                    Onboarding Complete!
                  </h3>
                  <p className="text-muted-foreground">
                    Your account is now set up and ready to use.
                  </p>
                </div>
              )}
            </div>

            {/* Navigation buttons */}
            <div className="flex justify-between">
              <button
                onClick={handlePrevious}
                className={`flex items-center ${
                  currentStep === 0
                    ? "invisible"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back
              </button>
              <button
                onClick={handleNext}
                className={`btn-primary flex items-center ${
                  (currentStepData.id === "profile" && !isProfileComplete()) ||
                  (currentStepData.id === "video" && !videoCompleted) ||
                  (currentStepData.id === "prospect" && !isProspectComplete())
                    ? "opacity-50 cursor-not-allowed"
                    : ""
                }`}
                disabled={
                  (currentStepData.id === "profile" && !isProfileComplete()) ||
                  (currentStepData.id === "video" && !videoCompleted) ||
                  (currentStepData.id === "prospect" && !isProspectComplete())
                }
              >
                {currentStep === steps.length - 1 ? "Go to Dashboard" : "Next"}
                <ArrowRight className="h-4 w-4 ml-1" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}