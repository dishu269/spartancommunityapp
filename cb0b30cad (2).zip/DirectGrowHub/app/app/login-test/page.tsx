"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, AlertCircle, CheckCircle } from "lucide-react";

export default function LoginTestPage() {
  const [email, setEmail] = useState("dishantparihar00@gmail.com");
  const [password, setPassword] = useState("Dishu@1997");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await fetch("/api/auth/test-login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        setError(data.error || "Login failed");
      } else {
        setResult(data);
      }
    } catch (err) {
      setError("An unexpected error occurred");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-muted/30">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h2 className="text-3xl font-bold text-center mb-2">
            Login Test Page
          </h2>
          <p className="text-muted-foreground">
            Test the login functionality with admin credentials
          </p>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mt-8 sm:mx-auto sm:w-full sm:max-w-md"
      >
        <div className="bg-white dark:bg-muted py-8 px-4 shadow-lg sm:rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1">
                Email address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="email"
                  type="email"
                  className="input pl-10"
                  placeholder="admin@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  className="input pl-10"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="btn-primary w-full flex justify-center items-center"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : null}
                {isLoading ? "Testing Login..." : "Test Login"}
              </button>
            </div>
          </form>

          {error && (
            <div className="mt-6 p-4 bg-danger/10 border border-danger/20 rounded-lg flex items-start">
              <AlertCircle className="h-5 w-5 text-danger mr-2 mt-0.5" />
              <div>
                <p className="text-sm text-danger">{error}</p>
              </div>
            </div>
          )}

          {result && (
            <div className="mt-6">
              <div className={`p-4 ${result.success ? "bg-success/10 border border-success/20" : "bg-danger/10 border border-danger/20"} rounded-lg flex items-start`}>
                {result.success ? (
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-danger mr-2 mt-0.5" />
                )}
                <div>
                  <p className={`text-sm ${result.success ? "text-success" : "text-danger"}`}>
                    {result.success ? "Login successful!" : "Login failed!"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Database connection: {result.dbConnectionSuccessful ? "Successful" : "Failed"}
                  </p>
                </div>
              </div>

              {result.success && (
                <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                  <h3 className="text-sm font-medium mb-2">User Information:</h3>
                  <pre className="text-xs overflow-auto p-2 bg-muted rounded">
                    {JSON.stringify(result.user, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-muted text-muted-foreground">
                  Test Credentials
                </span>
              </div>
            </div>
            <div className="mt-4 text-sm text-muted-foreground">
              <p><strong>Admin:</strong> dishantparihar00@gmail.com / Dishu@1997</p>
              <p><strong>User:</strong> user@example.com / password123</p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}