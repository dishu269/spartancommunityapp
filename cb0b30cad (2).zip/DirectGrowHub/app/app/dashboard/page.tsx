"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import Link from "next/link";
import { 
  BookOpen, 
  Users, 
  BarChart, 
  Award, 
  ArrowRight, 
  Bell, 
  Calendar, 
  TrendingUp,
  FileText,
  MessageSquare,
  Share2,
  User
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import EmptyState from "@/components/empty-state";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";

export default function Dashboard() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [statsRef, statsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [count, setCount] = useState({ 
    completedModules: 0, 
    leadsGenerated: 0, 
    earnings: 0 
  });

  const { user, isLoading } = useAuth();
  const router = useRouter();

  // Debug logging
  console.log("Dashboard rendering, auth state:", { user, isLoading });

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      console.log("User not authenticated, redirecting to login");
      router.push("/auth/login");
    }
  }, [user, isLoading, router]);

  // Empty states for dashboard
  const upcomingTasks: any[] = [];
  const recentActivities: any[] = [];
  const badges: any[] = [];

  // Progress data - would come from API in real implementation
  const progress = {
    completedModules: 0,
    totalModules: 12,
    leadsGenerated: 0,
    earnings: 0,
  };

  useEffect(() => {
    if (statsInView) {
      const interval = setInterval(() => {
        setCount(prev => ({
          completedModules: prev.completedModules >= progress.completedModules ? 
            progress.completedModules : prev.completedModules + 1,
          leadsGenerated: prev.leadsGenerated >= progress.leadsGenerated ? 
            progress.leadsGenerated : prev.leadsGenerated + 1,
          earnings: prev.earnings >= progress.earnings ? 
            progress.earnings : prev.earnings + 500,
        }));
      }, 100);
      
      return () => clearInterval(interval);
    }
  }, [statsInView, progress]);

  const quickActions = [
    { 
      icon: <BookOpen className="h-6 w-6 text-primary" />, 
      title: "Continue Training", 
      description: "Resume your learning journey",
      href: "/dashboard/training",
      color: "bg-primary/10"
    },
    { 
      icon: <Share2 className="h-6 w-6 text-secondary" />, 
      title: "Invite Prospect", 
      description: "Share your referral link",
      href: "/dashboard/referrals",
      color: "bg-secondary/10"
    },
    { 
      icon: <MessageSquare className="h-6 w-6 text-success" />, 
      title: "Join Discussion", 
      description: "Connect with your team",
      href: "/dashboard/community",
      color: "bg-success/10"
    },
    { 
      icon: <FileText className="h-6 w-6 text-warning" />, 
      title: "Compliance", 
      description: "Review latest policies",
      href: "/dashboard/compliance",
      color: "bg-warning/10"
    },
  ];

  const motivationalQuote = {
    text: "Success is not final, failure is not fatal: It is the courage to continue that counts.",
    author: "Winston Churchill"
  };

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Fallback if authentication state is lost
  if (!user) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="card p-8 text-center">
          <h2 className="text-xl font-semibold mb-4">Authentication Required</h2>
          <p className="text-muted-foreground mb-6">
            You need to be logged in to access this page. Please log in to continue.
          </p>
          <Link href="/auth/login" className="btn-primary">
            Go to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Welcome Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Welcome to Spartan Community India, {user.name.split(' ')[0]}!
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Here's your progress overview and today's tasks
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0 flex items-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="relative h-12 w-12 rounded-full overflow-hidden mr-3 bg-muted flex items-center justify-center">
              <User className="h-6 w-6 text-muted-foreground" />
            </div>
            <div>
              <p className="font-medium">{user.name}</p>
              <p className="text-sm text-muted-foreground">
                {user.role === "DISTRIBUTOR" ? "Distributor" : 
                 user.role === "LEADER" ? "Team Leader" : "Admin"}
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <motion.div
              key={action.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Link href={action.href}>
                <div className="card hover:translate-y-[-4px] transition-all duration-300">
                  <div className={`${action.color} p-3 rounded-full w-fit mb-3`}>
                    {action.icon}
                  </div>
                  <h3 className="font-medium mb-1">{action.title}</h3>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section 
        ref={statsRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Your Progress</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-full mr-4">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Completed Modules</p>
                <div className="flex items-baseline">
                  <h3 className="text-2xl font-bold">{count.completedModules}</h3>
                  <span className="text-sm text-muted-foreground ml-1">/ {progress.totalModules}</span>
                </div>
              </div>
            </div>
            <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full"
                style={{ width: `${(count.completedModules / progress.totalModules) * 100}%` }}
              ></div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-full mr-4">
                <BarChart className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Leads Generated</p>
                <h3 className="text-2xl font-bold">{count.leadsGenerated}</h3>
              </div>
            </div>
            <Link href="/dashboard/leads" className="mt-3 text-sm text-primary flex items-center">
              View all leads <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-success/10 rounded-full mr-4">
                <TrendingUp className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <h3 className="text-2xl font-bold">{formatCurrency(count.earnings)}</h3>
              </div>
            </div>
            <Link href="/dashboard/earnings" className="mt-3 text-sm text-primary flex items-center">
              View earnings <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Two Column Layout */}
      <div 
        ref={ref}
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Upcoming Tasks */}
          <motion.section 
            className="card"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Upcoming Tasks</h2>
              <Link href="/dashboard/tasks" className="text-sm text-primary flex items-center">
                View all <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            {upcomingTasks.length > 0 ? (
              <div className="space-y-3">
                {/* Task items would go here */}
              </div>
            ) : (
              <EmptyState
                icon={<Calendar className="h-6 w-6 text-muted-foreground" />}
                title="No upcoming tasks"
                description="Your upcoming tasks will appear here. Start by completing your training modules."
                action={
                  <Link href="/dashboard/training" className="btn-primary inline-flex items-center">
                    Start Training
                  </Link>
                }
              />
            )}
          </motion.section>

          {/* Recent Activity */}
          <motion.section 
            className="card"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Recent Activity</h2>
              <Link href="/dashboard/activity" className="text-sm text-primary flex items-center">
                View all <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            {recentActivities.length > 0 ? (
              <div className="space-y-4">
                {/* Activity items would go here */}
              </div>
            ) : (
              <EmptyState
                icon={<Bell className="h-6 w-6 text-muted-foreground" />}
                title="No recent activity"
                description="Your recent activities will appear here as you use the platform."
                action={null}
              />
            )}
          </motion.section>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Badges */}
          <motion.section 
            className="card"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Your Badges</h2>
              <Link href="/dashboard/badges" className="text-sm text-primary flex items-center">
                View all <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            {badges.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {/* Badge items would go here */}
              </div>
            ) : (
              <EmptyState
                icon={<Award className="h-6 w-6 text-muted-foreground" />}
                title="No badges yet"
                description="Complete training modules and activities to earn badges."
                action={null}
              />
            )}
          </motion.section>

          {/* Motivational Quote */}
          <motion.section 
            className="card bg-gradient-to-br from-primary/20 to-secondary/20 dark:from-primary/30 dark:to-secondary/30"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="text-center p-2">
              <p className="text-lg italic mb-3">"{motivationalQuote.text}"</p>
              <p className="text-sm text-muted-foreground">— {motivationalQuote.author}</p>
            </div>
          </motion.section>

          {/* Next Training */}
          <motion.section 
            className="card"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <h2 className="text-xl font-semibold mb-4">Continue Learning</h2>
            <EmptyState
              icon={<BookOpen className="h-6 w-6 text-muted-foreground" />}
              title="Start your training journey"
              description="Begin your learning path to develop your skills and grow your business."
              action={
                <Link 
                  href="/dashboard/training"
                  className="btn-primary inline-flex items-center"
                >
                  Explore Modules <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              }
            />
          </motion.section>
        </div>
      </div>
    </div>
  );
}