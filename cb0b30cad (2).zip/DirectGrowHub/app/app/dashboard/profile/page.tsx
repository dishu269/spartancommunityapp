"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Building, 
  Edit, 
  Save, 
  X, 
  Share2,
  Copy,
  QrCode,
  Link as LinkIcon
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/auth-context";
import ProfileAvatar from "@/components/profile-avatar";
import { useNotification } from "@/components/ui/notification";

export default function ProfilePage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, isLoading } = useAuth();
  const { showNotification } = useNotification();
  
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    company: "",
  });
  
  const [referralData, setReferralData] = useState({
    referralCode: "",
    referralLinks: {
      general: "",
      team: "",
      lead: ""
    },
    stats: {
      clicks: 0,
      conversions: 0,
      conversionRate: 0
    }
  });
  
  // Fetch user profile data
  useEffect(() => {
    if (user) {
      // In a real app, we would fetch the complete profile from an API
      // For now, we'll use the user data from auth context
      setProfileData({
        name: user.name || "",
        email: user.email || "",
        phone: "",
        address: "",
        city: "",
        state: "",
        pincode: "",
        company: "",
      });
      
      // Fetch referral data
      fetchReferralData();
    }
  }, [user]);
  
  // Fetch referral data
  const fetchReferralData = async () => {
    try {
      const response = await fetch("/api/referrals");
      const data = await response.json();
      
      if (data.success) {
        setReferralData(data.data);
      }
    } catch (error) {
      console.error("Error fetching referral data:", error);
    }
  };
  
  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle save profile
  const handleSaveProfile = async () => {
    setIsSaving(true);
    
    try {
      // In a real app, we would send the updated profile to an API
      // For now, we'll just simulate a delay and show a success message
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
        variant: "success",
      });
      
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Update failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  // Copy referral link to clipboard
  const copyReferralLink = (link: string, type: string) => {
    navigator.clipboard.writeText(link);
    
    showNotification({
      title: "Link copied!",
      message: `${type} referral link has been copied to clipboard`,
      type: "success",
      duration: 3000,
    });
  };
  
  // Show QR code
  const showQrCode = (link: string, type: string) => {
    // In a real app, we would show a QR code modal
    // For now, we'll just show a toast
    toast({
      title: "QR Code",
      description: `QR code for ${type} referral link would be shown here`,
      variant: "default",
    });
  };
  
  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  // Redirect if not authenticated
  if (!user) {
    router.push("/auth/login");
    return null;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              My Profile
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Manage your personal information and referral links
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            {isEditing ? (
              <div className="flex space-x-3">
                <button 
                  onClick={() => setIsEditing(false)}
                  className="btn-outline flex items-center"
                  disabled={isSaving}
                >
                  <X className="h-5 w-5 mr-2" />
                  Cancel
                </button>
                <button 
                  onClick={handleSaveProfile}
                  className="btn-primary flex items-center"
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  ) : (
                    <Save className="h-5 w-5 mr-2" />
                  )}
                  {isSaving ? "Saving..." : "Save Changes"}
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsEditing(true)}
                className="btn-primary flex items-center"
              >
                <Edit className="h-5 w-5 mr-2" />
                Edit Profile
              </button>
            )}
          </motion.div>
        </div>
      </section>

      {/* Profile Section */}
      <motion.section 
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="card p-6">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/3 flex flex-col items-center mb-6 md:mb-0">
              <ProfileAvatar 
                name={profileData.name}
                size="xl"
                className="mb-4"
              />
              <h2 className="text-xl font-semibold">{profileData.name}</h2>
              <p className="text-muted-foreground">{user.role === "DISTRIBUTOR" ? "Distributor" : user.role === "LEADER" ? "Team Leader" : "Admin"}</p>
            </div>
            
            <div className="md:w-2/3">
              <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Full Name
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="name"
                      className="input"
                      value={profileData.name}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <div className="flex items-center">
                      <User className="h-5 w-5 text-muted-foreground mr-2" />
                      <span>{profileData.name}</span>
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Email Address
                  </label>
                  {isEditing ? (
                    <input
                      type="email"
                      name="email"
                      className="input"
                      value={profileData.email}
                      onChange={handleInputChange}
                      disabled={true} // Email cannot be changed
                    />
                  ) : (
                    <div className="flex items-center">
                      <Mail className="h-5 w-5 text-muted-foreground mr-2" />
                      <span>{profileData.email}</span>
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Phone Number
                  </label>
                  {isEditing ? (
                    <input
                      type="tel"
                      name="phone"
                      className="input"
                      value={profileData.phone}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 text-muted-foreground mr-2" />
                      <span>{profileData.phone || "Not provided"}</span>
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Company/Business
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="company"
                      className="input"
                      value={profileData.company}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <div className="flex items-center">
                      <Building className="h-5 w-5 text-muted-foreground mr-2" />
                      <span>{profileData.company || "Not provided"}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <h3 className="text-lg font-semibold mt-6 mb-4">Address</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">
                    Street Address
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="address"
                      className="input"
                      value={profileData.address}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 text-muted-foreground mr-2" />
                      <span>{profileData.address || "Not provided"}</span>
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    City
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="city"
                      className="input"
                      value={profileData.city}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <span>{profileData.city || "Not provided"}</span>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    State
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="state"
                      className="input"
                      value={profileData.state}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <span>{profileData.state || "Not provided"}</span>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    PIN Code
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="pincode"
                      className="input"
                      value={profileData.pincode}
                      onChange={handleInputChange}
                      disabled={isSaving}
                    />
                  ) : (
                    <span>{profileData.pincode || "Not provided"}</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Referral Links Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <h2 className="text-xl font-semibold mb-4">My Referral Links</h2>
        
        <div className="card p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Referral Code</h3>
              <p className="text-muted-foreground">Share this code with others to earn referral rewards</p>
            </div>
            <div className="mt-3 md:mt-0 bg-primary/10 px-4 py-2 rounded-md font-mono text-lg font-semibold text-primary">
              {referralData.referralCode || "Loading..."}
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-md font-semibold mb-2">General Referral Link</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <LinkIcon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    type="text"
                    className="input pl-10 pr-24 w-full"
                    value={referralData.referralLinks.general}
                    readOnly
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                    <button 
                      onClick={() => copyReferralLink(referralData.referralLinks.general, "General")}
                      className="p-1 hover:bg-muted rounded-md"
                      title="Copy link"
                    >
                      <Copy className="h-4 w-4 text-muted-foreground" />
                    </button>
                    <button 
                      onClick={() => showQrCode(referralData.referralLinks.general, "General")}
                      className="p-1 hover:bg-muted rounded-md ml-1"
                      title="Show QR code"
                    >
                      <QrCode className="h-4 w-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>
                <button 
                  onClick={() => copyReferralLink(referralData.referralLinks.general, "General")}
                  className="btn-primary flex items-center justify-center sm:w-auto"
                >
                  <Share2 className="h-5 w-5 mr-2" />
                  Share
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Use this link for general referrals
              </p>
            </div>
            
            <div>
              <h3 className="text-md font-semibold mb-2">Team Referral Link</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <LinkIcon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    type="text"
                    className="input pl-10 pr-24 w-full"
                    value={referralData.referralLinks.team}
                    readOnly
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                    <button 
                      onClick={() => copyReferralLink(referralData.referralLinks.team, "Team")}
                      className="p-1 hover:bg-muted rounded-md"
                      title="Copy link"
                    >
                      <Copy className="h-4 w-4 text-muted-foreground" />
                    </button>
                    <button 
                      onClick={() => showQrCode(referralData.referralLinks.team, "Team")}
                      className="p-1 hover:bg-muted rounded-md ml-1"
                      title="Show QR code"
                    >
                      <QrCode className="h-4 w-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>
                <button 
                  onClick={() => copyReferralLink(referralData.referralLinks.team, "Team")}
                  className="btn-primary flex items-center justify-center sm:w-auto"
                >
                  <Share2 className="h-5 w-5 mr-2" />
                  Share
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Use this link when inviting people to join your team
              </p>
            </div>
            
            <div>
              <h3 className="text-md font-semibold mb-2">Lead Referral Link</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <LinkIcon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    type="text"
                    className="input pl-10 pr-24 w-full"
                    value={referralData.referralLinks.lead}
                    readOnly
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                    <button 
                      onClick={() => copyReferralLink(referralData.referralLinks.lead, "Lead")}
                      className="p-1 hover:bg-muted rounded-md"
                      title="Copy link"
                    >
                      <Copy className="h-4 w-4 text-muted-foreground" />
                    </button>
                    <button 
                      onClick={() => showQrCode(referralData.referralLinks.lead, "Lead")}
                      className="p-1 hover:bg-muted rounded-md ml-1"
                      title="Show QR code"
                    >
                      <QrCode className="h-4 w-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>
                <button 
                  onClick={() => copyReferralLink(referralData.referralLinks.lead, "Lead")}
                  className="btn-primary flex items-center justify-center sm:w-auto"
                >
                  <Share2 className="h-5 w-5 mr-2" />
                  Share
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Use this link when sharing with potential leads
              </p>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Referral Statistics</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Total Clicks</p>
                <p className="text-2xl font-bold">{referralData.stats.clicks}</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Conversions</p>
                <p className="text-2xl font-bold">{referralData.stats.conversions}</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <p className="text-2xl font-bold">{referralData.stats.conversionRate.toFixed(2)}%</p>
              </div>
            </div>
          </div>
        </div>
      </motion.section>
    </div>
  );
}