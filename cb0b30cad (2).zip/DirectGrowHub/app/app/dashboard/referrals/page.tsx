"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Link from "next/link";
import { 
  Share2, 
  QrCode, 
  Copy, 
  Users, 
  ArrowUpRight, 
  Mail, 
  MessageSquare, 
  Plus,
  CheckCircle
} from "lucide-react";
import EmptyState from "@/components/empty-state";
import { useToast } from "@/components/ui/use-toast";
import { copyToClipboard, generateReferralCode, createReferralLink } from "@/lib/copy-to-clipboard";

// Mock user data - in a real app, this would come from authentication context
const mockUser = {
  id: "usr123456",
  name: "Riya Sharma",
  email: "riya.sharma@example.com",
};

export default function ReferralsPage() {
  const [copied, setCopied] = useState(false);
  const [referralCode, setReferralCode] = useState("");
  const [referralLink, setReferralLink] = useState("");
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  const { toast } = useToast();

  // Generate referral code and link on component mount
  useEffect(() => {
    const code = generateReferralCode(mockUser.id, mockUser.name);
    setReferralCode(code);
    setReferralLink(createReferralLink(code));
  }, []);

  const handleCopyToClipboard = async () => {
    const success = await copyToClipboard(referralLink);
    
    if (success) {
      setCopied(true);
      toast({
        title: "Link copied!",
        description: "Referral link has been copied to clipboard",
        variant: "success",
      });
      
      // Reset copied state after 2 seconds
      setTimeout(() => {
        setCopied(false);
      }, 2000);
    } else {
      toast({
        title: "Copy failed",
        description: "Could not copy the referral link. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Empty state for referrals - would be populated from API in real implementation
  const referrals: any[] = [];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Your Referrals
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Invite others to join your team and track your referrals
            </motion.p>
          </div>
        </div>
      </section>

      {/* Referral Link Section */}
      <section className="mb-8">
        <motion.div
          className="card p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-xl font-semibold mb-4">Your Unique Referral Link</h2>
          <div className="bg-muted/50 p-4 rounded-lg mb-4">
            <div className="flex flex-col md:flex-row md:items-center gap-3">
              <div className="flex-1 bg-white dark:bg-background rounded-md px-3 py-2 text-sm break-all">
                {referralLink}
              </div>
              <button 
                onClick={handleCopyToClipboard}
                className="btn-primary flex items-center justify-center"
              >
                {copied ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Link
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-primary/10 p-4 rounded-lg">
              <div className="flex items-start">
                <div className="p-2 bg-white dark:bg-muted rounded-md mr-3">
                  <QrCode className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">QR Code</h3>
                  <p className="text-sm text-muted-foreground">Generate a QR code for in-person sharing</p>
                </div>
              </div>
              <button className="mt-3 w-full btn-outline text-sm py-1.5">
                Generate QR
              </button>
            </div>
            
            <div className="bg-secondary/10 p-4 rounded-lg">
              <div className="flex items-start">
                <div className="p-2 bg-white dark:bg-muted rounded-md mr-3">
                  <Mail className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">Email Invite</h3>
                  <p className="text-sm text-muted-foreground">Send a personalized email invitation</p>
                </div>
              </div>
              <button className="mt-3 w-full btn-outline text-sm py-1.5">
                Send Email
              </button>
            </div>
            
            <div className="bg-success/10 p-4 rounded-lg">
              <div className="flex items-start">
                <div className="p-2 bg-white dark:bg-muted rounded-md mr-3">
                  <MessageSquare className="h-5 w-5 text-success" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">WhatsApp Share</h3>
                  <p className="text-sm text-muted-foreground">Share your link via WhatsApp</p>
                </div>
              </div>
              <a 
                href={`https://wa.me/?text=Join%20my%20team%20on%20Spartan%20Community%20India!%20${encodeURIComponent(referralLink)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 w-full btn-outline text-sm py-1.5 inline-block text-center"
              >
                Share Now
              </a>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Referral Stats */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Referral Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-full mr-4">
                <Share2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Shares</p>
                <h3 className="text-2xl font-bold">0</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-full mr-4">
                <Users className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Successful Referrals</p>
                <h3 className="text-2xl font-bold">0</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-success/10 rounded-full mr-4">
                <ArrowUpRight className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <h3 className="text-2xl font-bold">0%</h3>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Referral List */}
      <section ref={ref}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Your Referrals</h2>
        </div>
        
        {referrals.length > 0 ? (
          <div className="card overflow-hidden">
            {/* Referral list would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<Users className="h-6 w-6 text-muted-foreground" />}
            title="No referrals yet"
            description="Share your unique referral link to invite others to join your team."
            action={
              <button 
                onClick={handleCopyToClipboard}
                className="btn-primary inline-flex items-center"
              >
                <Copy className="h-5 w-5 mr-2" />
                Copy Referral Link
              </button>
            }
          />
        )}
      </section>
    </div>
  );
}