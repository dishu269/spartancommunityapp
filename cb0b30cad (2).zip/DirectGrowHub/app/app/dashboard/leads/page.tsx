"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { 
  Users, 
  Calendar, 
  PlusCircle, 
  Search, 
  Filter,
  Phone,
  Mail,
  MessageSquare,
  Clock,
  ChevronDown,
  Edit,
  Trash2,
  ArrowUpRight,
  UserPlus
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/auth-context";
import EmptyState from "@/components/empty-state";

// Mock data for leads
const mockLeads = [
  {
    id: "1",
    name: "Rahul Sharma",
    email: "rahul.s@example.com",
    phone: "+91 9876543210",
    relationship: "Friend",
    status: "NEW",
    notes: "Met at networking event, interested in health products",
    createdAt: "2023-10-15T10:30:00Z",
  },
  {
    id: "2",
    name: "Priya Patel",
    email: "priya.p@example.com",
    phone: "+91 9876543211",
    relationship: "Colleague",
    status: "CONTACTED",
    notes: "Sent product catalog, following up next week",
    createdAt: "2023-10-12T14:20:00Z",
  },
  {
    id: "3",
    name: "Amit Kumar",
    email: "amit.k@example.com",
    phone: "+91 9876543212",
    relationship: "Family",
    status: "INTERESTED",
    notes: "Very interested in business opportunity, scheduling presentation",
    createdAt: "2023-10-10T09:15:00Z",
  },
  {
    id: "4",
    name: "Neha Gupta",
    email: "neha.g@example.com",
    phone: "+91 9876543213",
    relationship: "Neighbor",
    status: "CONVERTED",
    notes: "Joined as distributor, needs onboarding support",
    createdAt: "2023-10-05T16:45:00Z",
  },
  {
    id: "5",
    name: "Vikram Singh",
    email: "vikram.s@example.com",
    phone: "+91 9876543214",
    relationship: "Friend",
    status: "LOST",
    notes: "Not interested at this time, follow up in 3 months",
    createdAt: "2023-09-28T11:30:00Z",
  },
];

// Mock data for follow-ups
const mockFollowUps = [
  {
    id: "1",
    leadId: "2",
    leadName: "Priya Patel",
    type: "CALL",
    date: "2023-10-20T10:00:00Z",
    notes: "Follow up on product catalog, answer questions",
    completed: false,
  },
  {
    id: "2",
    leadId: "3",
    leadName: "Amit Kumar",
    type: "MEETING",
    date: "2023-10-21T15:30:00Z",
    notes: "Business opportunity presentation",
    completed: false,
  },
  {
    id: "3",
    leadId: "4",
    leadName: "Neha Gupta",
    type: "CALL",
    date: "2023-10-19T11:00:00Z",
    notes: "Onboarding support call",
    completed: false,
  },
];

const statusColors = {
  NEW: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  CONTACTED: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  INTERESTED: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  CONVERTED: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  LOST: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const followUpTypeColors = {
  CALL: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  MEETING: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  EMAIL: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  MESSAGE: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
};

export default function LeadsPage() {
  const [leads, setLeads] = useState(mockLeads);
  const [followUps, setFollowUps] = useState(mockFollowUps);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [followUpsRef, followUpsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  const [leadsRef, leadsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  // Filter leads based on search term and status filter
  const filteredLeads = leads.filter(lead => {
    const matchesSearch = 
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone.includes(searchTerm);
    
    const matchesStatus = statusFilter === "ALL" || lead.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Format date to readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };

  // Handle lead deletion
  const handleDeleteLead = (id: string) => {
    setLeads(leads.filter(lead => lead.id !== id));
    toast({
      title: "Lead deleted",
      description: "The lead has been successfully deleted.",
    });
  };

  // Handle follow-up completion
  const handleCompleteFollowUp = (id: string) => {
    setFollowUps(followUps.map(followUp => 
      followUp.id === id ? { ...followUp, completed: true } : followUp
    ));
    toast({
      title: "Follow-up completed",
      description: "The follow-up has been marked as completed.",
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6 flex items-center justify-center min-h-[60vh]">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Lead Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Track and manage your prospects and leads
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Link href="/dashboard/leads/add" className="btn-primary flex items-center">
              <UserPlus className="h-5 w-5 mr-2" />
              Add New Lead
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Upcoming Follow-ups Section */}
      <section 
        ref={followUpsRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Upcoming Follow-ups</h2>
        
        {followUps.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {followUps.map((followUp, index) => (
              <motion.div
                key={followUp.id}
                className="card"
                initial={{ opacity: 0, y: 20 }}
                animate={followUpsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="flex items-start">
                  <div className={`p-2 rounded-md mr-3 ${followUpTypeColors[followUp.type as keyof typeof followUpTypeColors]}`}>
                    {followUp.type === "CALL" && <Phone className="h-5 w-5" />}
                    {followUp.type === "MEETING" && <Users className="h-5 w-5" />}
                    {followUp.type === "EMAIL" && <Mail className="h-5 w-5" />}
                    {followUp.type === "MESSAGE" && <MessageSquare className="h-5 w-5" />}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{followUp.leadName}</h3>
                    <div className="flex items-center text-sm text-muted-foreground mb-2">
                      <Clock className="h-4 w-4 mr-1" />
                      {formatDate(followUp.date)}
                    </div>
                    <p className="text-sm mb-3">{followUp.notes}</p>
                    <div className="flex justify-between">
                      <button 
                        onClick={() => handleCompleteFollowUp(followUp.id)}
                        className="text-sm text-primary hover:text-primary-dark font-medium"
                      >
                        Mark as Complete
                      </button>
                      <Link 
                        href={`/dashboard/leads/${followUp.leadId}`}
                        className="text-sm text-muted-foreground hover:text-foreground"
                      >
                        View Lead
                      </Link>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={<Calendar className="h-6 w-6 text-muted-foreground" />}
            title="No upcoming follow-ups"
            description="Schedule follow-ups with your leads to stay connected"
            action={
              <Link href="/dashboard/leads/follow-ups/create" className="btn-primary inline-flex items-center">
                <PlusCircle className="h-5 w-5 mr-2" />
                Schedule Follow-up
              </Link>
            }
          />
        )}
      </section>

      {/* Leads List Section */}
      <section ref={leadsRef}>
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Your Leads</h2>
          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 mt-2 md:mt-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search leads..."
                className="input pl-9 w-full md:w-auto"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <select
                className="input pl-9 w-full md:w-auto appearance-none"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="ALL">All Statuses</option>
                <option value="NEW">New</option>
                <option value="CONTACTED">Contacted</option>
                <option value="INTERESTED">Interested</option>
                <option value="CONVERTED">Converted</option>
                <option value="LOST">Lost</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            </div>
          </div>
        </div>
        
        {filteredLeads.length > 0 ? (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">Name</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Contact</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Relationship</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Added On</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredLeads.map((lead, index) => (
                    <motion.tr 
                      key={lead.id}
                      className="hover:bg-muted/30 transition-colors duration-150"
                      initial={{ opacity: 0, y: 20 }}
                      animate={leadsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <td className="px-4 py-3">
                        <Link href={`/dashboard/leads/${lead.id}`} className="font-medium hover:text-primary">
                          {lead.name}
                        </Link>
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-sm">{lead.email}</div>
                        <div className="text-xs text-muted-foreground">{lead.phone}</div>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {lead.relationship}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[lead.status as keyof typeof statusColors]}`}>
                          {lead.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {new Date(lead.createdAt).toLocaleDateString('en-IN')}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <Link 
                            href={`/dashboard/leads/${lead.id}/edit`}
                            className="p-1 text-muted-foreground hover:text-foreground"
                            title="Edit Lead"
                          >
                            <Edit className="h-4 w-4" />
                          </Link>
                          <button 
                            onClick={() => handleDeleteLead(lead.id)}
                            className="p-1 text-muted-foreground hover:text-danger"
                            title="Delete Lead"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                          <Link 
                            href={`/dashboard/leads/${lead.id}`}
                            className="p-1 text-muted-foreground hover:text-primary"
                            title="View Details"
                          >
                            <ArrowUpRight className="h-4 w-4" />
                          </Link>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <EmptyState
            icon={<Users className="h-6 w-6 text-muted-foreground" />}
            title="No leads found"
            description="Start adding leads to grow your business"
            action={
              <Link href="/dashboard/leads/add" className="btn-primary inline-flex items-center">
                <PlusCircle className="h-5 w-5 mr-2" />
                Add Your First Lead
              </Link>
            }
          />
        )}
      </section>
    </div>
  );
}