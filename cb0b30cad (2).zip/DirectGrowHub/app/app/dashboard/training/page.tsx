"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import Link from "next/link";
import { 
  BookOpen, 
  CheckCircle, 
  Lock, 
  Search,
  Filter,
  ChevronDown,
  Award,
  PlusCircle
} from "lucide-react";
import { calculateProgress } from "@/lib/utils";
import EmptyState from "@/components/empty-state";

export default function TrainingPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("ALL");
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [pathsRef, pathsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [badgesRef, badgesInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  // Empty states for training
  const trainingModules: any[] = [];
  const inProgressModules: any[] = [];
  const learningPaths: any[] = [];
  const badges: any[] = [];

  // Calculate overall progress
  const completedModules = 0;
  const totalModules = 12; // Default total modules
  const overallProgress = calculateProgress(completedModules, totalModules);

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Training Center
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Enhance your skills with our structured learning modules
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-white dark:bg-muted rounded-lg shadow-sm p-3">
              <div className="flex items-center">
                <BookOpen className="h-6 w-6 text-primary mr-3" />
                <div>
                  <p className="text-sm text-muted-foreground">Overall Progress</p>
                  <div className="flex items-baseline">
                    <h3 className="text-xl font-bold">{overallProgress}%</h3>
                    <span className="text-sm text-muted-foreground ml-1">
                      ({completedModules}/{totalModules} modules)
                    </span>
                  </div>
                </div>
              </div>
              <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${overallProgress}%` }}
                ></div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search modules..."
              className="input pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-5 w-5 text-muted-foreground" />
            </div>
            <select
              className="input pl-10 pr-10 appearance-none"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="ALL">All Categories</option>
              <option value="ESSENTIAL">Essential</option>
              <option value="MARKETING">Marketing</option>
              <option value="SALES">Sales</option>
              <option value="COMPLIANCE">Compliance</option>
              <option value="LEADERSHIP">Leadership</option>
              <option value="TECHNOLOGY">Technology</option>
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown className="h-5 w-5 text-muted-foreground" />
            </div>
          </div>
        </div>
      </section>

      {/* Continue Learning */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Continue Learning</h2>
        {inProgressModules.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* In-progress modules would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<BookOpen className="h-6 w-6 text-muted-foreground" />}
            title="No modules in progress"
            description="Start a new module to continue your learning journey"
            action={null}
          />
        )}
      </section>

      {/* Learning Paths */}
      <section 
        ref={pathsRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Learning Paths</h2>
        {learningPaths.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Learning paths would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<BookOpen className="h-6 w-6 text-muted-foreground" />}
            title="Learning paths coming soon"
            description="Structured learning paths will be available soon to guide your development"
            action={null}
          />
        )}
      </section>

      {/* Badges */}
      <section 
        ref={badgesRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Your Badges</h2>
        {badges.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Badges would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<Award className="h-6 w-6 text-muted-foreground" />}
            title="No badges earned yet"
            description="Complete training modules to earn recognition badges"
            action={null}
          />
        )}
      </section>

      {/* All Modules */}
      <section ref={ref}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">All Training Modules</h2>
          {searchQuery || selectedCategory !== "ALL" ? (
            <button 
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("ALL");
              }}
              className="text-sm text-primary hover:text-primary-light"
            >
              Clear filters
            </button>
          ) : null}
        </div>
        
        {trainingModules.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Training modules would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<BookOpen className="h-6 w-6 text-muted-foreground" />}
            title="No training modules available"
            description="Training modules will be added soon. Check back later."
            action={
              <Link href="/dashboard" className="btn-primary inline-flex items-center">
                <PlusCircle className="h-5 w-5 mr-2" />
                Return to Dashboard
              </Link>
            }
          />
        )}
      </section>
    </div>
  );
}