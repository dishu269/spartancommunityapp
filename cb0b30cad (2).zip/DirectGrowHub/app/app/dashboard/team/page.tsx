"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Link from "next/link";
import { 
  Users, 
  Search, 
  Filter, 
  ChevronDown, 
  BarChart, 
  Award, 
  TrendingUp,
  UserPlus,
  BookOpen
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import EmptyState from "@/components/empty-state";

export default function TeamPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("ALL");
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [statsRef, statsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [count, setCount] = useState({ 
    totalMembers: 0, 
    totalEarnings: 0, 
    totalLeads: 0,
    completionRate: 0
  });

  // Empty state for team members
  const teamMembers: any[] = [];

  // Team performance data - would come from API in real implementation
  const teamPerformance = {
    totalMembers: 0,
    activeMembers: 0,
    onboardingMembers: 0,
    totalEarnings: 0,
    totalLeads: 0,
    completionRate: 0,
  };

  // Simulate counting animation for stats
  useState(() => {
    if (statsInView) {
      const interval = setInterval(() => {
        setCount(prev => ({
          totalMembers: prev.totalMembers >= teamPerformance.totalMembers ? 
            teamPerformance.totalMembers : prev.totalMembers + 1,
          totalEarnings: prev.totalEarnings >= teamPerformance.totalEarnings ? 
            teamPerformance.totalEarnings : prev.totalEarnings + 1000,
          totalLeads: prev.totalLeads >= teamPerformance.totalLeads ? 
            teamPerformance.totalLeads : prev.totalLeads + 1,
          completionRate: prev.completionRate >= teamPerformance.completionRate ? 
            teamPerformance.completionRate : prev.completionRate + 1,
        }));
      }, 50);
      
      return () => clearInterval(interval);
    }
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Team Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Monitor and support your team's growth
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Link href="/dashboard/referrals" className="btn-primary flex items-center">
              <UserPlus className="h-5 w-5 mr-2" />
              Invite Team Member
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Team Performance Stats */}
      <section 
        ref={statsRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Team Performance</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-full mr-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Team Members</p>
                <h3 className="text-2xl font-bold">{count.totalMembers}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-full mr-4">
                <TrendingUp className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Earnings</p>
                <h3 className="text-2xl font-bold">{formatCurrency(count.totalEarnings)}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-success/10 rounded-full mr-4">
                <BarChart className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Leads</p>
                <h3 className="text-2xl font-bold">{count.totalLeads}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-warning/10 rounded-full mr-4">
                <BookOpen className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Training Completion</p>
                <h3 className="text-2xl font-bold">{count.completionRate}%</h3>
              </div>
            </div>
            <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-warning rounded-full"
                style={{ width: `${count.completionRate}%` }}
              ></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Team Members List */}
      <section ref={ref}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Team Members</h2>
          <div className="mt-3 md:mt-0 flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative flex-1 sm:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-muted-foreground" />
              </div>
              <input
                type="text"
                placeholder="Search members..."
                className="input pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="relative w-full sm:w-40">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-muted-foreground" />
              </div>
              <select
                className="input pl-10 pr-10 appearance-none w-full"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="ALL">All Status</option>
                <option value="ACTIVE">Active</option>
                <option value="ONBOARDING">Onboarding</option>
                <option value="INACTIVE">Inactive</option>
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </div>
        </div>
        
        {teamMembers.length > 0 ? (
          <div className="space-y-4">
            {/* Team member items would go here */}
          </div>
        ) : (
          <EmptyState
            icon={<Users className="h-6 w-6 text-muted-foreground" />}
            title="No team members found"
            description="Start building your team by inviting new members"
            action={
              <Link href="/dashboard/referrals" className="btn-primary inline-flex items-center">
                <UserPlus className="h-5 w-5 mr-2" />
                Invite Team Member
              </Link>
            }
          />
        )}
      </section>
    </div>
  );
}