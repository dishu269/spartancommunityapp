"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { 
  HelpCircle, 
  Book, 
  Video, 
  Users, 
  FileText, 
  Settings, 
  BarChart, 
  Bell, 
  Calendar,
  Search,
  ChevronRight,
  ExternalLink,
  ArrowRight
} from "lucide-react";

const helpTopics = [
  {
    id: "dashboard",
    title: "Dashboard",
    icon: <BarChart className="h-5 w-5" />,
    description: "Learn how to use the admin dashboard and interpret analytics",
  },
  {
    id: "users",
    title: "User Management",
    icon: <Users className="h-5 w-5" />,
    description: "Manage distributors, leaders, and admin accounts",
  },
  {
    id: "content",
    title: "Content Management",
    icon: <FileText className="h-5 w-5" />,
    description: "Upload and manage training materials and resources",
  },
  {
    id: "videos",
    title: "Video Management",
    icon: <Video className="h-5 w-5" />,
    description: "Add and manage introduction and training videos",
    new: true,
  },
  {
    id: "notifications",
    title: "Notifications",
    icon: <Bell className="h-5 w-5" />,
    description: "Send announcements and alerts to users",
  },
  {
    id: "events",
    title: "Events",
    icon: <Calendar className="h-5 w-5" />,
    description: "Schedule and manage training events and webinars",
  },
  {
    id: "settings",
    title: "Settings",
    icon: <Settings className="h-5 w-5" />,
    description: "Configure application settings and preferences",
  },
];

export default function AdminHelpPage() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredTopics = helpTopics.filter(topic => 
    topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Admin Help Center
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Documentation and tutorials for Spartan Community India administrators
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Link href="/admin/dashboard" className="btn-primary flex items-center">
              <ArrowRight className="h-5 w-5 mr-2" />
              Back to Dashboard
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Search Section */}
      <section className="mb-8">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            placeholder="Search help topics..."
            className="input pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </section>

      {/* Quick Start Guide */}
      <section className="mb-8">
        <div className="card p-6 bg-gradient-to-r from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10">
          <div className="flex flex-col md:flex-row md:items-center">
            <div className="mb-4 md:mb-0 md:mr-6">
              <div className="bg-primary/20 p-3 rounded-full inline-block">
                <Book className="h-8 w-8 text-primary" />
              </div>
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-semibold mb-2">Quick Start Guide</h2>
              <p className="text-muted-foreground mb-4">
                New to the admin panel? This guide will help you get started with the basic features and functionality.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/admin/help/getting-started" className="btn-primary text-sm">
                  Getting Started
                </Link>
                <Link href="/admin/help/video-tutorial" className="btn-outline text-sm flex items-center">
                  <Video className="h-4 w-4 mr-1" />
                  Watch Tutorial
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Help Topics */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Help Topics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTopics.map((topic, index) => (
            <motion.div
              key={topic.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="relative"
            >
              <Link href={`/admin/help/${topic.id}`}>
                <div className="card p-6 hover:shadow-md transition-all duration-300 h-full">
                  <div className="flex items-start">
                    <div className="p-2 bg-primary/10 rounded-md mr-3">
                      {topic.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium mb-1 flex items-center">
                        {topic.title}
                        {topic.new && (
                          <span className="ml-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 text-xs px-2 py-0.5 rounded-full">
                            New
                          </span>
                        )}
                      </h3>
                      <p className="text-sm text-muted-foreground">{topic.description}</p>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Video Management Help */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Video Management Guide</h2>
        <div className="card p-6 border-2 border-red-200 dark:border-red-800/30">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/3 mb-4 md:mb-0 md:mr-6">
              <div className="bg-red-100 dark:bg-red-900/20 p-4 rounded-lg flex items-center justify-center h-full">
                <Video className="h-16 w-16 text-red-500" />
              </div>
            </div>
            <div className="md:w-2/3">
              <div className="flex items-center mb-2">
                <h3 className="text-lg font-semibold">Managing Introduction Videos</h3>
                <span className="ml-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 text-xs px-2 py-0.5 rounded-full">
                  New Feature
                </span>
              </div>
              <p className="text-muted-foreground mb-4">
                Learn how to add, edit, and manage introduction videos that will be shown to users during onboarding and training.
              </p>
              <div className="space-y-3">
                <div className="flex items-start">
                  <div className="bg-red-100 dark:bg-red-900/20 p-1 rounded-full mr-2 mt-0.5">
                    <span className="text-xs font-bold text-red-800 dark:text-red-300">1</span>
                  </div>
                  <p className="text-sm">Upload YouTube videos through the admin video management panel</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-red-100 dark:bg-red-900/20 p-1 rounded-full mr-2 mt-0.5">
                    <span className="text-xs font-bold text-red-800 dark:text-red-300">2</span>
                  </div>
                  <p className="text-sm">Set video titles, descriptions, and categories</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-red-100 dark:bg-red-900/20 p-1 rounded-full mr-2 mt-0.5">
                    <span className="text-xs font-bold text-red-800 dark:text-red-300">3</span>
                  </div>
                  <p className="text-sm">Activate or deactivate videos as needed</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-border">
                <Link href="/admin/help/videos" className="btn-primary bg-red-500 hover:bg-red-600 text-sm flex items-center w-fit">
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Read Full Documentation
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Support */}
      <section>
        <div className="card p-6 bg-muted/50">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-semibold mb-2">Need Additional Help?</h2>
              <p className="text-muted-foreground">
                Contact our support team for personalized assistance with any admin-related questions.
              </p>
            </div>
            <div>
              <Link href="/admin/support" className="btn-primary">
                <HelpCircle className="h-5 w-5 mr-2" />
                Contact Support
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}