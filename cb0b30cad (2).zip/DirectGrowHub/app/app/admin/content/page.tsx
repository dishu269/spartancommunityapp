"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Link from "next/link";
import { 
  FileText, 
  Video, 
  Image as ImageIcon, 
  Link as LinkIcon, 
  FileSpreadsheet, 
  Presentation, 
  Plus, 
  Search, 
  Filter, 
  ChevronDown, 
  MoreHorizontal, 
  Trash2, 
  Edit, 
  Eye, 
  Download,
  Upload
} from "lucide-react";

// Mock data for content items
const contentItems = [
  {
    id: "1",
    title: "Company Overview Presentation",
    description: "Introduction to our company, mission, and values",
    type: "PRESENTATION",
    format: "PPT",
    size: "2.4 MB",
    uploadedBy: "Priya Admin",
    uploadedAt: "2 days ago",
    downloads: 45,
    views: 120,
  },
  {
    id: "2",
    title: "Product Catalog 2024",
    description: "Complete catalog of all products with pricing",
    type: "DOCUMENT",
    format: "PDF",
    size: "5.1 MB",
    uploadedBy: "Priya Admin",
    uploadedAt: "1 week ago",
    downloads: 78,
    views: 210,
  },
  {
    id: "3",
    title: "Sales Training Video",
    description: "Learn effective sales techniques for our products",
    type: "VIDEO",
    format: "MP4",
    size: "45.8 MB",
    uploadedBy: "Arjun Leader",
    uploadedAt: "2 weeks ago",
    downloads: 0,
    views: 156,
  },
  {
    id: "4",
    title: "Compensation Plan Calculator",
    description: "Calculate earnings based on sales and team performance",
    type: "SPREADSHEET",
    format: "XLSX",
    size: "1.2 MB",
    uploadedBy: "Priya Admin",
    uploadedAt: "3 weeks ago",
    downloads: 92,
    views: 180,
  },
  {
    id: "5",
    title: "Social Media Marketing Guide",
    description: "Best practices for promoting products on social media",
    type: "DOCUMENT",
    format: "PDF",
    size: "3.7 MB",
    uploadedBy: "Priya Admin",
    uploadedAt: "1 month ago",
    downloads: 65,
    views: 145,
  },
  {
    id: "6",
    title: "Company Website",
    description: "Official website with product information",
    type: "LINK",
    format: "URL",
    size: "-",
    uploadedBy: "Priya Admin",
    uploadedAt: "1 month ago",
    downloads: 0,
    views: 230,
  },
];

const typeIcons = {
  DOCUMENT: <FileText className="h-6 w-6 text-blue-500" />,
  VIDEO: <Video className="h-6 w-6 text-red-500" />,
  IMAGE: <ImageIcon className="h-6 w-6 text-green-500" />,
  LINK: <LinkIcon className="h-6 w-6 text-purple-500" />,
  SPREADSHEET: <FileSpreadsheet className="h-6 w-6 text-green-600" />,
  PRESENTATION: <Presentation className="h-6 w-6 text-orange-500" />,
};

const formatColors = {
  PDF: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  DOCX: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  XLSX: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  PPT: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  MP4: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  JPG: "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300",
  PNG: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
  URL: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300",
};

export default function ContentManagementPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("ALL");
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  // Filter content items based on search and type
  const filteredItems = contentItems.filter((item) => {
    const matchesSearch = 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "ALL" || item.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Content Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Upload and manage training materials and resources
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              onClick={() => setIsUploadModalOpen(true)}
              className="btn-primary flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Upload Content
            </button>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search content..."
              className="input pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter className="h-5 w-5 text-muted-foreground" />
            </div>
            <select
              className="input pl-10 pr-10 appearance-none"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              <option value="ALL">All Types</option>
              <option value="DOCUMENT">Documents</option>
              <option value="VIDEO">Videos</option>
              <option value="IMAGE">Images</option>
              <option value="SPREADSHEET">Spreadsheets</option>
              <option value="PRESENTATION">Presentations</option>
              <option value="LINK">Links</option>
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown className="h-5 w-5 text-muted-foreground" />
            </div>
          </div>
        </div>
      </section>

      {/* Content List */}
      <section ref={ref}>
        {filteredItems.length > 0 ? (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">Content</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Format</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Size</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Uploaded</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Stats</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredItems.map((item, index) => (
                    <motion.tr 
                      key={item.id}
                      className="hover:bg-muted/30 transition-colors duration-150"
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-start">
                          <div className="p-2 bg-muted/50 rounded-md mr-3">
                            {typeIcons[item.type as keyof typeof typeIcons]}
                          </div>
                          <div>
                            <p className="font-medium">{item.title}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${formatColors[item.format as keyof typeof formatColors]}`}>
                          {item.format}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {item.size}
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm">{item.uploadedBy}</p>
                        <p className="text-xs text-muted-foreground">{item.uploadedAt}</p>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center">
                            <Eye className="h-4 w-4 text-muted-foreground mr-1" />
                            <span className="text-sm">{item.views}</span>
                          </div>
                          {item.type !== "LINK" && item.type !== "VIDEO" && (
                            <div className="flex items-center">
                              <Download className="h-4 w-4 text-muted-foreground mr-1" />
                              <span className="text-sm">{item.downloads}</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          {item.type === "LINK" ? (
                            <a 
                              href="#" 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="p-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded transition-colors duration-200"
                            >
                              <LinkIcon className="h-4 w-4" />
                            </a>
                          ) : (
                            <button className="p-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded transition-colors duration-200">
                              <Download className="h-4 w-4" />
                            </button>
                          )}
                          <button className="p-1.5 bg-muted hover:bg-muted/80 rounded transition-colors duration-200">
                            <Edit className="h-4 w-4" />
                          </button>
                          <button className="p-1.5 bg-danger/10 text-danger hover:bg-danger/20 rounded transition-colors duration-200">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="card p-8 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-lg font-medium mb-2">No content found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filter criteria</p>
            <button 
              onClick={() => setIsUploadModalOpen(true)}
              className="btn-primary inline-flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Upload New Content
            </button>
          </div>
        )}
      </section>

      {/* Upload Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div 
            className="bg-white dark:bg-muted rounded-lg shadow-xl w-full max-w-md"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-4">Upload Content</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium mb-1">
                    Title
                  </label>
                  <input
                    id="title"
                    type="text"
                    className="input"
                    placeholder="Enter content title"
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    className="input min-h-[80px]"
                    placeholder="Enter content description"
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="contentType" className="block text-sm font-medium mb-1">
                    Content Type
                  </label>
                  <select
                    id="contentType"
                    className="input"
                  >
                    <option value="">Select content type</option>
                    <option value="DOCUMENT">Document</option>
                    <option value="VIDEO">Video</option>
                    <option value="IMAGE">Image</option>
                    <option value="SPREADSHEET">Spreadsheet</option>
                    <option value="PRESENTATION">Presentation</option>
                    <option value="LINK">Link</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Upload File or Enter URL
                  </label>
                  <div className="border-2 border-dashed border-input rounded-lg p-8 text-center">
                    <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drag and drop your file here, or click to browse
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Supports PDF, DOCX, XLSX, PPT, MP4, JPG, PNG (Max 50MB)
                    </p>
                    <input
                      type="file"
                      className="hidden"
                      id="fileUpload"
                    />
                    <button className="btn-outline text-sm mt-4">
                      Browse Files
                    </button>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="url" className="block text-sm font-medium mb-1">
                    Or Enter URL
                  </label>
                  <input
                    id="url"
                    type="url"
                    className="input"
                    placeholder="https://example.com"
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button 
                  onClick={() => setIsUploadModalOpen(false)}
                  className="btn-outline"
                >
                  Cancel
                </button>
                <button className="btn-primary">
                  Upload
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}