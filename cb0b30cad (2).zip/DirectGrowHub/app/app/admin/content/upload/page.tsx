"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { 
  FileText, 
  Video, 
  Image as ImageIcon, 
  Link as LinkIcon, 
  FileSpreadsheet, 
  Presentation, 
  Upload,
  AlertCircle,
  CheckCircle,
  ArrowLeft
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

// Content upload schema with validation
const contentSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  type: z.enum(["DOCUMENT", "VIDEO", "IMAGE", "LINK", "SPREADSHEET", "PRESENTATION"], {
    errorMap: () => ({ message: "Please select a content type" }),
  }),
  format: z.string().optional(),
  url: z.string().url("Please enter a valid URL"),
  fileSize: z.string().optional(),
});

type ContentFormValues = z.infer<typeof contentSchema>;

export default function ContentUploadPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<ContentFormValues>({
    resolver: zodResolver(contentSchema),
    defaultValues: {
      title: "",
      description: "",
      type: undefined,
      format: "",
      url: "",
      fileSize: "",
    },
  });
  
  const selectedType = watch("type");
  
  const typeIcons = {
    DOCUMENT: <FileText className="h-6 w-6 text-blue-500" />,
    VIDEO: <Video className="h-6 w-6 text-red-500" />,
    IMAGE: <ImageIcon className="h-6 w-6 text-green-500" />,
    LINK: <LinkIcon className="h-6 w-6 text-purple-500" />,
    SPREADSHEET: <FileSpreadsheet className="h-6 w-6 text-green-600" />,
    PRESENTATION: <Presentation className="h-6 w-6 text-orange-500" />,
  };
  
  const formatOptions = {
    DOCUMENT: ["PDF", "DOCX"],
    VIDEO: ["MP4", "MOV", "AVI"],
    IMAGE: ["JPG", "PNG", "GIF"],
    LINK: ["URL"],
    SPREADSHEET: ["XLSX", "CSV"],
    PRESENTATION: ["PPT", "PPTX"],
  };
  
  const onSubmit = async (data: ContentFormValues) => {
    setIsSubmitting(true);
    
    try {
      console.log("Submitting content:", data);
      
      const response = await fetch("/api/admin/content", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        console.error("Content upload failed:", result);
        toast({
          title: "Upload failed",
          description: result.message || "Failed to upload content. Please try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }
      
      console.log("Content uploaded successfully:", result);
      
      toast({
        title: "Content uploaded",
        description: "Your content has been uploaded successfully.",
        variant: "success",
      });
      
      // Redirect to content management page
      router.push("/admin/content");
    } catch (error) {
      console.error("Content upload error:", error);
      toast({
        title: "Upload error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-6">
        <button
          onClick={() => router.back()}
          className="flex items-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back
        </button>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="card p-6">
          <h1 className="text-2xl font-bold mb-6">Upload New Content</h1>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium mb-1">
                Title*
              </label>
              <input
                id="title"
                type="text"
                className={`input ${errors.title ? "border-danger focus:ring-danger" : ""}`}
                placeholder="Enter content title"
                {...register("title")}
                disabled={isSubmitting}
              />
              {errors.title && (
                <p className="mt-1 text-sm text-danger">{errors.title.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium mb-1">
                Description
              </label>
              <textarea
                id="description"
                className="input min-h-[100px]"
                placeholder="Enter content description"
                {...register("description")}
                disabled={isSubmitting}
              ></textarea>
            </div>
            
            <div>
              <label htmlFor="type" className="block text-sm font-medium mb-1">
                Content Type*
              </label>
              <select
                id="type"
                className={`input ${errors.type ? "border-danger focus:ring-danger" : ""}`}
                {...register("type")}
                disabled={isSubmitting}
              >
                <option value="">Select content type</option>
                <option value="DOCUMENT">Document</option>
                <option value="VIDEO">Video</option>
                <option value="IMAGE">Image</option>
                <option value="SPREADSHEET">Spreadsheet</option>
                <option value="PRESENTATION">Presentation</option>
                <option value="LINK">Link</option>
              </select>
              {errors.type && (
                <p className="mt-1 text-sm text-danger">{errors.type.message}</p>
              )}
            </div>
            
            {selectedType && (
              <div>
                <label htmlFor="format" className="block text-sm font-medium mb-1">
                  Format
                </label>
                <select
                  id="format"
                  className="input"
                  {...register("format")}
                  disabled={isSubmitting}
                >
                  <option value="">Select format</option>
                  {formatOptions[selectedType as keyof typeof formatOptions]?.map((format) => (
                    <option key={format} value={format}>
                      {format}
                    </option>
                  ))}
                </select>
              </div>
            )}
            
            <div>
              <label htmlFor="url" className="block text-sm font-medium mb-1">
                URL*
              </label>
              <input
                id="url"
                type="url"
                className={`input ${errors.url ? "border-danger focus:ring-danger" : ""}`}
                placeholder="https://example.com/content"
                {...register("url")}
                disabled={isSubmitting}
              />
              {errors.url && (
                <p className="mt-1 text-sm text-danger">{errors.url.message}</p>
              )}
              <p className="mt-1 text-xs text-muted-foreground">
                Enter the URL where the content is hosted. For videos, use YouTube or Vimeo links.
              </p>
            </div>
            
            <div>
              <label htmlFor="fileSize" className="block text-sm font-medium mb-1">
                File Size
              </label>
              <input
                id="fileSize"
                type="text"
                className="input"
                placeholder="e.g., 2.5 MB"
                {...register("fileSize")}
                disabled={isSubmitting}
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Optional: Enter the file size for downloadable content.
              </p>
            </div>
            
            <div className="pt-4 border-t border-border">
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => router.back()}
                  className="btn-outline"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary flex items-center"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Content
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </motion.div>
      
      {/* Help Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-6"
      >
        <div className="card bg-muted/50 p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <AlertCircle className="h-5 w-5 text-primary mr-2" />
            Content Upload Guidelines
          </h2>
          
          <ul className="space-y-3">
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-success mr-2 mt-1" />
              <span className="text-sm">
                <strong>Documents:</strong> Upload PDF or DOCX files for training materials, guides, or policies.
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-success mr-2 mt-1" />
              <span className="text-sm">
                <strong>Videos:</strong> Use YouTube or Vimeo links for better streaming performance.
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-success mr-2 mt-1" />
              <span className="text-sm">
                <strong>Images:</strong> Ensure images are high quality but optimized for mobile viewing.
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-success mr-2 mt-1" />
              <span className="text-sm">
                <strong>Links:</strong> Provide descriptive titles and descriptions for external resources.
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-success mr-2 mt-1" />
              <span className="text-sm">
                <strong>File Size:</strong> Keep files under 50MB for better user experience on mobile devices.
              </span>
            </li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
}