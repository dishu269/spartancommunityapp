"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import Link from "next/link";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import { 
  Users, 
  BookOpen, 
  BarChart, 
  TrendingUp, 
  Calendar, 
  ArrowUpRight,
  Download,
  Filter,
  ChevronDown,
  Search,
  Video,
  FileText,
  Settings,
  Bell,
  HelpCircle,
  UserPlus,
  MessageSquare,
  Shield,
  Zap,
  Award,
  PlusCircle
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/auth-context";
import { UserRole } from "@/lib/types";

// Dynamically import Chart components with SSR disabled
const LineChart = dynamic(
  () => import('react-chartjs-2').then(mod => mod.Line),
  { ssr: false, loading: () => <div className="h-64 w-full flex items-center justify-center bg-muted/50 rounded-lg">Loading chart...</div> }
);

const BarChartComponent = dynamic(
  () => import('react-chartjs-2').then(mod => mod.Bar),
  { ssr: false, loading: () => <div className="h-64 w-full flex items-center justify-center bg-muted/50 rounded-lg">Loading chart...</div> }
);

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// Mock data for admin dashboard
const teamGrowthData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  datasets: [
    {
      label: 'New Distributors',
      data: [12, 19, 15, 22, 35, 40, 42, 50, 55, 60, 70, 75],
      borderColor: 'rgb(59, 130, 246)',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      tension: 0.4,
      fill: true,
    },
  ],
};

const teamPerformanceData = {
  labels: ['Training Completion', 'Lead Generation', 'Conversion Rate', 'Team Building', 'Earnings'],
  datasets: [
    {
      label: 'Team Average',
      data: [65, 72, 58, 45, 80],
      backgroundColor: 'rgba(59, 130, 246, 0.7)',
    },
    {
      label: 'Industry Benchmark',
      data: [70, 60, 65, 50, 75],
      backgroundColor: 'rgba(249, 115, 22, 0.7)',
    },
  ],
};

const recentRegistrations = [
  {
    id: "1",
    name: "Ananya Desai",
    email: "ananya.d@example.com",
    phone: "+91 9876543220",
    joinedDate: "2 days ago",
    status: "ACTIVE",
    avatar: "/Screenshot 2025-05-24 003353.png",
  },
  {
    id: "2",
    name: "Vikram Malhotra",
    email: "vikram.m@example.com",
    phone: "+91 9876543221",
    joinedDate: "3 days ago",
    status: "ONBOARDING",
    avatar: "/Screenshot 2025-05-24 001253.png",
  },
  {
    id: "3",
    name: "Deepika Reddy",
    email: "deepika.r@example.com",
    phone: "+91 9876543222",
    joinedDate: "1 week ago",
    status: "ACTIVE",
    avatar: "/image.png",
  },
];

const upcomingTrainings = [
  {
    id: "1",
    title: "Social Media Marketing Masterclass",
    date: "Tomorrow, 3:00 PM",
    attendees: 25,
    type: "WEBINAR",
  },
  {
    id: "2",
    title: "Product Knowledge Update",
    date: "Wed, 11:00 AM",
    attendees: 42,
    type: "TRAINING",
  },
  {
    id: "3",
    title: "Compliance Guidelines 2024",
    date: "Fri, 2:30 PM",
    attendees: 38,
    type: "MANDATORY",
  },
];

const statusColors = {
  ACTIVE: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  ONBOARDING: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  INACTIVE: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const trainingTypeColors = {
  WEBINAR: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  TRAINING: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  MANDATORY: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

// Admin feature panel data
const adminFeatures = [
  {
    title: "User Management",
    description: "Manage distributors, leaders, and admins",
    icon: <Users className="h-6 w-6 text-white" />,
    href: "/admin/users",
    color: "bg-blue-500 hover:bg-blue-600",
  },
  {
    title: "Content Management",
    description: "Upload and manage training materials",
    icon: <FileText className="h-6 w-6 text-white" />,
    href: "/admin/content",
    color: "bg-purple-500 hover:bg-purple-600",
  },
  {
    title: "Video Management",
    description: "Manage introduction and training videos",
    icon: <Video className="h-6 w-6 text-white" />,
    href: "/admin/videos",
    color: "bg-red-500 hover:bg-red-600",
    new: true,
  },
  {
    title: "Analytics",
    description: "Track team growth and performance",
    icon: <BarChart className="h-6 w-6 text-white" />,
    href: "/admin/analytics",
    color: "bg-green-500 hover:bg-green-600",
  },
  {
    title: "Notifications",
    description: "Send announcements and alerts",
    icon: <Bell className="h-6 w-6 text-white" />,
    href: "/admin/notifications",
    color: "bg-yellow-500 hover:bg-yellow-600",
  },
  {
    title: "Events",
    description: "Schedule and manage training events",
    icon: <Calendar className="h-6 w-6 text-white" />,
    href: "/admin/events",
    color: "bg-indigo-500 hover:bg-indigo-600",
  },
  {
    title: "Compliance",
    description: "Manage policies and compliance",
    icon: <Shield className="h-6 w-6 text-white" />,
    href: "/admin/compliance",
    color: "bg-teal-500 hover:bg-teal-600",
  },
  {
    title: "Settings",
    description: "Configure application settings",
    icon: <Settings className="h-6 w-6 text-white" />,
    href: "/admin/settings",
    color: "bg-gray-500 hover:bg-gray-600",
  },
];

export default function AdminDashboardPage() {
  const [statsRef, statsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [chartsRef, chartsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [featuresRef, featuresInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [count, setCount] = useState({ 
    totalDistributors: 0, 
    activeDistributors: 0, 
    totalRevenue: 0,
    completionRate: 0
  });

  const { toast } = useToast();
  const { user, isLoading } = useAuth();
  const router = useRouter();

  // Debug logging
  console.log("Admin Dashboard rendering, auth state:", { user, isLoading });

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        console.log("User not authenticated, redirecting to admin login");
        router.push("/auth/admin-login");
      } else if (user.role !== UserRole.ADMIN) {
        console.log("User not admin, redirecting to dashboard");
        router.push("/dashboard");
      }
    }
  }, [user, isLoading, router]);

  // Simulate counting animation for stats
  useEffect(() => {
    if (statsInView) {
      const interval = setInterval(() => {
        setCount(prev => ({
          totalDistributors: prev.totalDistributors >= 350 ? 350 : prev.totalDistributors + 5,
          activeDistributors: prev.activeDistributors >= 275 ? 275 : prev.activeDistributors + 4,
          totalRevenue: prev.totalRevenue >= 1250000 ? 1250000 : prev.totalRevenue + 20000,
          completionRate: prev.completionRate >= 68 ? 68 : prev.completionRate + 1,
        }));
      }, 50);
      
      return () => clearInterval(interval);
    }
  }, [statsInView]);

  // Chart options
  const lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
      },
    },
  };

  const showTooltip = (title: string, description: string) => {
    toast({
      title,
      description
    });
  };

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Fallback if authentication state is lost or user is not admin
  if (!user || user.role !== UserRole.ADMIN) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="card p-8 text-center">
          <h2 className="text-xl font-semibold mb-4">Admin Authentication Required</h2>
          <p className="text-muted-foreground mb-6">
            You need to be logged in as an admin to access this page.
          </p>
          <Link href="/auth/admin-login" className="btn-primary">
            Go to Admin Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Admin Dashboard
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Welcome to the Spartan Community India admin panel, {user.name.split(' ')[0]}
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0 flex gap-3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              className="btn-outline flex items-center"
              onClick={() => showTooltip("Help Center", "Access admin documentation and tutorials")}
            >
              <HelpCircle className="h-5 w-5 mr-2" />
              Help
            </button>
            <Link href="/admin/settings" className="btn-primary">
              <Settings className="h-5 w-5 mr-2" />
              Settings
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Admin Feature Panel */}
      <section 
        ref={featuresRef}
        className="mb-8"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Admin Features</h2>
          <button 
            className="text-sm text-primary flex items-center"
            onClick={() => showTooltip("Admin Features", "Quick access to all administrative functions")}
          >
            <HelpCircle className="h-4 w-4 mr-1" />
            Help
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {adminFeatures.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={featuresInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="relative"
            >
              <Link href={feature.href}>
                <div className={`rounded-lg p-6 transition-all duration-300 ${feature.color} h-full`}>
                  <div className="flex flex-col h-full">
                    <div className="bg-white/20 p-3 rounded-full w-fit mb-4">
                      {feature.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                    <p className="text-white/80 text-sm">{feature.description}</p>
                  </div>
                </div>
              </Link>
              {feature.new && (
                <div className="absolute top-2 right-2 bg-white text-red-500 px-2 py-0.5 rounded-full text-xs font-bold animate-pulse">
                  NEW
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ y: -4 }}
          >
            <Link href="/admin/users/add">
              <div className="card hover:shadow-md transition-all duration-300 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-800/30">
                <div className="flex items-start">
                  <div className="p-3 bg-blue-500 text-white rounded-lg mr-4">
                    <UserPlus className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Add New User</h3>
                    <p className="text-sm text-muted-foreground">Create a new distributor or leader account</p>
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            whileHover={{ y: -4 }}
          >
            <Link href="/admin/videos/add">
              <div className="card hover:shadow-md transition-all duration-300 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 border-red-200 dark:border-red-800/30">
                <div className="flex items-start">
                  <div className="p-3 bg-red-500 text-white rounded-lg mr-4">
                    <Video className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Upload Video</h3>
                    <p className="text-sm text-muted-foreground">Add a new introduction or training video</p>
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
            whileHover={{ y: -4 }}
          >
            <Link href="/admin/notifications/send">
              <div className="card hover:shadow-md transition-all duration-300 bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20 border-yellow-200 dark:border-yellow-800/30">
                <div className="flex items-start">
                  <div className="p-3 bg-yellow-500 text-white rounded-lg mr-4">
                    <Bell className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Send Notification</h3>
                    <p className="text-sm text-muted-foreground">Broadcast a message to all users</p>
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section 
        ref={statsRef}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold mb-4">Platform Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-full mr-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Distributors</p>
                <div className="flex items-baseline">
                  <h3 className="text-2xl font-bold">{count.totalDistributors}</h3>
                  <span className="text-sm text-success ml-2 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-0.5" />
                    +12%
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-success/10 rounded-full mr-4">
                <Users className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Distributors</p>
                <div className="flex items-baseline">
                  <h3 className="text-2xl font-bold">{count.activeDistributors}</h3>
                  <span className="text-xs text-muted-foreground ml-2">
                    ({Math.round((count.activeDistributors / (count.totalDistributors || 1)) * 100)}%)
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-full mr-4">
                <TrendingUp className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <h3 className="text-2xl font-bold">{formatCurrency(count.totalRevenue)}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-warning/10 rounded-full mr-4">
                <BookOpen className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Training Completion</p>
                <div className="flex items-baseline">
                  <h3 className="text-2xl font-bold">{count.completionRate}%</h3>
                </div>
              </div>
            </div>
            <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-warning rounded-full"
                style={{ width: `${count.completionRate}%` }}
              ></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Charts Section */}
      <section 
        ref={chartsRef}
        className="mb-8 grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <motion.div 
          className="card p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={chartsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-xl font-semibold mb-4">Team Growth Trend</h2>
          <div className="h-64">
            <LineChart data={teamGrowthData} options={lineChartOptions} />
          </div>
        </motion.div>

        <motion.div 
          className="card p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={chartsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <h2 className="text-xl font-semibold mb-4">Team Performance</h2>
          <div className="h-64">
            <BarChartComponent data={teamPerformanceData} options={barChartOptions} />
          </div>
        </motion.div>
      </section>

      {/* Recent Registrations */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Recent Registrations</h2>
          <Link href="/admin/users" className="text-sm text-primary flex items-center">
            View all <ChevronDown className="h-4 w-4 ml-1" />
          </Link>
        </div>
        
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium">User</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Contact</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Joined</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {recentRegistrations.map((user) => (
                  <tr key={user.id} className="hover:bg-muted/30 transition-colors duration-150">
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        <div className="relative h-10 w-10 rounded-full overflow-hidden mr-3">
                          <Image 
                            src={user.avatar}
                            alt={user.name}
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium">{user.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm">{user.email}</p>
                      <p className="text-xs text-muted-foreground">{user.phone}</p>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      {user.joinedDate}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[user.status as keyof typeof statusColors]}`}>
                        {user.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <Link 
                          href={`/admin/users/${user.id}`}
                          className="px-2 py-1 bg-primary/10 text-primary hover:bg-primary/20 rounded text-xs font-medium transition-colors duration-200"
                        >
                          View
                        </Link>
                        <button className="px-2 py-1 bg-muted hover:bg-muted/80 rounded text-xs font-medium transition-colors duration-200">
                          Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Upcoming Trainings */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Upcoming Trainings</h2>
          <Link href="/admin/content" className="text-sm text-primary flex items-center">
            Manage Content <ChevronDown className="h-4 w-4 ml-1" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingTrainings.map((training) => (
            <motion.div
              key={training.id}
              className="card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              whileHover={{ y: -4 }}
            >
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium">{training.title}</h3>
                    <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-medium ${trainingTypeColors[training.type as keyof typeof trainingTypeColors]}`}>
                      {training.type}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{training.date}</p>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 text-muted-foreground mr-1" />
                    <span className="text-sm">{training.attendees} attendees</span>
                  </div>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-border flex justify-between">
                <Link 
                  href={`/admin/trainings/${training.id}`}
                  className="text-primary hover:text-primary-light text-sm font-medium"
                >
                  View Details
                </Link>
                <button className="text-muted-foreground hover:text-foreground text-sm font-medium">
                  Send Reminder
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Admin Help Section */}
      <section className="mt-8">
        <div className="card bg-gradient-to-r from-primary/10 to-secondary/10 dark:from-primary/20 dark:to-secondary/20">
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-semibold mb-2">Need Help with Admin Features?</h2>
                <p className="text-muted-foreground">
                  Access our comprehensive admin documentation and tutorials to learn more about managing the platform.
                </p>
              </div>
              <div className="flex space-x-3">
                <Link href="/admin/help" className="btn-outline">
                  <HelpCircle className="h-5 w-5 mr-2" />
                  View Docs
                </Link>
                <button 
                  className="btn-primary"
                  onClick={() => showTooltip("Admin Tutorial", "Interactive tutorial will guide you through all admin features")}
                >
                  <Zap className="h-5 w-5 mr-2" />
                  Start Tutorial
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}