"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Link from "next/link";
import { 
  Share2, 
  Users, 
  ArrowUpRight, 
  BarChart, 
  Search, 
  ChevronDown, 
  ChevronUp,
  Download,
  Filter,
  RefreshCw,
  User,
  Mail,
  Calendar,
  ExternalLink
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { formatDate } from "@/lib/utils";

export default function AdminReferralsPage() {
  const [referrals, setReferrals] = useState<any[]>([]);
  const [statistics, setStatistics] = useState({
    totalClicks: 0,
    totalConversions: 0,
    conversionRate: 0,
  });
  const [topReferrers, setTopReferrers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState("clicks");
  const [sortOrder, setSortOrder] = useState("desc");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  const [statsRef, statsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  // Fetch referrals data
  const fetchReferrals = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch(`/api/admin/referrals?sortBy=${sortBy}&order=${sortOrder}`);
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        setError(result.message || "Failed to fetch referrals");
        toast({
          title: "Error",
          description: result.message || "Failed to fetch referrals",
          variant: "destructive",
        });
        return;
      }
      
      setReferrals(result.data.referrals);
      setStatistics(result.data.statistics);
      setTopReferrers(result.data.topReferrers);
    } catch (error) {
      console.error("Error fetching referrals:", error);
      setError("An unexpected error occurred. Please try again.");
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Initial fetch
  useEffect(() => {
    fetchReferrals();
  }, [sortBy, sortOrder]);
  
  // Handle sort change
  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("desc");
    }
  };
  
  // Filter referrals by search query
  const filteredReferrals = referrals.filter((referral) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      referral.code.toLowerCase().includes(searchLower) ||
      referral.referrer.name.toLowerCase().includes(searchLower) ||
      (referral.referredUser && referral.referredUser.name.toLowerCase().includes(searchLower))
    );
  });
  
  // Export referrals as CSV
  const exportReferrals = () => {
    // Create CSV content
    const headers = ["Code", "Referrer", "Referrer Email", "Clicks", "Conversions", "Conversion Rate", "Created At"];
    const rows = filteredReferrals.map((referral) => [
      referral.code,
      referral.referrer.name,
      referral.referrer.email,
      referral.clicks,
      referral.conversions,
      referral.clicks > 0 ? ((referral.conversions / referral.clicks) * 100).toFixed(2) + "%" : "0%",
      new Date(referral.createdAt).toLocaleDateString(),
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");
    
    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `referrals_export_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Export successful",
      description: "Referrals data has been exported as CSV",
      variant: "success",
    });
  };
  
  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Referral Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Track and analyze referral performance across the platform
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0 flex gap-3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              onClick={exportReferrals}
              className="btn-outline flex items-center"
              disabled={isLoading || referrals.length === 0}
            >
              <Download className="h-5 w-5 mr-2" />
              Export CSV
            </button>
            <button 
              onClick={fetchReferrals}
              className="btn-primary flex items-center"
              disabled={isLoading}
            >
              <RefreshCw className={`h-5 w-5 mr-2 ${isLoading ? "animate-spin" : ""}`} />
              Refresh Data
            </button>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section 
        ref={statsRef}
        className="mb-8"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-full mr-4">
                <Share2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Clicks</p>
                <h3 className="text-2xl font-bold">{statistics.totalClicks.toLocaleString()}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-success/10 rounded-full mr-4">
                <Users className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Conversions</p>
                <h3 className="text-2xl font-bold">{statistics.totalConversions.toLocaleString()}</h3>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-full mr-4">
                <ArrowUpRight className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <h3 className="text-2xl font-bold">{statistics.conversionRate.toFixed(2)}%</h3>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Top Referrers Section */}
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Top Referrers</h2>
        
        {topReferrers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {topReferrers.map((referrer, index) => (
              <motion.div
                key={referrer.referrerId}
                className="card p-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-3 flex-shrink-0">
                    <User className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium truncate">{referrer.user?.name || "Unknown User"}</h3>
                      <span className="bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full">
                        #{index + 1}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      <Mail className="h-3.5 w-3.5 inline mr-1" />
                      {referrer.user?.email || "No email"}
                    </p>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      <div className="bg-muted/50 p-2 rounded">
                        <p className="text-xs text-muted-foreground">Clicks</p>
                        <p className="font-medium">{referrer._sum.clicks}</p>
                      </div>
                      <div className="bg-muted/50 p-2 rounded">
                        <p className="text-xs text-muted-foreground">Conversions</p>
                        <p className="font-medium">{referrer._sum.conversions}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="card p-6 text-center">
            <BarChart className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-lg font-medium mb-2">No referral data available</h3>
            <p className="text-muted-foreground mb-4">
              There are no referrals in the system yet. Data will appear here once users start sharing their referral links.
            </p>
          </div>
        )}
      </section>

      {/* Referrals List */}
      <section ref={ref}>
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">All Referrals</h2>
          
          <div className="mt-3 md:mt-0 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search referrals..."
              className="input pl-9 py-2 text-sm w-full md:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {isLoading ? (
          <div className="card p-6 flex items-center justify-center">
            <RefreshCw className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="card p-6 text-center">
            <p className="text-danger mb-4">{error}</p>
            <button 
              onClick={fetchReferrals}
              className="btn-primary"
            >
              Try Again
            </button>
          </div>
        ) : filteredReferrals.length > 0 ? (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">
                      <button 
                        className="flex items-center"
                        onClick={() => handleSort("code")}
                      >
                        Code
                        {sortBy === "code" && (
                          sortOrder === "asc" ? 
                            <ChevronUp className="h-4 w-4 ml-1" /> : 
                            <ChevronDown className="h-4 w-4 ml-1" />
                        )}
                      </button>
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Referrer</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">
                      <button 
                        className="flex items-center"
                        onClick={() => handleSort("clicks")}
                      >
                        Clicks
                        {sortBy === "clicks" && (
                          sortOrder === "asc" ? 
                            <ChevronUp className="h-4 w-4 ml-1" /> : 
                            <ChevronDown className="h-4 w-4 ml-1" />
                        )}
                      </button>
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-medium">
                      <button 
                        className="flex items-center"
                        onClick={() => handleSort("conversions")}
                      >
                        Conversions
                        {sortBy === "conversions" && (
                          sortOrder === "asc" ? 
                            <ChevronUp className="h-4 w-4 ml-1" /> : 
                            <ChevronDown className="h-4 w-4 ml-1" />
                        )}
                      </button>
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Rate</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Created</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredReferrals.map((referral) => (
                    <tr key={referral.id} className="hover:bg-muted/30 transition-colors duration-150">
                      <td className="px-4 py-3 text-sm font-medium">
                        {referral.code}
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm font-medium">{referral.referrer.name}</p>
                          <p className="text-xs text-muted-foreground">{referral.referrer.email}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {referral.clicks}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {referral.conversions}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {referral.clicks > 0 ? ((referral.conversions / referral.clicks) * 100).toFixed(2) : 0}%
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex items-center">
                          <Calendar className="h-3.5 w-3.5 text-muted-foreground mr-1" />
                          <span>{formatDate(referral.createdAt)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <a 
                          href={`/ref/${referral.code}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:text-primary-light text-sm font-medium flex items-center"
                        >
                          <ExternalLink className="h-3.5 w-3.5 mr-1" />
                          View
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="card p-6 text-center">
            <Share2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-lg font-medium mb-2">No referrals found</h3>
            <p className="text-muted-foreground">
              {searchQuery ? "No referrals match your search criteria." : "There are no referrals in the system yet."}
            </p>
          </div>
        )}
      </section>
    </div>
  );
}