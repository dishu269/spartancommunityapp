"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { 
  Shield, 
  Lock, 
  Key, 
  Eye, 
  EyeOff, 
  Mail, 
  User, 
  AlertTriangle,
  CheckCircle,
  Smartphone,
  History,
  LogOut
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/components/ui/use-toast";

// Password change form schema with validation
const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type PasswordChangeFormValues = z.infer<typeof passwordChangeSchema>;

// Mock admin user data
const adminUser = {
  name: "Priya Admin",
  email: "priya.admin@example.com",
  role: "ADMIN",
  lastLogin: "Today at 9:30 AM",
  lastPasswordChange: "30 days ago",
  twoFactorEnabled: false,
};

// Mock login sessions
const loginSessions = [
  {
    id: "1",
    device: "Chrome on Windows",
    location: "Mumbai, India",
    ip: "103.25.xx.xx",
    time: "Today at 9:30 AM",
    current: true,
  },
  {
    id: "2",
    device: "Safari on iPhone",
    location: "Delhi, India",
    ip: "122.168.xx.xx",
    time: "Yesterday at 6:15 PM",
    current: false,
  },
  {
    id: "3",
    device: "Chrome on Android",
    location: "Bangalore, India",
    ip: "115.99.xx.xx",
    time: "3 days ago",
    current: false,
  },
];

export default function AdminSecurityPage() {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const { toast } = useToast();
  
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm<PasswordChangeFormValues>({
    resolver: zodResolver(passwordChangeSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Watch the new password to calculate strength
  const newPassword = watch("newPassword");

  // Calculate password strength
  const calculatePasswordStrength = (password: string) => {
    if (!password) return 0;
    
    let strength = 0;
    
    // Length check
    if (password.length >= 8) strength += 1;
    if (password.length >= 12) strength += 1;
    
    // Character type checks
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    // Calculate percentage (max strength is 6)
    return Math.min(Math.floor((strength / 6) * 100), 100);
  };

  // Update password strength when password changes
  useState(() => {
    if (newPassword) {
      setPasswordStrength(calculatePasswordStrength(newPassword));
    } else {
      setPasswordStrength(0);
    }
  });

  const onSubmit = async (data: PasswordChangeFormValues) => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      
      // Check if current password is correct (in a real app, this would be done server-side)
      if (data.currentPassword === "admin123") {
        toast({
          title: "Password changed successfully",
          description: "Your password has been updated. Please use your new password for future logins.",
          variant: "success",
        });
        reset();
      } else {
        toast({
          title: "Current password is incorrect",
          description: "Please enter your current password correctly to proceed.",
          variant: "destructive",
        });
      }
    }, 1500);
  };

  const handleLogoutAllDevices = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Logged out from all devices",
        description: "You have been successfully logged out from all devices except this one.",
        variant: "success",
      });
    }, 1000);
  };

  const handleToggleTwoFactor = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Two-factor authentication enabled",
        description: "You will now receive a verification code on your mobile device when logging in.",
        variant: "success",
      });
    }, 1000);
  };

  const getStrengthColor = () => {
    if (passwordStrength < 40) return "bg-red-500";
    if (passwordStrength < 70) return "bg-yellow-500";
    return "bg-green-500";
  };

  const getStrengthText = () => {
    if (passwordStrength < 40) return "Weak";
    if (passwordStrength < 70) return "Moderate";
    return "Strong";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Security Settings
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Manage your account security and authentication settings
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-primary/10 px-4 py-2 rounded-lg flex items-center">
              <Shield className="h-5 w-5 text-primary mr-2" />
              <span className="text-sm font-medium">Admin Account</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Account Overview */}
      <section className="mb-8">
        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-4">Account Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-medium">{adminUser.name}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{adminUser.email}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Role</p>
                  <p className="font-medium">{adminUser.role}</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <History className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last Login</p>
                  <p className="font-medium">{adminUser.lastLogin}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <Key className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last Password Change</p>
                  <p className="font-medium">{adminUser.lastPasswordChange}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="p-2 bg-muted rounded-md mr-3">
                  <Smartphone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Two-Factor Authentication</p>
                  <p className="font-medium">{adminUser.twoFactorEnabled ? "Enabled" : "Disabled"}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Change Password */}
      <section 
        ref={ref}
        className="mb-8"
      >
        <motion.div 
          className="card p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-xl font-semibold mb-4">Change Password</h2>
          <p className="text-muted-foreground mb-6">
            It's a good practice to change your password regularly to maintain account security.
          </p>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="currentPassword" className="block text-sm font-medium mb-1">
                Current Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="currentPassword"
                  type={showCurrentPassword ? "text" : "password"}
                  className={`input pl-10 ${errors.currentPassword ? "border-danger focus:ring-danger" : ""}`}
                  placeholder="Enter your current password"
                  {...register("currentPassword")}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                >
                  {showCurrentPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
              {errors.currentPassword && (
                <p className="mt-1 text-sm text-danger">{errors.currentPassword.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="newPassword" className="block text-sm font-medium mb-1">
                New Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Key className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="newPassword"
                  type={showNewPassword ? "text" : "password"}
                  className={`input pl-10 ${errors.newPassword ? "border-danger focus:ring-danger" : ""}`}
                  placeholder="Enter your new password"
                  {...register("newPassword")}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                >
                  {showNewPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
              {errors.newPassword && (
                <p className="mt-1 text-sm text-danger">{errors.newPassword.message}</p>
              )}
              
              {/* Password strength meter */}
              {newPassword && (
                <div className="mt-2">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted-foreground">Password Strength</span>
                    <span className="text-xs font-medium">{getStrengthText()}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${getStrengthColor()} rounded-full transition-all duration-300`}
                      style={{ width: `${passwordStrength}%` }}
                    ></div>
                  </div>
                </div>
              )}
              
              <div className="mt-2">
                <p className="text-xs text-muted-foreground">Password must contain:</p>
                <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                  <li className="flex items-center">
                    <span className={`mr-1 ${newPassword && newPassword.length >= 8 ? "text-success" : "text-muted-foreground"}`}>
                      {newPassword && newPassword.length >= 8 ? (
                        <CheckCircle className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                    </span>
                    At least 8 characters
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[A-Z]/.test(newPassword || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[A-Z]/.test(newPassword || "") ? (
                        <CheckCircle className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                    </span>
                    At least one uppercase letter
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[a-z]/.test(newPassword || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[a-z]/.test(newPassword || "") ? (
                        <CheckCircle className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                    </span>
                    At least one lowercase letter
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[0-9]/.test(newPassword || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[0-9]/.test(newPassword || "") ? (
                        <CheckCircle className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                    </span>
                    At least one number
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[^A-Za-z0-9]/.test(newPassword || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[^A-Za-z0-9]/.test(newPassword || "") ? (
                        <CheckCircle className="h-3 w-3" />
                      ) : (
                        <AlertTriangle className="h-3 w-3" />
                      )}
                    </span>
                    At least one special character
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium mb-1">
                Confirm New Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  className={`input pl-10 ${errors.confirmPassword ? "border-danger focus:ring-danger" : ""}`}
                  placeholder="Confirm your new password"
                  {...register("confirmPassword")}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-sm text-danger">{errors.confirmPassword.message}</p>
              )}
            </div>
            
            <div className="pt-2">
              <button
                type="submit"
                className="btn-primary w-full md:w-auto flex justify-center items-center"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : (
                  <Key className="h-5 w-5 mr-2" />
                )}
                {isLoading ? "Changing Password..." : "Change Password"}
              </button>
            </div>
          </form>
        </motion.div>
      </section>

      {/* Two-Factor Authentication */}
      <section className="mb-8">
        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-4">Two-Factor Authentication</h2>
          <p className="text-muted-foreground mb-6">
            Add an extra layer of security to your account by enabling two-factor authentication.
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="p-3 bg-muted rounded-full mr-4">
                <Smartphone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Mobile Authentication</h3>
                <p className="text-sm text-muted-foreground">
                  Receive a verification code on your mobile device when logging in.
                </p>
              </div>
            </div>
            <button 
              onClick={handleToggleTwoFactor}
              className="btn-primary"
              disabled={isLoading}
            >
              {adminUser.twoFactorEnabled ? "Disable" : "Enable"}
            </button>
          </div>
        </div>
      </section>

      {/* Active Sessions */}
      <section className="mb-8">
        <div className="card p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Active Sessions</h2>
            <button 
              onClick={handleLogoutAllDevices}
              className="btn-outline text-sm py-1.5 flex items-center"
              disabled={isLoading}
            >
              <LogOut className="h-4 w-4 mr-1" />
              Logout All Devices
            </button>
          </div>
          <p className="text-muted-foreground mb-6">
            These are the devices that are currently logged into your account.
          </p>
          
          <div className="space-y-4">
            {loginSessions.map((session) => (
              <div 
                key={session.id} 
                className={`p-4 rounded-lg ${
                  session.current 
                    ? "bg-primary/10 border border-primary/20" 
                    : "bg-muted/50"
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between">
                  <div className="mb-3 md:mb-0">
                    <div className="flex items-center">
                      <h3 className="font-medium">{session.device}</h3>
                      {session.current && (
                        <span className="ml-2 bg-primary/20 text-primary text-xs px-2 py-0.5 rounded-full">
                          Current Session
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap text-sm text-muted-foreground mt-1">
                      <span className="mr-3">{session.location}</span>
                      <span className="mr-3">IP: {session.ip}</span>
                      <span>{session.time}</span>
                    </div>
                  </div>
                  {!session.current && (
                    <button className="text-danger hover:text-danger/80 text-sm font-medium">
                      Terminate
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Recommendations */}
      <section>
        <div className="card p-6 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800/30">
          <div className="flex items-start">
            <div className="p-2 bg-yellow-100 dark:bg-yellow-800/30 rounded-full mr-4">
              <AlertTriangle className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-2">Security Recommendations</h2>
              <p className="text-muted-foreground mb-4">
                Follow these recommendations to keep your admin account secure:
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                  <span>Use a strong, unique password that you don't use elsewhere</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                  <span>Enable two-factor authentication for additional security</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                  <span>Change your password regularly (every 60-90 days)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                  <span>Monitor your active sessions and terminate any suspicious activity</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-success mr-2 mt-0.5" />
                  <span>Always log out when using shared or public computers</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}