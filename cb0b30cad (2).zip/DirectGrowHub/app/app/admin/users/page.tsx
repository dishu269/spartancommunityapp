"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import Link from "next/link";
import { 
  Users, 
  Search, 
  Filter, 
  ChevronDown, 
  Mail, 
  Phone, 
  MoreHorizontal,
  UserPlus,
  Download,
  CheckCircle,
  XCircle,
  Eye
} from "lucide-react";

// Mock data for users
const mockUsers = [
  {
    id: "1",
    name: "Riya Sharma",
    email: "riya.sharma@example.com",
    phone: "+91 9876543210",
    role: "DISTRIBUTOR",
    joinedDate: "August 15, 2023",
    status: "ACTIVE",
    completedModules: 7,
    totalModules: 12,
    leadsGenerated: 5,
    earnings: 12500,
    avatar: "https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg",
  },
  {
    id: "2",
    name: "Arjun Singh",
    email: "arjun.singh@example.com",
    phone: "+91 9876543211",
    role: "LEADER",
    joinedDate: "June 10, 2023",
    status: "ACTIVE",
    completedModules: 12,
    totalModules: 12,
    leadsGenerated: 15,
    earnings: 35000,
    avatar: "https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg",
  },
  {
    id: "3",
    name: "Ananya Desai",
    email: "ananya.d@example.com",
    phone: "+91 9876543220",
    role: "DISTRIBUTOR",
    joinedDate: "September 5, 2023",
    status: "ACTIVE",
    completedModules: 8,
    totalModules: 12,
    leadsGenerated: 12,
    earnings: 18500,
    avatar: "https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg",
  },
  {
    id: "4",
    name: "Vikram Malhotra",
    email: "vikram.m@example.com",
    phone: "+91 9876543221",
    role: "DISTRIBUTOR",
    joinedDate: "October 12, 2023",
    status: "ACTIVE",
    completedModules: 6,
    totalModules: 12,
    leadsGenerated: 8,
    earnings: 12000,
    avatar: "https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg",
  },
  {
    id: "5",
    name: "Deepika Reddy",
    email: "deepika.r@example.com",
    phone: "+91 9876543222",
    role: "DISTRIBUTOR",
    joinedDate: "November 3, 2023",
    status: "ACTIVE",
    completedModules: 4,
    totalModules: 12,
    leadsGenerated: 5,
    earnings: 7500,
    avatar: "https://cdn.pixabay.com/photo/2024/01/06/09/38/indian-8490981_1280.jpg",
  },
  {
    id: "6",
    name: "Rajesh Kumar",
    email: "rajesh.k@example.com",
    phone: "+91 9876543223",
    role: "DISTRIBUTOR",
    joinedDate: "November 20, 2023",
    status: "ONBOARDING",
    completedModules: 2,
    totalModules: 12,
    leadsGenerated: 1,
    earnings: 2000,
    avatar: "https://c8.alamy.com/comp/B515JJ/portrait-of-a-smiling-middle-aged-indian-man-B515JJ.jpg",
  },
  {
    id: "7",
    name: "Meera Joshi",
    email: "meera.j@example.com",
    phone: "+91 9876543224",
    role: "DISTRIBUTOR",
    joinedDate: "December 5, 2023",
    status: "ONBOARDING",
    completedModules: 1,
    totalModules: 12,
    leadsGenerated: 0,
    earnings: 0,
    avatar: "https://cdn.pixabay.com/photo/2022/01/23/08/24/indian-woman-6960082_1280.jpg",
  },
  {
    id: "8",
    name: "Priya Patel",
    email: "priya.admin@example.com",
    phone: "+91 9876543225",
    role: "ADMIN",
    joinedDate: "January 15, 2023",
    status: "ACTIVE",
    completedModules: 12,
    totalModules: 12,
    leadsGenerated: 0,
    earnings: 0,
    avatar: "https://as2.ftcdn.net/v2/jpg/03/87/11/63/1000_F_387116344_yxApYuCOH7CxKD4vhJKJiEBER0rcKdV9.jpg",
  },
];

const statusColors = {
  ACTIVE: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  ONBOARDING: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  INACTIVE: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const roleColors = {
  DISTRIBUTOR: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  LEADER: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  ADMIN: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
};

export default function UsersManagementPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRole, setSelectedRole] = useState("ALL");
  const [selectedStatus, setSelectedStatus] = useState("ALL");
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  // Filter users based on search, role, and status
  const filteredUsers = mockUsers.filter((user) => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.phone.includes(searchQuery);
    const matchesRole = selectedRole === "ALL" || user.role === selectedRole;
    const matchesStatus = selectedStatus === "ALL" || user.status === selectedStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              User Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              View and manage all users in the system
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0 flex gap-3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button className="btn-outline flex items-center">
              <Download className="h-5 w-5 mr-2" />
              Export Users
            </button>
            <button className="btn-primary flex items-center">
              <UserPlus className="h-5 w-5 mr-2" />
              Add User
            </button>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search users..."
              className="input pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-muted-foreground" />
              </div>
              <select
                className="input pl-10 pr-10 appearance-none w-full"
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
              >
                <option value="ALL">All Roles</option>
                <option value="DISTRIBUTOR">Distributor</option>
                <option value="LEADER">Team Leader</option>
                <option value="ADMIN">Admin</option>
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-muted-foreground" />
              </div>
              <select
                className="input pl-10 pr-10 appearance-none w-full"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="ALL">All Status</option>
                <option value="ACTIVE">Active</option>
                <option value="ONBOARDING">Onboarding</option>
                <option value="INACTIVE">Inactive</option>
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Users List */}
      <section ref={ref}>
        {filteredUsers.length > 0 ? (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">User</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Contact</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Role</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Progress</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredUsers.map((user, index) => (
                    <motion.tr 
                      key={user.id}
                      className="hover:bg-muted/30 transition-colors duration-150"
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center">
                          <div className="relative h-10 w-10 rounded-full overflow-hidden mr-3">
                            <Image 
                              src={user.avatar}
                              alt={user.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-xs text-muted-foreground">Joined {user.joinedDate}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <div className="flex items-center">
                            <Mail className="h-4 w-4 text-muted-foreground mr-2" />
                            <span className="text-sm">{user.email}</span>
                          </div>
                          <div className="flex items-center">
                            <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                            <span className="text-sm">{user.phone}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${roleColors[user.role as keyof typeof roleColors]}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[user.status as keyof typeof statusColors]}`}>
                          {user.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span>Training</span>
                            <span>{user.completedModules}/{user.totalModules}</span>
                          </div>
                          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary rounded-full" 
                              style={{ width: `${(user.completedModules / user.totalModules) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <Link 
                            href={`/admin/users/${user.id}`}
                            className="p-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded transition-colors duration-200"
                          >
                            <Eye className="h-4 w-4" />
                          </Link>
                          {user.status === "ONBOARDING" && (
                            <button className="p-1.5 bg-success/10 text-success hover:bg-success/20 rounded transition-colors duration-200">
                              <CheckCircle className="h-4 w-4" />
                            </button>
                          )}
                          {user.status === "ACTIVE" && (
                            <button className="p-1.5 bg-danger/10 text-danger hover:bg-danger/20 rounded transition-colors duration-200">
                              <XCircle className="h-4 w-4" />
                            </button>
                          )}
                          <div className="relative">
                            <button className="p-1.5 bg-muted hover:bg-muted/80 rounded transition-colors duration-200">
                              <MoreHorizontal className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-4 border-t border-border flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                Showing <span className="font-medium">{filteredUsers.length}</span> of <span className="font-medium">{mockUsers.length}</span> users
              </div>
              <div className="flex space-x-2">
                <button className="px-3 py-1 bg-muted rounded text-sm">Previous</button>
                <button className="px-3 py-1 bg-primary text-white rounded text-sm">1</button>
                <button className="px-3 py-1 bg-muted rounded text-sm">Next</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="card p-8 text-center">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <h3 className="text-lg font-medium mb-2">No users found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filter criteria</p>
            <button className="btn-primary inline-flex items-center">
              <UserPlus className="h-5 w-5 mr-2" />
              Add New User
            </button>
          </div>
        )}
      </section>
    </div>
  );
}