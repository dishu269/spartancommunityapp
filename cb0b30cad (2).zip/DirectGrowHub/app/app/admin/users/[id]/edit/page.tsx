"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { 
  User, 
  Mail, 
  Phone, 
  Building, 
  MapPin, 
  Shield, 
  ArrowLeft,
  Save,
  AlertCircle,
  Loader2
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { UserRole } from "@/lib/types";

// User update schema with validation
const userUpdateSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  role: z.enum([UserRole.DISTRIBUTOR, UserRole.LEADER, UserRole.ADMIN], {
    errorMap: () => ({ message: "Please select a valid role" }),
  }),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  pincode: z.string().optional(),
  company: z.string().optional(),
});

type UserUpdateFormValues = z.infer<typeof userUpdateSchema>;

export default function EditUserPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<UserUpdateFormValues>({
    resolver: zodResolver(userUpdateSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      role: UserRole.DISTRIBUTOR,
      address: "",
      city: "",
      state: "",
      pincode: "",
      company: "",
    },
  });
  
  // Fetch user data
  useEffect(() => {
    const fetchUser = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const response = await fetch(`/api/admin/users/${params.id}`);
        const result = await response.json();
        
        if (!response.ok || !result.success) {
          setError(result.message || "Failed to fetch user data");
          return;
        }
        
        setUser(result.data);
        
        // Set form default values
        reset({
          name: result.data.name,
          email: result.data.email,
          phone: result.data.phone || "",
          role: result.data.role,
          address: result.data.address || "",
          city: result.data.city || "",
          state: result.data.state || "",
          pincode: result.data.pincode || "",
          company: result.data.company || "",
        });
      } catch (error) {
        console.error("Error fetching user:", error);
        setError("An unexpected error occurred. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchUser();
  }, [params.id, reset]);
  
  const onSubmit = async (data: UserUpdateFormValues) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      console.log("Updating user:", data);
      
      const response = await fetch(`/api/admin/users/${params.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        setError(result.message || "Failed to update user");
        toast({
          title: "Update failed",
          description: result.message || "Failed to update user. Please try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }
      
      console.log("User updated successfully:", result);
      
      toast({
        title: "User updated",
        description: "User information has been updated successfully.",
        variant: "success",
      });
      
      // Redirect to user details page
      router.push(`/admin/users/${params.id}`);
    } catch (error) {
      console.error("User update error:", error);
      setError("An unexpected error occurred. Please try again.");
      toast({
        title: "Update error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error && !user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="card p-6 text-center">
          <AlertCircle className="h-12 w-12 text-danger mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Error Loading User</h1>
          <p className="text-muted-foreground mb-4">{error}</p>
          <button
            onClick={() => router.back()}
            className="btn-primary"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-6">
        <button
          onClick={() => router.back()}
          className="flex items-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back
        </button>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="card p-6">
          <h1 className="text-2xl font-bold mb-6">Edit User</h1>
          
          {error && (
            <div className="mb-6 p-4 bg-danger/10 border border-danger/20 rounded-lg flex items-start">
              <AlertCircle className="h-5 w-5 text-danger mr-2 mt-0.5" />
              <p className="text-sm text-danger">{error}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-1">
                  Full Name*
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="name"
                    type="text"
                    className={`input pl-10 ${errors.name ? "border-danger focus:ring-danger" : ""}`}
                    placeholder="Enter full name"
                    {...register("name")}
                    disabled={isSubmitting}
                  />
                </div>
                {errors.name && (
                  <p className="mt-1 text-sm text-danger">{errors.name.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-1">
                  Email Address*
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="email"
                    type="email"
                    className={`input pl-10 ${errors.email ? "border-danger focus:ring-danger" : ""}`}
                    placeholder="Enter email address"
                    {...register("email")}
                    disabled={isSubmitting}
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-sm text-danger">{errors.email.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium mb-1">
                  Phone Number*
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="phone"
                    type="tel"
                    className={`input pl-10 ${errors.phone ? "border-danger focus:ring-danger" : ""}`}
                    placeholder="Enter phone number"
                    {...register("phone")}
                    disabled={isSubmitting}
                  />
                </div>
                {errors.phone && (
                  <p className="mt-1 text-sm text-danger">{errors.phone.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="role" className="block text-sm font-medium mb-1">
                  Role*
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Shield className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <select
                    id="role"
                    className={`input pl-10 ${errors.role ? "border-danger focus:ring-danger" : ""}`}
                    {...register("role")}
                    disabled={isSubmitting}
                  >
                    <option value={UserRole.DISTRIBUTOR}>Distributor</option>
                    <option value={UserRole.LEADER}>Team Leader</option>
                    <option value={UserRole.ADMIN}>Admin</option>
                  </select>
                </div>
                {errors.role && (
                  <p className="mt-1 text-sm text-danger">{errors.role.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="company" className="block text-sm font-medium mb-1">
                  Company/Business
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Building className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="company"
                    type="text"
                    className="input pl-10"
                    placeholder="Enter company name"
                    {...register("company")}
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="address" className="block text-sm font-medium mb-1">
                  Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="address"
                    type="text"
                    className="input pl-10"
                    placeholder="Enter address"
                    {...register("address")}
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="city" className="block text-sm font-medium mb-1">
                    City
                  </label>
                  <input
                    id="city"
                    type="text"
                    className="input"
                    placeholder="Enter city"
                    {...register("city")}
                    disabled={isSubmitting}
                  />
                </div>
                
                <div>
                  <label htmlFor="state" className="block text-sm font-medium mb-1">
                    State
                  </label>
                  <input
                    id="state"
                    type="text"
                    className="input"
                    placeholder="Enter state"
                    {...register("state")}
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="pincode" className="block text-sm font-medium mb-1">
                  PIN Code
                </label>
                <input
                  id="pincode"
                  type="text"
                  className="input"
                  placeholder="Enter PIN code"
                  {...register("pincode")}
                  disabled={isSubmitting}
                />
              </div>
            </div>
            
            <div className="pt-4 border-t border-border">
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => router.back()}
                  className="btn-outline"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary flex items-center"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}