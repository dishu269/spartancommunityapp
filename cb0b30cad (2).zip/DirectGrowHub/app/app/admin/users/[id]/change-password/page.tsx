"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { 
  Key, 
  ArrowLeft,
  Save,
  AlertCircle,
  Eye,
  EyeOff,
  Lock
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

// Password change schema with validation
const passwordChangeSchema = z.object({
  password: z
    .string()
    .min(6, "Password must be at least 6 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type PasswordChangeFormValues = z.infer<typeof passwordChangeSchema>;

export default function ChangePasswordPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<PasswordChangeFormValues>({
    resolver: zodResolver(passwordChangeSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });
  
  // Watch the password to calculate strength
  const password = watch("password");
  
  // Calculate password strength
  const calculatePasswordStrength = (password: string) => {
    if (!password) return 0;
    
    let strength = 0;
    
    // Length check
    if (password.length >= 6) strength += 1;
    if (password.length >= 10) strength += 1;
    
    // Character type checks
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    // Calculate percentage (max strength is 6)
    return Math.min(Math.floor((strength / 6) * 100), 100);
  };
  
  // Update password strength when password changes
  useState(() => {
    if (password) {
      setPasswordStrength(calculatePasswordStrength(password));
    } else {
      setPasswordStrength(0);
    }
  });
  
  const getStrengthColor = () => {
    if (passwordStrength < 40) return "bg-red-500";
    if (passwordStrength < 70) return "bg-yellow-500";
    return "bg-green-500";
  };
  
  const getStrengthText = () => {
    if (passwordStrength < 40) return "Weak";
    if (passwordStrength < 70) return "Moderate";
    return "Strong";
  };
  
  const onSubmit = async (data: PasswordChangeFormValues) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      console.log("Changing password for user:", params.id);
      
      const response = await fetch(`/api/admin/users/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ password: data.password }),
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.success) {
        setError(result.message || "Failed to change password");
        toast({
          title: "Password change failed",
          description: result.message || "Failed to change password. Please try again.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }
      
      console.log("Password changed successfully");
      
      toast({
        title: "Password changed",
        description: "The password has been changed successfully.",
        variant: "success",
      });
      
      // Redirect to user details page
      router.push(`/admin/users/${params.id}`);
    } catch (error) {
      console.error("Password change error:", error);
      setError("An unexpected error occurred. Please try again.");
      toast({
        title: "Password change error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-6">
        <button
          onClick={() => router.back()}
          className="flex items-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back
        </button>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="card p-6">
          <h1 className="text-2xl font-bold mb-6">Change User Password</h1>
          
          {error && (
            <div className="mb-6 p-4 bg-danger/10 border border-danger/20 rounded-lg flex items-start">
              <AlertCircle className="h-5 w-5 text-danger mr-2 mt-0.5" />
              <p className="text-sm text-danger">{error}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-1">
                New Password*
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Key className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  className={`input pl-10 ${errors.password ? "border-danger focus:ring-danger" : ""}`}
                  placeholder="Enter new password"
                  {...register("password")}
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isSubmitting}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-sm text-danger">{errors.password.message}</p>
              )}
              
              {/* Password strength meter */}
              {password && (
                <div className="mt-2">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted-foreground">Password Strength</span>
                    <span className="text-xs font-medium">{getStrengthText()}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${getStrengthColor()} rounded-full transition-all duration-300`}
                      style={{ width: `${passwordStrength}%` }}
                    ></div>
                  </div>
                </div>
              )}
              
              <div className="mt-2">
                <p className="text-xs text-muted-foreground">Password must contain:</p>
                <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                  <li className="flex items-center">
                    <span className={`mr-1 ${password && password.length >= 6 ? "text-success" : "text-muted-foreground"}`}>
                      {password && password.length >= 6 ? "✓" : "•"}
                    </span>
                    At least 6 characters
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[A-Z]/.test(password || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[A-Z]/.test(password || "") ? "✓" : "•"}
                    </span>
                    At least one uppercase letter
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[a-z]/.test(password || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[a-z]/.test(password || "") ? "✓" : "•"}
                    </span>
                    At least one lowercase letter
                  </li>
                  <li className="flex items-center">
                    <span className={`mr-1 ${/[0-9]/.test(password || "") ? "text-success" : "text-muted-foreground"}`}>
                      {/[0-9]/.test(password || "") ? "✓" : "•"}
                    </span>
                    At least one number
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium mb-1">
                Confirm New Password*
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  className={`input pl-10 ${errors.confirmPassword ? "border-danger focus:ring-danger" : ""}`}
                  placeholder="Confirm new password"
                  {...register("confirmPassword")}
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  disabled={isSubmitting}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-sm text-danger">{errors.confirmPassword.message}</p>
              )}
            </div>
            
            <div className="pt-4 border-t border-border">
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => router.back()}
                  className="btn-outline"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-primary flex items-center"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Changing Password...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Change Password
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </motion.div>
      
      {/* Security Notice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-6"
      >
        <div className="card bg-muted/50 p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <AlertCircle className="h-5 w-5 text-primary mr-2" />
            Security Notice
          </h2>
          
          <p className="text-sm text-muted-foreground mb-4">
            Changing a user's password is a sensitive operation. Please ensure that:
          </p>
          
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>You have proper authorization to change this user's password.</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>The user is informed about the password change.</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>The new password is communicated securely to the user.</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>The user is advised to change their password again after first login.</span>
            </li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
}