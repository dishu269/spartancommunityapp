"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { 
  Video, 
  Play, 
  Edit, 
  Trash2, 
  Plus, 
  Save,
  Youtube,
  Link as LinkIcon,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// Mock data for existing videos
const initialVideos = [
  {
    id: "1",
    title: "Welcome to Spartan Community India",
    description: "Introduction to our platform and community",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    type: "ONBOARDING",
    addedBy: "Admin",
    addedAt: "2 weeks ago",
    active: true,
  },
  {
    id: "2",
    title: "Getting Started with Direct Selling",
    description: "Learn the basics of direct selling and how to start your journey",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    type: "TRAINING",
    addedBy: "Admin",
    addedAt: "1 month ago",
    active: true,
  }
];

export default function VideoManagementPage() {
  const [videos, setVideos] = useState(initialVideos);
  const [isAddingVideo, setIsAddingVideo] = useState(false);
  const [editingVideoId, setEditingVideoId] = useState<string | null>(null);
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  const { toast } = useToast();

  const [newVideo, setNewVideo] = useState({
    title: "",
    description: "",
    url: "",
    type: "ONBOARDING",
  });

  const validateYouTubeUrl = (url: string) => {
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
    return youtubeRegex.test(url);
  };

  const handleAddVideo = () => {
    if (!newVideo.title || !newVideo.url) {
      toast({
        title: "Missing information",
        description: "Please provide a title and URL for the video",
        variant: "destructive",
      });
      return;
    }

    if (!validateYouTubeUrl(newVideo.url)) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid YouTube URL",
        variant: "destructive",
      });
      return;
    }

    const videoToAdd = {
      id: (videos.length + 1).toString(),
      ...newVideo,
      addedBy: "Admin",
      addedAt: "Just now",
      active: true,
    };

    setVideos([videoToAdd, ...videos]);
    setNewVideo({
      title: "",
      description: "",
      url: "",
      type: "ONBOARDING",
    });
    setIsAddingVideo(false);

    toast({
      title: "Video added",
      description: "The video has been successfully added",
      variant: "success",
    });
  };

  const handleUpdateVideo = (id: string) => {
    const updatedVideos = videos.map(video => {
      if (video.id === id) {
        const editedVideo = videos.find(v => v.id === editingVideoId);
        return {
          ...video,
          ...editedVideo,
        };
      }
      return video;
    });

    setVideos(updatedVideos);
    setEditingVideoId(null);

    toast({
      title: "Video updated",
      description: "The video has been successfully updated",
      variant: "success",
    });
  };

  const handleDeleteVideo = (id: string) => {
    const updatedVideos = videos.filter(video => video.id !== id);
    setVideos(updatedVideos);

    toast({
      title: "Video deleted",
      description: "The video has been successfully deleted",
      variant: "success",
    });
  };

  const handleEditVideo = (id: string) => {
    setEditingVideoId(id);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>, id?: string) => {
    const { name, value } = e.target;
    
    if (id) {
      // Editing existing video
      const updatedVideos = videos.map(video => {
        if (video.id === id) {
          return {
            ...video,
            [name]: value,
          };
        }
        return video;
      });
      setVideos(updatedVideos);
    } else {
      // Adding new video
      setNewVideo({
        ...newVideo,
        [name]: value,
      });
    }
  };

  const getYouTubeThumbnail = (url: string) => {
    try {
      const videoId = url.split('v=')[1].split('&')[0];
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    } catch (error) {
      return 'https://via.placeholder.com/480x360?text=Video+Thumbnail';
    }
  };

  const toggleVideoStatus = (id: string) => {
    const updatedVideos = videos.map(video => {
      if (video.id === id) {
        return {
          ...video,
          active: !video.active,
        };
      }
      return video;
    });
    
    setVideos(updatedVideos);
    
    const video = updatedVideos.find(v => v.id === id);
    toast({
      title: video?.active ? "Video activated" : "Video deactivated",
      description: `The video has been ${video?.active ? "activated" : "deactivated"}`,
      variant: "success",
    });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Video Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Manage introduction and training videos for the platform
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              onClick={() => setIsAddingVideo(!isAddingVideo)}
              className="btn-primary flex items-center"
            >
              {isAddingVideo ? (
                <>
                  <AlertCircle className="h-5 w-5 mr-2" />
                  Cancel
                </>
              ) : (
                <>
                  <Plus className="h-5 w-5 mr-2" />
                  Add New Video
                </>
              )}
            </button>
          </motion.div>
        </div>
      </section>

      {/* Add Video Form */}
      {isAddingVideo && (
        <motion.section 
          className="mb-8"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-4">Add New Video</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium mb-1">
                  Video Title*
                </label>
                <input
                  id="title"
                  name="title"
                  type="text"
                  className="input"
                  placeholder="Enter video title"
                  value={newVideo.title}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  className="input min-h-[80px]"
                  placeholder="Enter video description"
                  value={newVideo.description}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="url" className="block text-sm font-medium mb-1">
                  YouTube URL*
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Youtube className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    id="url"
                    name="url"
                    type="url"
                    className="input pl-10"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={newVideo.url}
                    onChange={handleInputChange}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Enter a valid YouTube video URL
                </p>
              </div>
              
              <div>
                <label htmlFor="type" className="block text-sm font-medium mb-1">
                  Video Type
                </label>
                <select
                  id="type"
                  name="type"
                  className="input"
                  value={newVideo.type}
                  onChange={handleInputChange}
                >
                  <option value="ONBOARDING">Onboarding</option>
                  <option value="TRAINING">Training</option>
                  <option value="PRODUCT">Product</option>
                  <option value="COMPLIANCE">Compliance</option>
                  <option value="MOTIVATIONAL">Motivational</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <button 
                  onClick={() => setIsAddingVideo(false)}
                  className="btn-outline"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddVideo}
                  className="btn-primary flex items-center"
                >
                  <Save className="h-5 w-5 mr-2" />
                  Save Video
                </button>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Videos List */}
      <section ref={ref}>
        <h2 className="text-xl font-semibold mb-4">All Videos</h2>
        
        <div className="space-y-4">
          {videos.map((video, index) => (
            <motion.div 
              key={video.id}
              className="card overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3 relative">
                  <div className="relative h-48 md:h-full">
                    <img 
                      src={getYouTubeThumbnail(video.url)} 
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <a 
                        href={video.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-black/70 hover:bg-black/90 text-white rounded-full p-3 transition-all duration-200"
                      >
                        <Play className="h-6 w-6" />
                      </a>
                    </div>
                    <div className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-medium ${video.active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'}`}>
                      {video.active ? 'Active' : 'Inactive'}
                    </div>
                  </div>
                </div>
                
                <div className="p-6 md:w-2/3">
                  {editingVideoId === video.id ? (
                    <div className="space-y-4">
                      <div>
                        <label htmlFor={`title-${video.id}`} className="block text-sm font-medium mb-1">
                          Video Title
                        </label>
                        <input
                          id={`title-${video.id}`}
                          name="title"
                          type="text"
                          className="input"
                          value={video.title}
                          onChange={(e) => handleInputChange(e, video.id)}
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`description-${video.id}`} className="block text-sm font-medium mb-1">
                          Description
                        </label>
                        <textarea
                          id={`description-${video.id}`}
                          name="description"
                          className="input min-h-[80px]"
                          value={video.description}
                          onChange={(e) => handleInputChange(e, video.id)}
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`url-${video.id}`} className="block text-sm font-medium mb-1">
                          YouTube URL
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Youtube className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <input
                            id={`url-${video.id}`}
                            name="url"
                            type="url"
                            className="input pl-10"
                            value={video.url}
                            onChange={(e) => handleInputChange(e, video.id)}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label htmlFor={`type-${video.id}`} className="block text-sm font-medium mb-1">
                          Video Type
                        </label>
                        <select
                          id={`type-${video.id}`}
                          name="type"
                          className="input"
                          value={video.type}
                          onChange={(e) => handleInputChange(e, video.id)}
                        >
                          <option value="ONBOARDING">Onboarding</option>
                          <option value="TRAINING">Training</option>
                          <option value="PRODUCT">Product</option>
                          <option value="COMPLIANCE">Compliance</option>
                          <option value="MOTIVATIONAL">Motivational</option>
                        </select>
                      </div>
                      
                      <div className="flex justify-end space-x-3 pt-4">
                        <button 
                          onClick={() => setEditingVideoId(null)}
                          className="btn-outline"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={() => handleUpdateVideo(video.id)}
                          className="btn-primary flex items-center"
                        >
                          <Save className="h-5 w-5 mr-2" />
                          Update Video
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-semibold mb-2">{video.title}</h3>
                          <p className="text-muted-foreground mb-4">{video.description}</p>
                        </div>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                          video.type === 'ONBOARDING' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' :
                          video.type === 'TRAINING' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300' :
                          video.type === 'PRODUCT' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' :
                          video.type === 'COMPLIANCE' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' :
                          'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
                        }`}>
                          {video.type}
                        </span>
                      </div>
                      
                      <div className="flex items-center text-sm text-muted-foreground mb-4">
                        <span>Added by {video.addedBy}</span>
                        <span className="mx-2">•</span>
                        <span>{video.addedAt}</span>
                      </div>
                      
                      <div className="flex items-center mb-4">
                        <div className="flex items-center bg-muted/50 rounded-md px-3 py-2 flex-1 mr-3">
                          <LinkIcon className="h-4 w-4 text-muted-foreground mr-2" />
                          <span className="text-sm truncate">{video.url}</span>
                        </div>
                        <a 
                          href={video.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="btn-outline text-sm py-1.5"
                        >
                          Open
                        </a>
                      </div>
                      
                      <div className="flex space-x-3">
                        <button 
                          onClick={() => handleEditVideo(video.id)}
                          className="btn-outline text-sm py-1.5 flex items-center"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </button>
                        <button 
                          onClick={() => toggleVideoStatus(video.id)}
                          className={`text-sm py-1.5 flex items-center ${
                            video.active 
                              ? 'bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 dark:hover:bg-red-900/50' 
                              : 'bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:hover:bg-green-900/50'
                          } font-medium px-3 rounded-md transition-colors duration-200`}
                        >
                          {video.active ? 'Deactivate' : 'Activate'}
                        </button>
                        <button 
                          onClick={() => handleDeleteVideo(video.id)}
                          className="bg-danger/10 text-danger hover:bg-danger/20 font-medium px-3 py-1.5 rounded-md transition-colors duration-200 text-sm flex items-center"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}