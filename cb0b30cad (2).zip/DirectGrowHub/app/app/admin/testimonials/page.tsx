"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import { 
  MessageSquare, 
  Plus, 
  Edit, 
  Trash2, 
  Star, 
  User,
  Save,
  X,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// Mock testimonials data - would come from API in real implementation
const initialTestimonials = [
  {
    id: "1",
    name: "Priya Sharma",
    role: "Team Leader",
    content: "Joining Spartan Community India was the best decision I've made. In just 6 months, I built a team of 30 distributors and doubled my monthly income!",
    imageUrl: "https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg",
    rating: 5,
    isActive: true,
  },
  {
    id: "2",
    name: "Rajesh Kumar",
    role: "Distributor",
    content: "The training and support I received helped me understand the business quickly. Now I'm earning a steady income while working flexible hours.",
    imageUrl: "https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg",
    rating: 5,
    isActive: true,
  },
  {
    id: "3",
    name: "Ananya Patel",
    role: "New Distributor",
    content: "As a college student, I was looking for a part-time opportunity. Spartan Community India provided me with the perfect platform to earn while I learn.",
    imageUrl: "https://cdn.pixabay.com/photo/2024/01/06/09/38/indian-8490981_1280.jpg",
    rating: 4,
    isActive: true,
  },
];

export default function TestimonialsPage() {
  const [testimonials, setTestimonials] = useState(initialTestimonials);
  const [isAddingTestimonial, setIsAddingTestimonial] = useState(false);
  const [editingTestimonialId, setEditingTestimonialId] = useState<string | null>(null);
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  const { toast } = useToast();

  const [newTestimonial, setNewTestimonial] = useState({
    name: "",
    role: "",
    content: "",
    imageUrl: "",
    rating: 5,
  });

  const handleAddTestimonial = () => {
    if (!newTestimonial.name || !newTestimonial.content) {
      toast({
        title: "Missing information",
        description: "Please provide a name and testimonial content",
        variant: "destructive",
      });
      return;
    }

    const testimonialToAdd = {
      id: (testimonials.length + 1).toString(),
      ...newTestimonial,
      isActive: true,
    };

    setTestimonials([testimonialToAdd, ...testimonials]);
    setNewTestimonial({
      name: "",
      role: "",
      content: "",
      imageUrl: "",
      rating: 5,
    });
    setIsAddingTestimonial(false);

    toast({
      title: "Testimonial added",
      description: "The testimonial has been successfully added",
      variant: "success",
    });
  };

  const handleUpdateTestimonial = (id: string) => {
    const updatedTestimonials = testimonials.map(testimonial => {
      if (testimonial.id === id) {
        const editedTestimonial = testimonials.find(t => t.id === editingTestimonialId);
        return {
          ...testimonial,
          ...editedTestimonial,
        };
      }
      return testimonial;
    });

    setTestimonials(updatedTestimonials);
    setEditingTestimonialId(null);

    toast({
      title: "Testimonial updated",
      description: "The testimonial has been successfully updated",
      variant: "success",
    });
  };

  const handleDeleteTestimonial = (id: string) => {
    const updatedTestimonials = testimonials.filter(testimonial => testimonial.id !== id);
    setTestimonials(updatedTestimonials);

    toast({
      title: "Testimonial deleted",
      description: "The testimonial has been successfully deleted",
      variant: "success",
    });
  };

  const handleEditTestimonial = (id: string) => {
    setEditingTestimonialId(id);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>, id?: string) => {
    const { name, value } = e.target;
    
    if (id) {
      // Editing existing testimonial
      const updatedTestimonials = testimonials.map(testimonial => {
        if (testimonial.id === id) {
          return {
            ...testimonial,
            [name]: name === "rating" ? parseInt(value) : value,
          };
        }
        return testimonial;
      });
      setTestimonials(updatedTestimonials);
    } else {
      // Adding new testimonial
      setNewTestimonial({
        ...newTestimonial,
        [name]: name === "rating" ? parseInt(value) : value,
      });
    }
  };

  const toggleTestimonialStatus = (id: string) => {
    const updatedTestimonials = testimonials.map(testimonial => {
      if (testimonial.id === id) {
        return {
          ...testimonial,
          isActive: !testimonial.isActive,
        };
      }
      return testimonial;
    });
    
    setTestimonials(updatedTestimonials);
    
    const testimonial = updatedTestimonials.find(t => t.id === id);
    toast({
      title: testimonial?.isActive ? "Testimonial activated" : "Testimonial deactivated",
      description: `The testimonial has been ${testimonial?.isActive ? "activated" : "deactivated"}`,
      variant: "success",
    });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header Section */}
      <section className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <motion.h1 
              className="text-2xl md:text-3xl font-bold mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Testimonial Management
            </motion.h1>
            <motion.p 
              className="text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Manage success stories displayed on the referral landing page
            </motion.p>
          </div>
          <motion.div 
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              onClick={() => setIsAddingTestimonial(!isAddingTestimonial)}
              className="btn-primary flex items-center"
            >
              {isAddingTestimonial ? (
                <>
                  <X className="h-5 w-5 mr-2" />
                  Cancel
                </>
              ) : (
                <>
                  <Plus className="h-5 w-5 mr-2" />
                  Add Testimonial
                </>
              )}
            </button>
          </motion.div>
        </div>
      </section>

      {/* Add Testimonial Form */}
      {isAddingTestimonial && (
        <motion.section 
          className="mb-8"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-4">Add New Testimonial</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Name*
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    className="input"
                    placeholder="Enter name"
                    value={newTestimonial.name}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div>
                  <label htmlFor="role" className="block text-sm font-medium mb-1">
                    Role*
                  </label>
                  <input
                    id="role"
                    name="role"
                    type="text"
                    className="input"
                    placeholder="e.g., Team Leader, Distributor"
                    value={newTestimonial.role}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="content" className="block text-sm font-medium mb-1">
                  Testimonial Content*
                </label>
                <textarea
                  id="content"
                  name="content"
                  className="input min-h-[120px]"
                  placeholder="Enter testimonial content"
                  value={newTestimonial.content}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="imageUrl" className="block text-sm font-medium mb-1">
                    Profile Image URL
                  </label>
                  <input
                    id="imageUrl"
                    name="imageUrl"
                    type="url"
                    className="input"
                    placeholder="https://example.com/image.jpg"
                    value={newTestimonial.imageUrl}
                    onChange={handleInputChange}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Enter a URL for the person's profile image
                  </p>
                </div>
                
                <div>
                  <label htmlFor="rating" className="block text-sm font-medium mb-1">
                    Rating
                  </label>
                  <select
                    id="rating"
                    name="rating"
                    className="input"
                    value={newTestimonial.rating}
                    onChange={handleInputChange}
                  >
                    <option value="5">5 Stars</option>
                    <option value="4">4 Stars</option>
                    <option value="3">3 Stars</option>
                    <option value="2">2 Stars</option>
                    <option value="1">1 Star</option>
                  </select>
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <button 
                  onClick={() => setIsAddingTestimonial(false)}
                  className="btn-outline"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddTestimonial}
                  className="btn-primary flex items-center"
                >
                  <Save className="h-5 w-5 mr-2" />
                  Save Testimonial
                </button>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Testimonials List */}
      <section ref={ref}>
        <h2 className="text-xl font-semibold mb-4">All Testimonials</h2>
        
        <div className="space-y-4">
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={testimonial.id}
              className="card overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-border">
                  <div className="relative h-24 w-24 rounded-full overflow-hidden mb-4">
                    {testimonial.imageUrl ? (
                      <Image 
                        src={testimonial.imageUrl} 
                        alt={testimonial.name}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <div className="h-full w-full bg-primary/10 flex items-center justify-center">
                        <User className="h-12 w-12 text-primary" />
                      </div>
                    )}
                  </div>
                  
                  {editingTestimonialId === testimonial.id ? (
                    <div className="w-full space-y-3">
                      <input
                        name="name"
                        type="text"
                        className="input text-center"
                        value={testimonial.name}
                        onChange={(e) => handleInputChange(e, testimonial.id)}
                      />
                      <input
                        name="role"
                        type="text"
                        className="input text-center"
                        value={testimonial.role}
                        onChange={(e) => handleInputChange(e, testimonial.id)}
                      />
                    </div>
                  ) : (
                    <div className="text-center">
                      <h3 className="font-semibold">{testimonial.name}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  )}
                  
                  <div className="flex mt-3">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-500 fill-yellow-500' : 'text-muted'}`} 
                      />
                    ))}
                  </div>
                  
                  {editingTestimonialId === testimonial.id && (
                    <div className="mt-3 w-full">
                      <label className="block text-sm font-medium mb-1">
                        Rating
                      </label>
                      <select
                        name="rating"
                        className="input"
                        value={testimonial.rating}
                        onChange={(e) => handleInputChange(e, testimonial.id)}
                      >
                        <option value="5">5 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="2">2 Stars</option>
                        <option value="1">1 Star</option>
                      </select>
                    </div>
                  )}
                  
                  <div className={`mt-4 px-2.5 py-1 rounded-full text-xs font-medium ${
                    testimonial.isActive 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                      : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {testimonial.isActive ? 'Active' : 'Inactive'}
                  </div>
                </div>
                
                <div className="md:w-3/4 p-6">
                  {editingTestimonialId === testimonial.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">
                          Testimonial Content
                        </label>
                        <textarea
                          name="content"
                          className="input min-h-[120px]"
                          value={testimonial.content}
                          onChange={(e) => handleInputChange(e, testimonial.id)}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">
                          Profile Image URL
                        </label>
                        <input
                          name="imageUrl"
                          type="url"
                          className="input"
                          value={testimonial.imageUrl}
                          onChange={(e) => handleInputChange(e, testimonial.id)}
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-3 pt-4">
                        <button 
                          onClick={() => setEditingTestimonialId(null)}
                          className="btn-outline"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={() => handleUpdateTestimonial(testimonial.id)}
                          className="btn-primary flex items-center"
                        >
                          <Save className="h-5 w-5 mr-2" />
                          Save Changes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="mb-6">
                        <h3 className="text-lg font-semibold mb-2">Testimonial</h3>
                        <p className="text-muted-foreground">"{testimonial.content}"</p>
                      </div>
                      
                      <div className="flex space-x-3">
                        <button 
                          onClick={() => handleEditTestimonial(testimonial.id)}
                          className="btn-outline text-sm py-1.5 flex items-center"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </button>
                        <button 
                          onClick={() => toggleTestimonialStatus(testimonial.id)}
                          className={`text-sm py-1.5 flex items-center ${
                            testimonial.isActive 
                              ? 'bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 dark:hover:bg-red-900/50' 
                              : 'bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:hover:bg-green-900/50'
                          } font-medium px-3 rounded-md transition-colors duration-200`}
                        >
                          {testimonial.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                        <button 
                          onClick={() => handleDeleteTestimonial(testimonial.id)}
                          className="bg-danger/10 text-danger hover:bg-danger/20 font-medium px-3 py-1.5 rounded-md transition-colors duration-200 text-sm flex items-center"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
          
          {testimonials.length === 0 && (
            <div className="card p-6 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <h3 className="text-lg font-medium mb-2">No testimonials yet</h3>
              <p className="text-muted-foreground mb-4">
                Add testimonials to showcase success stories on the referral landing page.
              </p>
              <button 
                onClick={() => setIsAddingTestimonial(true)}
                className="btn-primary"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add First Testimonial
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Help Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="mt-8"
      >
        <div className="card bg-muted/50 p-6">
          <div className="flex items-start">
            <AlertCircle className="h-6 w-6 text-primary mr-3 mt-0.5" />
            <div>
              <h3 className="font-semibold mb-2">Tips for Effective Testimonials</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Use real success stories from actual distributors</li>
                <li>• Include specific achievements and results</li>
                <li>• Keep testimonials concise and focused</li>
                <li>• Use high-quality profile images when available</li>
                <li>• Ensure testimonials are relatable to your target audience</li>
              </ul>
            </div>
          </div>
        </div>
      </motion.section>
    </div>
  );
}