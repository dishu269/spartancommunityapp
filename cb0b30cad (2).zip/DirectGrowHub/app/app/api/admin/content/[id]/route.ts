import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { UserRole } from "@/lib/types";
import { z } from "zod";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Content update schema with validation
const contentUpdateSchema = z.object({
  title: z.string().min(1, "Title is required").optional(),
  description: z.string().optional(),
  type: z.enum(["DOCUMENT", "VIDEO", "IMAGE", "LINK", "SPREADSHEET", "PRESENTATION"], {
    errorMap: () => ({ message: "Invalid content type" }),
  }).optional(),
  format: z.string().optional(),
  url: z.string().url("Please enter a valid URL").optional(),
  fileSize: z.string().optional(),
  isActive: z.boolean().optional(),
});

// Verify admin authorization
async function verifyAdmin(request: NextRequest) {
  const token = cookies().get("auth-token")?.value;
  
  if (!token) {
    return { authorized: false, message: "Not authenticated" };
  }
  
  const payload = await verifyToken(token);
  
  if (!payload) {
    return { authorized: false, message: "Invalid or expired session" };
  }
  
  // Verify user exists and is an admin
  const user = await prisma.user.findUnique({
    where: { id: payload.id as string }
  });
  
  if (!user || user.role !== UserRole.ADMIN) {
    return { authorized: false, message: "Unauthorized access" };
  }
  
  return { authorized: true, user };
}

// GET - Fetch a specific content item
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`GET content/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Fetch content item from database
    const contentItem = await prisma.content.findUnique({
      where: { id: params.id }
    });
    
    if (!contentItem) {
      return NextResponse.json(
        { 
          success: false, 
          error: "Content not found", 
          message: "The requested content item does not exist." 
        },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ 
      success: true, 
      data: contentItem 
    });
  } catch (error) {
    console.error(`GET content/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// PATCH - Update a content item
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`PATCH content/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get update data from request body
    const body = await request.json();
    
    // Validate input
    const result = contentUpdateSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    // Check if content exists
    const existingContent = await prisma.content.findUnique({
      where: { id: params.id }
    });
    
    if (!existingContent) {
      return NextResponse.json(
        { 
          success: false, 
          error: "Content not found", 
          message: "The content item you are trying to update does not exist." 
        },
        { status: 404 }
      );
    }
    
    // Update content item in database
    const updatedContent = await prisma.content.update({
      where: { id: params.id },
      data: result.data
    });
    
    console.log("Content updated:", { id: updatedContent.id, title: updatedContent.title });
    
    return NextResponse.json({ 
      success: true, 
      message: "Content updated successfully",
      data: updatedContent
    });
  } catch (error) {
    console.error(`PATCH content/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// DELETE - Delete a content item
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`DELETE content/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Check if content exists
    const existingContent = await prisma.content.findUnique({
      where: { id: params.id }
    });
    
    if (!existingContent) {
      return NextResponse.json(
        { 
          success: false, 
          error: "Content not found", 
          message: "The content item you are trying to delete does not exist." 
        },
        { status: 404 }
      );
    }
    
    // Delete content item from database
    await prisma.content.delete({
      where: { id: params.id }
    });
    
    console.log("Content deleted:", { id: params.id });
    
    return NextResponse.json({ 
      success: true, 
      message: "Content deleted successfully"
    });
  } catch (error) {
    console.error(`DELETE content/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}