import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { UserRole } from "@/lib/types";
import { z } from "zod";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Content schema with validation
const contentSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  type: z.enum(["DOCUMENT", "VIDEO", "IMAGE", "LINK", "SPREADSHEET", "PRESENTATION"], {
    errorMap: () => ({ message: "Invalid content type" }),
  }),
  format: z.string().optional(),
  url: z.string().url("Please enter a valid URL"),
  fileSize: z.string().optional(),
});

// Verify admin authorization
async function verifyAdmin(request: NextRequest) {
  const token = cookies().get("auth-token")?.value;
  
  if (!token) {
    return { authorized: false, message: "Not authenticated" };
  }
  
  const payload = await verifyToken(token);
  
  if (!payload) {
    return { authorized: false, message: "Invalid or expired session" };
  }
  
  // Verify user exists and is an admin
  const user = await prisma.user.findUnique({
    where: { id: payload.id as string }
  });
  
  if (!user || user.role !== UserRole.ADMIN) {
    return { authorized: false, message: "Unauthorized access" };
  }
  
  return { authorized: true, user };
}

// GET - Fetch all content items
export async function GET(request: NextRequest) {
  try {
    console.log("GET content API called");
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const search = searchParams.get("search");
    
    // Build filter conditions
    const whereConditions: any = {};
    
    if (type && type !== "ALL") {
      whereConditions.type = type;
    }
    
    if (search) {
      whereConditions.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ];
    }
    
    // Fetch content items from database
    const contentItems = await prisma.content.findMany({
      where: whereConditions,
      orderBy: { createdAt: "desc" },
    });
    
    return NextResponse.json({ 
      success: true, 
      data: contentItems 
    });
  } catch (error) {
    console.error("GET content API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// POST - Create new content item
export async function POST(request: NextRequest) {
  try {
    console.log("POST content API called");
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get content data from request body
    const body = await request.json();
    
    // Validate input
    const result = contentSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    const { title, description, type, format, url, fileSize } = result.data;
    
    // Create new content item in database
    const newContent = await prisma.content.create({
      data: {
        title,
        description,
        type,
        format,
        url,
        fileSize,
        uploadedBy: auth.user?.name || "Admin", // Fixed: Added null check with default value
        isActive: true,
      }
    });
    
    console.log("New content created:", { id: newContent.id, title: newContent.title });
    
    return NextResponse.json({ 
      success: true, 
      message: "Content created successfully",
      data: newContent
    });
  } catch (error) {
    console.error("POST content API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}