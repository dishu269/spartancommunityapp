import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { UserRole } from "@/lib/types";
import { z } from "zod";
import { hashPassword } from "@/lib/utils";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// User update schema with validation
const userUpdateSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").optional(),
  email: z.string().email("Please enter a valid email address").optional(),
  phone: z.string().min(10, "Please enter a valid phone number").optional(),
  role: z.enum([UserRole.DISTRIBUTOR, UserRole.LEADER, UserRole.ADMIN], {
    errorMap: () => ({ message: "Invalid user role" }),
  }).optional(),
  onboardingComplete: z.boolean().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  pincode: z.string().optional(),
  company: z.string().optional(),
  profileImage: z.string().optional(),
});

// Password change schema with validation
const passwordChangeSchema = z.object({
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Verify admin authorization
async function verifyAdmin(request: NextRequest) {
  const token = cookies().get("auth-token")?.value;
  
  if (!token) {
    return { authorized: false, message: "Not authenticated" };
  }
  
  const payload = await verifyToken(token);
  
  if (!payload) {
    return { authorized: false, message: "Invalid or expired session" };
  }
  
  // Verify user exists and is an admin
  const user = await prisma.user.findUnique({
    where: { id: payload.id as string }
  });
  
  if (!user || user.role !== UserRole.ADMIN) {
    return { authorized: false, message: "Unauthorized access" };
  }
  
  return { authorized: true, user };
}

// GET - Fetch a specific user
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`GET users/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Fetch user from database
    const user = await prisma.user.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        onboardingComplete: true,
        profileImage: true,
        address: true,
        city: true,
        state: true,
        pincode: true,
        company: true,
        referralCode: true,
        createdAt: true,
        updatedAt: true,
        // Exclude password and other sensitive fields
      }
    });
    
    if (!user) {
      return NextResponse.json(
        { 
          success: false, 
          error: "User not found", 
          message: "The requested user does not exist." 
        },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ 
      success: true, 
      data: user 
    });
  } catch (error) {
    console.error(`GET users/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// PATCH - Update a user
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`PATCH users/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get update data from request body
    const body = await request.json();
    
    // Validate input
    const result = userUpdateSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { id: params.id }
    });
    
    if (!existingUser) {
      return NextResponse.json(
        { 
          success: false, 
          error: "User not found", 
          message: "The user you are trying to update does not exist." 
        },
        { status: 404 }
      );
    }
    
    // If email is being updated, check if it's already in use
    if (result.data.email && result.data.email.toLowerCase() !== existingUser.email) {
      const emailExists = await prisma.user.findUnique({
        where: { email: result.data.email.toLowerCase() }
      });
      
      if (emailExists) {
        return NextResponse.json(
          { 
            success: false, 
            error: "Email already exists", 
            message: "This email is already registered. Please use a different email." 
          },
          { status: 409 }
        );
      }
      
      // Update email to lowercase
      result.data.email = result.data.email.toLowerCase();
    }
    
    // Update user in database
    const updatedUser = await prisma.user.update({
      where: { id: params.id },
      data: result.data,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        onboardingComplete: true,
        profileImage: true,
        address: true,
        city: true,
        state: true,
        pincode: true,
        company: true,
        referralCode: true,
        createdAt: true,
        updatedAt: true,
        // Exclude password and other sensitive fields
      }
    });
    
    console.log("User updated:", { id: updatedUser.id, name: updatedUser.name, email: updatedUser.email });
    
    return NextResponse.json({ 
      success: true, 
      message: "User updated successfully",
      data: updatedUser
    });
  } catch (error) {
    console.error(`PATCH users/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// PUT - Change user password
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`PUT users/${params.id}/password API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get password data from request body
    const body = await request.json();
    
    // Validate input
    const result = passwordChangeSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { id: params.id }
    });
    
    if (!existingUser) {
      return NextResponse.json(
        { 
          success: false, 
          error: "User not found", 
          message: "The user you are trying to update does not exist." 
        },
        { status: 404 }
      );
    }
    
    // Hash new password
    const hashedPassword = await hashPassword(result.data.password);
    
    // Update user password in database
    await prisma.user.update({
      where: { id: params.id },
      data: { password: hashedPassword }
    });
    
    console.log("User password updated:", { id: params.id });
    
    return NextResponse.json({ 
      success: true, 
      message: "Password updated successfully"
    });
  } catch (error) {
    console.error(`PUT users/${params.id}/password API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// DELETE - Delete a user
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`DELETE users/${params.id} API called`);
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { id: params.id }
    });
    
    if (!existingUser) {
      return NextResponse.json(
        { 
          success: false, 
          error: "User not found", 
          message: "The user you are trying to delete does not exist." 
        },
        { status: 404 }
      );
    }
    
    // Prevent deleting the last admin
    if (existingUser.role === UserRole.ADMIN) {
      const adminCount = await prisma.user.count({
        where: { role: UserRole.ADMIN }
      });
      
      if (adminCount <= 1) {
        return NextResponse.json(
          { 
            success: false, 
            error: "Cannot delete last admin", 
            message: "You cannot delete the last admin user." 
          },
          { status: 400 }
        );
      }
    }
    
    // Delete user from database
    await prisma.user.delete({
      where: { id: params.id }
    });
    
    console.log("User deleted:", { id: params.id });
    
    return NextResponse.json({ 
      success: true, 
      message: "User deleted successfully"
    });
  } catch (error) {
    console.error(`DELETE users/${params.id} API error:`, error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}