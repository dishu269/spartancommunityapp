import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { UserRole } from "@/lib/types";
import { z } from "zod";
import { hashPassword, generateReferralCode } from "@/lib/utils";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// User creation schema with validation
const userCreateSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.enum([UserRole.DISTRIBUTOR, UserRole.LEADER, UserRole.ADMIN], {
    errorMap: () => ({ message: "Invalid user role" }),
  }),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  pincode: z.string().optional(),
  company: z.string().optional(),
});

type UserCreateData = z.infer<typeof userCreateSchema>;

// Verify admin authorization
async function verifyAdmin(request: NextRequest) {
  const token = cookies().get("auth-token")?.value;
  
  if (!token) {
    return { authorized: false, message: "Not authenticated" };
  }
  
  const payload = await verifyToken(token);
  
  if (!payload) {
    return { authorized: false, message: "Invalid or expired session" };
  }
  
  // Verify user exists and is an admin
  const user = await prisma.user.findUnique({
    where: { id: payload.id as string }
  });
  
  if (!user || user.role !== UserRole.ADMIN) {
    return { authorized: false, message: "Unauthorized access" };
  }
  
  return { authorized: true, user };
}

// GET - Fetch all users
export async function GET(request: NextRequest) {
  try {
    console.log("GET users API called");
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const role = searchParams.get("role");
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    
    // Build filter conditions
    const whereConditions: any = {};
    
    if (role && role !== "ALL") {
      whereConditions.role = role;
    }
    
    if (status === "ACTIVE") {
      whereConditions.onboardingComplete = true;
    } else if (status === "ONBOARDING") {
      whereConditions.onboardingComplete = false;
    }
    
    if (search) {
      whereConditions.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
        { phone: { contains: search } },
      ];
    }
    
    // Fetch users from database
    const users = await prisma.user.findMany({
      where: whereConditions,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        onboardingComplete: true,
        profileImage: true,
        createdAt: true,
        // Exclude password and other sensitive fields
      },
      orderBy: { createdAt: "desc" },
    });
    
    return NextResponse.json({ 
      success: true, 
      data: users 
    });
  } catch (error) {
    console.error("GET users API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}

// POST - Create new user
export async function POST(request: NextRequest) {
  try {
    console.log("POST users API called");
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get user data from request body
    const body = await request.json();
    
    // Validate input
    const result = userCreateSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    const { name, email, phone, password, role, ...otherData } = result.data;
    
    // Check if email already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() }
    });
    
    if (existingUser) {
      return NextResponse.json(
        { 
          success: false, 
          error: "Email already exists", 
          message: "This email is already registered. Please use a different email." 
        },
        { status: 409 }
      );
    }
    
    // Hash password
    const hashedPassword = await hashPassword(password);
    
    // Create new user in database
    const newUser = await prisma.user.create({
      data: {
        name,
        email: email.toLowerCase(),
        phone,
        password: hashedPassword,
        role,
        onboardingComplete: true, // Admin-created users are considered onboarded
        referralCode: generateReferralCode("temp", name), // Will update after user creation
        ...otherData
      }
    });
    
    // Update referral code with actual user ID
    const referralCode = generateReferralCode(newUser.id, name);
    await prisma.user.update({
      where: { id: newUser.id },
      data: { referralCode }
    });
    
    console.log("New user created by admin:", { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role });
    
    // Return user data without password
    const { password: _, ...userWithoutPassword } = newUser;
    
    return NextResponse.json({ 
      success: true, 
      message: "User created successfully",
      data: userWithoutPassword
    });
  } catch (error) {
    console.error("POST users API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}