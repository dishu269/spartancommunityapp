import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { UserRole } from "@/lib/types";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Verify admin authorization
async function verifyAdmin(request: NextRequest) {
  const token = cookies().get("auth-token")?.value;
  
  if (!token) {
    return { authorized: false, message: "Not authenticated" };
  }
  
  const payload = await verifyToken(token);
  
  if (!payload) {
    return { authorized: false, message: "Invalid or expired session" };
  }
  
  // Verify user exists and is an admin
  const user = await prisma.user.findUnique({
    where: { id: payload.id as string }
  });
  
  if (!user || user.role !== UserRole.ADMIN) {
    return { authorized: false, message: "Unauthorized access" };
  }
  
  return { authorized: true, user };
}

// GET - Fetch all referrals with statistics
export async function GET(request: NextRequest) {
  try {
    console.log("GET referrals API called");
    
    // Verify admin authorization
    const auth = await verifyAdmin(request);
    
    if (!auth.authorized) {
      return NextResponse.json(
        { success: false, error: auth.message },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const sortBy = searchParams.get("sortBy") || "clicks";
    const order = searchParams.get("order") || "desc";
    
    // Build filter conditions
    const whereConditions: any = {};
    
    if (userId) {
      whereConditions.referrerId = userId;
    }
    
    // Fetch referrals from database
    const referrals = await prisma.referral.findMany({
      where: whereConditions,
      include: {
        referrer: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
        referredUser: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
      orderBy: {
        [sortBy === "conversions" ? "conversions" : "clicks"]: order === "asc" ? "asc" : "desc",
      },
    });
    
    // Get overall statistics
    const totalClicks = await prisma.referral.aggregate({
      _sum: {
        clicks: true,
      },
    });
    
    const totalConversions = await prisma.referral.aggregate({
      _sum: {
        conversions: true,
      },
    });
    
    // Get top referrers
    const topReferrers = await prisma.referral.groupBy({
      by: ["referrerId"],
      _sum: {
        clicks: true,
        conversions: true,
      },
      orderBy: {
        _sum: {
          conversions: "desc",
        },
      },
      take: 5,
    });
    
    // Fetch user details for top referrers
    const topReferrersWithDetails = await Promise.all(
      topReferrers.map(async (item: any) => {
        const user = await prisma.user.findUnique({
          where: { id: item.referrerId },
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        });
        
        return {
          ...item,
          user,
        };
      })
    );
    
    return NextResponse.json({ 
      success: true, 
      data: {
        referrals,
        statistics: {
          totalClicks: totalClicks._sum.clicks || 0,
          totalConversions: totalConversions._sum.conversions || 0,
          conversionRate: totalClicks._sum.clicks 
            ? ((totalConversions._sum.conversions || 0) / totalClicks._sum.clicks) * 100 
            : 0,
        },
        topReferrers: topReferrersWithDetails,
      }
    });
  } catch (error) {
    console.error("GET referrals API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}