import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { generateToken } from "@/lib/jwt";
import { hashPassword, generateReferralCode } from "@/lib/utils";
import { Pool } from "pg";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

// Register schema with validation
const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  referralCode: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    console.log("Register API called");
    const body = await request.json();
    
    // Validate input
    const result = registerSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    const { name, email, phone, password, referralCode } = result.data;
    
    console.log(`Registration attempt for email: ${email}`);
    
    // Connect to database
    const client = await pool.connect();
    
    try {
      // Check if email already exists
      const existingUserResult = await client.query(
        'SELECT * FROM "User" WHERE email = $1',
        [email.toLowerCase()]
      );
      
      if (existingUserResult.rows.length > 0) {
        console.log("Email already exists");
        return NextResponse.json(
          { 
            success: false, 
            error: "Email already exists", 
            message: "This email is already registered. Please use a different email or login." 
          },
          { status: 409 }
        );
      }
      
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Begin transaction
      await client.query('BEGIN');
      
      // Create new user in database
      const userResult = await client.query(
        `INSERT INTO "User" (
          id, name, email, phone, password, role, onboardingComplete, 
          preferredLanguage, "createdAt", "updatedAt"
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
        ) RETURNING *`,
        [
          `user_${Date.now()}`, // Generate a unique ID
          name,
          email.toLowerCase(),
          phone,
          hashedPassword,
          'DISTRIBUTOR', // Default role
          false, // onboardingComplete
          'en', // preferredLanguage
          new Date(), // createdAt
          new Date(), // updatedAt
        ]
      );
      
      const newUser = userResult.rows[0];
      
      // Generate referral code
      const userReferralCode = generateReferralCode(newUser.id, name);
      
      // Update user with referral code
      await client.query(
        `UPDATE "User" SET "referralCode" = $1 WHERE id = $2`,
        [userReferralCode, newUser.id]
      );
      
      // If user was referred, create referral record
      if (referralCode) {
        // Find referrer by referral code
        const referrerResult = await client.query(
          'SELECT id FROM "User" WHERE "referralCode" = $1',
          [referralCode]
        );
        
        if (referrerResult.rows.length > 0) {
          const referrerId = referrerResult.rows[0].id;
          
          // Create referral record
          await client.query(
            `INSERT INTO "Referral" (
              id, code, clicks, conversions, "referrerId", "referredUserId", "createdAt", "updatedAt"
            ) VALUES (
              $1, $2, $3, $4, $5, $6, $7, $8
            )`,
            [
              `ref_${Date.now()}`, // Generate a unique ID
              referralCode,
              1, // clicks
              1, // conversions
              referrerId,
              newUser.id,
              new Date(), // createdAt
              new Date(), // updatedAt
            ]
          );
          
          // Increment conversions for the referral code
          await client.query(
            `UPDATE "Referral" SET conversions = conversions + 1 WHERE code = $1`,
            [referralCode]
          );
        }
      }
      
      // Commit transaction
      await client.query('COMMIT');
      
      console.log("New user created:", { id: newUser.id, name: newUser.name, email: newUser.email });
      
      // Create user object without password
      const userWithoutPassword = {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        onboardingComplete: newUser.onboardingComplete,
        referralCode: userReferralCode
      };
      
      // Generate JWT token
      const token = await generateToken({
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      });
      
      // Set JWT token in cookie
      cookies().set({
        name: "auth-token",
        value: token,
        httpOnly: true,
        path: "/",
        maxAge: 60 * 60 * 24 * 7, // 7 days
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
      });
      
      // Return user data and redirect path
      return NextResponse.json({ 
        success: true, 
        user: userWithoutPassword,
        redirectTo: "/auth/onboarding"
      });
    } catch (error) {
      // Rollback transaction on error
      await client.query('ROLLBACK');
      console.error("Register API database error:", error);
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Register API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}