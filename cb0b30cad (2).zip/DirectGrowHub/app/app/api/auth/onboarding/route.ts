import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { verifyToken } from "@/lib/jwt";
import { getUserDashboardPath } from "@/lib/utils";
import { Pool } from "pg";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

export async function POST(request: NextRequest) {
  try {
    console.log("Onboarding completion API called");
    
    // Get JWT token from cookies
    const token = cookies().get("auth-token")?.value;
    
    if (!token) {
      console.log("No auth token found");
      return NextResponse.json(
        { 
          success: false, 
          error: "Not authenticated", 
          message: "You must be logged in to complete onboarding." 
        },
        { status: 401 }
      );
    }
    
    // Verify JWT token
    const payload = await verifyToken(token);
    
    if (!payload) {
      console.log("Invalid or expired token");
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid session", 
          message: "Your session has expired. Please log in again." 
        },
        { status: 401 }
      );
    }
    
    // Get user data from request body
    const body = await request.json();
    const { profileData, prospectData } = body;
    
    // Connect to database
    const client = await pool.connect();
    
    try {
      // Begin transaction
      await client.query('BEGIN');
      
      // Update user profile in database
      const updateFields = [];
      const updateValues = [];
      let valueIndex = 1;
      
      if (profileData) {
        if (profileData.fullName) {
          updateFields.push(`name = $${valueIndex}`);
          updateValues.push(profileData.fullName);
          valueIndex++;
        }
        
        if (profileData.phone) {
          updateFields.push(`phone = $${valueIndex}`);
          updateValues.push(profileData.phone);
          valueIndex++;
        }
        
        if (profileData.address) {
          updateFields.push(`address = $${valueIndex}`);
          updateValues.push(profileData.address);
          valueIndex++;
        }
        
        if (profileData.city) {
          updateFields.push(`city = $${valueIndex}`);
          updateValues.push(profileData.city);
          valueIndex++;
        }
        
        if (profileData.state) {
          updateFields.push(`state = $${valueIndex}`);
          updateValues.push(profileData.state);
          valueIndex++;
        }
        
        if (profileData.pincode) {
          updateFields.push(`pincode = $${valueIndex}`);
          updateValues.push(profileData.pincode);
          valueIndex++;
        }
        
        if (profileData.company) {
          updateFields.push(`company = $${valueIndex}`);
          updateValues.push(profileData.company);
          valueIndex++;
        }
      }
      
      // Always set onboardingComplete to true
      updateFields.push(`"onboardingComplete" = $${valueIndex}`);
      updateValues.push(true);
      valueIndex++;
      
      // Add updatedAt
      updateFields.push(`"updatedAt" = $${valueIndex}`);
      updateValues.push(new Date());
      valueIndex++;
      
      // Add user ID to values
      updateValues.push(payload.id);
      
      // Update user
      const updateQuery = `
        UPDATE "User" 
        SET ${updateFields.join(', ')} 
        WHERE id = $${valueIndex}
        RETURNING *
      `;
      
      const userResult = await client.query(updateQuery, updateValues);
      const updatedUser = userResult.rows[0];
      
      // Add prospect if provided
      if (prospectData && prospectData.prospectName && prospectData.prospectPhone) {
        await client.query(
          `INSERT INTO "Prospect" (
            id, name, email, phone, relationship, status, "userId", "createdAt", "updatedAt"
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9
          )`,
          [
            `prospect_${Date.now()}`, // Generate a unique ID
            prospectData.prospectName,
            prospectData.prospectEmail || null,
            prospectData.prospectPhone,
            prospectData.prospectRelation || null,
            'PENDING', // status
            updatedUser.id,
            new Date(), // createdAt
            new Date(), // updatedAt
          ]
        );
        
        console.log("Prospect added for user:", updatedUser.id);
      }
      
      // Commit transaction
      await client.query('COMMIT');
      
      console.log("Onboarding completed for user:", updatedUser.id);
      
      // Return success response with redirect path
      return NextResponse.json({ 
        success: true, 
        message: "Onboarding completed successfully",
        redirectTo: getUserDashboardPath(updatedUser.role)
      });
    } catch (error) {
      // Rollback transaction on error
      await client.query('ROLLBACK');
      console.error("Onboarding API database error:", error);
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Onboarding API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}