import { NextRequest, NextResponse } from "next/server";
import * as bcrypt from "bcryptjs";
import { Pool } from "pg";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

// Mock admin user for testing
const mockAdminUser = {
  id: "admin1",
  name: "Dishant Parihar",
  email: "dishantparihar00@gmail.com",
  password: "$2a$10$XQtV9nt5/mVMGEftGDgkQeRaMH5.iV1wMHVLM7YVfZgQ.j8WUIsIy", // Hashed "Dishu@1997"
  role: "ADMIN"
};

export async function POST(request: NextRequest) {
  try {
    console.log("Test Login API called");
    const body = await request.json();
    const { email, password } = body;
    
    if (!email || !password) {
      return NextResponse.json(
        { 
          success: false, 
          error: "Email and password are required" 
        },
        { status: 400 }
      );
    }
    
    console.log(`Test login attempt for email: ${email}`);
    
    // Try to find user in database
    let user = null;
    let dbConnectionSuccessful = false;
    
    try {
      const client = await pool.connect();
      dbConnectionSuccessful = true;
      
      try {
        const result = await client.query(
          'SELECT * FROM "User" WHERE email = $1',
          [email.toLowerCase()]
        );
        
        if (result.rows.length > 0) {
          user = result.rows[0];
          console.log("User found in database");
        } else {
          console.log("User not found in database");
        }
      } finally {
        client.release();
      }
    } catch (dbError) {
      console.error("Database connection error:", dbError);
      // Continue with mock user if database connection fails
    }
    
    // If database connection failed or user not found, check mock user
    if (!dbConnectionSuccessful || !user) {
      if (email.toLowerCase() === mockAdminUser.email.toLowerCase()) {
        user = mockAdminUser;
        console.log("Using mock admin user");
      } else {
        return NextResponse.json(
          { 
            success: false, 
            error: "User not found",
            dbConnectionSuccessful
          },
          { status: 404 }
        );
      }
    }
    
    // Verify password
    const passwordValid = await bcrypt.compare(password, user.password);
    
    if (!passwordValid) {
      console.log("Invalid password");
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid credentials",
          dbConnectionSuccessful
        },
        { status: 401 }
      );
    }
    
    console.log("Password verified successfully");
    
    // Create user object without password
    const userWithoutPassword = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    };
    
    // Return user data
    return NextResponse.json({ 
      success: true, 
      user: userWithoutPassword,
      dbConnectionSuccessful
    });
  } catch (error) {
    console.error("Test Login API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error",
        message: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    );
  }
}