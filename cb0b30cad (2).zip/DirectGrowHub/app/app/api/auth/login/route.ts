import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { generateToken } from "@/lib/jwt";
import { getUserDashboardPath } from "@/lib/utils";
import { UserRole } from "@/lib/types";
import * as bcrypt from "bcryptjs";
import { Pool } from "pg";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Login schema
const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  rememberMe: z.boolean().optional(),
});

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

// Define a type that matches the structure of the User model
type User = {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  onboardingComplete: boolean;
  phone: string | null;
  profileImage: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  pincode: string | null;
  company: string | null;
  referralCode: string | null;
  preferredLanguage: string;
  createdAt: Date;
  updatedAt: Date;
  leaderId: string | null;
};

// Mock users for fallback when database is not available
const mockUsers = [
  {
    id: "admin1",
    name: "Dishant Parihar",
    email: "dishantparihar00@gmail.com",
    password: "$2a$10$XQtV9nt5/mVMGEftGDgkQeRaMH5.iV1wMHVLM7YVfZgQ.j8WUIsIy", // Hashed "Dishu@1997"
    role: UserRole.ADMIN,
    onboardingComplete: true,
    phone: null,
    profileImage: null,
    address: null,
    city: null,
    state: null,
    pincode: null,
    company: null,
    referralCode: null,
    preferredLanguage: "en",
    createdAt: new Date(),
    updatedAt: new Date(),
    leaderId: null
  },
  {
    id: "user1",
    name: "Riya Sharma",
    email: "user@example.com",
    password: "$2a$10$XQtV9nt5/mVMGEftGDgkQeRaMH5.iV1wMHVLM7YVfZgQ.j8WUIsIy", // Hashed "password123"
    role: UserRole.DISTRIBUTOR,
    onboardingComplete: true,
    phone: null,
    profileImage: null,
    address: null,
    city: null,
    state: null,
    pincode: null,
    company: null,
    referralCode: null,
    preferredLanguage: "en",
    createdAt: new Date(),
    updatedAt: new Date(),
    leaderId: null
  }
];

// Function to compare passwords
async function comparePasswords(plainPassword: string, hashedPassword: string): Promise<boolean> {
  try {
    return await bcrypt.compare(plainPassword, hashedPassword);
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

// Function to find user by email using direct PostgreSQL query
async function findUserByEmail(email: string): Promise<User | null> {
  try {
    console.log(`Finding user with email: ${email}`);
    const client = await pool.connect();
    
    try {
      const result = await client.query(
        'SELECT * FROM "User" WHERE email = $1',
        [email.toLowerCase()]
      );
      
      if (result.rows.length === 0) {
        console.log("No user found in database");
        return null;
      }
      
      console.log("User found in database");
      return result.rows[0] as User;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Database error when finding user:", error);
    
    // Fallback to mock users if database is not available
    console.log("Falling back to mock users");
    const mockUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    return mockUser || null;
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log("Login API called");
    const body = await request.json();
    
    // Validate input
    const result = loginSchema.safeParse(body);
    
    if (!result.success) {
      console.log("Validation failed:", result.error.format());
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid input", 
          details: result.error.format() 
        },
        { status: 400 }
      );
    }
    
    const { email, password, rememberMe } = result.data;
    
    console.log(`Login attempt for email: ${email}`);
    
    // Find user by email
    const user = await findUserByEmail(email);
    
    if (!user) {
      console.log("User not found");
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid credentials", 
          message: "The email or password you entered is incorrect." 
        },
        { status: 401 }
      );
    }
    
    // Verify password
    const passwordValid = await comparePasswords(password, user.password);
    
    if (!passwordValid) {
      console.log("Invalid password");
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid credentials", 
          message: "The email or password you entered is incorrect." 
        },
        { status: 401 }
      );
    }
    
    console.log("Password verified successfully");
    
    // Create user object without password
    const userWithoutPassword = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      onboardingComplete: user.onboardingComplete
    };
    
    // Generate JWT token
    const token = await generateToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    });
    
    console.log("User authenticated, token generated");
    
    // Set cookie expiry
    const cookieExpiry = rememberMe ? 60 * 60 * 24 * 30 : 60 * 60 * 24; // 30 days or 1 day
    
    // Set JWT token in cookie
    cookies().set({
      name: "auth-token",
      value: token,
      httpOnly: true,
      path: "/",
      maxAge: cookieExpiry,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    });
    
    // Determine redirect path based on onboarding status and role
    let redirectTo = getUserDashboardPath(user.role);
    
    if (!user.onboardingComplete && user.role !== UserRole.ADMIN) {
      redirectTo = "/auth/onboarding";
    }
    
    console.log("Redirecting user to:", redirectTo);
    
    // Return user data and redirect path
    return NextResponse.json({ 
      success: true, 
      user: userWithoutPassword,
      redirectTo
    });
  } catch (error) {
    console.error("Login API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}