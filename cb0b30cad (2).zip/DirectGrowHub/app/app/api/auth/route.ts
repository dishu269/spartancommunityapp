import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";

// Define user roles (not exported)
enum UserRole {
  DISTRIBUTOR = "DISTRIBUTOR",
  LEADER = "LEADER",
  ADMIN = "ADMIN"
}

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Mock users for demo
const mockUsers = [
  {
    id: "1",
    name: "Riya Sharma",
    email: "riya@example.com",
    password: "password123",
    role: UserRole.DISTRIBUTOR
  },
  {
    id: "2",
    name: "Arjun Singh",
    email: "arjun@example.com",
    password: "password123",
    role: UserRole.LEADER
  },
  {
    id: "3",
    name: "Dishant Parihar",
    email: "dishantparihar00@gmail.com",
    password: "Dishu@1997",
    role: UserRole.ADMIN
  }
];

// Login schema
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  isAdmin: z.boolean().optional(),
});

// Register schema
const registerSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    // Login handler
    if (action === "login") {
      const result = loginSchema.safeParse(body);
      
      if (!result.success) {
        return NextResponse.json(
          { error: "Invalid input", details: result.error.format() },
          { status: 400 }
        );
      }
      
      const { email, password, isAdmin } = result.data;
      
      // Find user
      const user = mockUsers.find(u => 
        u.email.toLowerCase() === email.toLowerCase() && 
        u.password === password &&
        (isAdmin ? u.role === UserRole.ADMIN : true)
      );
      
      if (!user) {
        return NextResponse.json(
          { error: "Invalid credentials" },
          { status: 401 }
        );
      }
      
      // Create user object without password
      const { password: _, ...userWithoutPassword } = user;
      
      // Set cookie
      cookies().set({
        name: "auth-token",
        value: JSON.stringify(userWithoutPassword),
        httpOnly: true,
        path: "/",
        maxAge: 60 * 60 * 24 * 7, // 1 week
      });
      
      return NextResponse.json({ user: userWithoutPassword });
    }
    
    // Register handler
    if (action === "register") {
      const result = registerSchema.safeParse(body);
      
      if (!result.success) {
        return NextResponse.json(
          { error: "Invalid input", details: result.error.format() },
          { status: 400 }
        );
      }
      
      const { name, email, password } = result.data;
      
      // Check if email already exists
      const emailExists = mockUsers.some(u => 
        u.email.toLowerCase() === email.toLowerCase()
      );
      
      if (emailExists) {
        return NextResponse.json(
          { error: "Email already exists" },
          { status: 409 }
        );
      }
      
      // Create new user
      const newUser = {
        id: `${mockUsers.length + 1}`,
        name,
        email,
        password,
        role: UserRole.DISTRIBUTOR // Default role for new registrations
      };
      
      // In a real app, we would save to database here
      mockUsers.push(newUser);
      
      // Create user object without password
      const { password: _, ...userWithoutPassword } = newUser;
      
      // Set cookie
      cookies().set({
        name: "auth-token",
        value: JSON.stringify(userWithoutPassword),
        httpOnly: true,
        path: "/",
        maxAge: 60 * 60 * 24 * 7, // 1 week
      });
      
      return NextResponse.json({ user: userWithoutPassword });
    }
    
    // Logout handler
    if (action === "logout") {
      cookies().delete("auth-token");
      return NextResponse.json({ success: true });
    }
    
    return NextResponse.json(
      { error: "Invalid action" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Auth API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = cookies().get("auth-token")?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }
    
    const user = JSON.parse(token);
    
    return NextResponse.json({ user });
  } catch (error) {
    console.error("Auth API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}