import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import prisma from "@/lib/prisma";
import * as jwt from 'jsonwebtoken';

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Function to verify JWT token
async function verifyToken(token: string): Promise<any | null> {
  try {
    const JWT_SECRET = process.env.JWT_SECRET || "spartan_community_india_secret_key_change_in_production";
    const payload = jwt.verify(token, JWT_SECRET);
    return payload;
  } catch (error) {
    console.error("JWT verification error:", error);
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    console.log("Session API called");
    
    // Get JWT token from cookies
    const token = cookies().get("auth-token")?.value;
    
    if (!token) {
      console.log("No auth token found");
      return NextResponse.json(
        { 
          authenticated: false, 
          message: "Not authenticated" 
        },
        { status: 401 }
      );
    }
    
    // Verify JWT token
    const payload = await verifyToken(token);
    
    if (!payload) {
      console.log("Invalid or expired token");
      
      // Clear invalid token
      cookies().delete("auth-token");
      
      return NextResponse.json(
        { 
          authenticated: false, 
          message: "Invalid or expired session" 
        },
        { status: 401 }
      );
    }
    
    // Verify user exists in database
    const user = await prisma.user.findUnique({
      where: { id: payload.id as string }
    });
    
    if (!user) {
      console.log("User not found in database");
      
      // Clear invalid token
      cookies().delete("auth-token");
      
      return NextResponse.json(
        { 
          authenticated: false, 
          message: "User not found" 
        },
        { status: 401 }
      );
    }
    
    console.log("Valid session found:", { id: user.id, name: user.name, role: user.role });
    
    // Return user data from database (not token payload)
    return NextResponse.json({ 
      authenticated: true, 
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        onboardingComplete: user.onboardingComplete
      }
    });
  } catch (error) {
    console.error("Session API error:", error);
    return NextResponse.json(
      { 
        authenticated: false, 
        message: "Internal server error" 
      },
      { status: 500 }
    );
  }
}
