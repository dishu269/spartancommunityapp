import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    console.log("Logout API called");
    
    // Clear auth token
    cookies().delete("auth-token");
    
    return NextResponse.json({ 
      success: true, 
      message: "Logged out successfully" 
    });
  } catch (error) {
    console.error("Logout API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        message: "Failed to logout" 
      },
      { status: 500 }
    );
  }
}