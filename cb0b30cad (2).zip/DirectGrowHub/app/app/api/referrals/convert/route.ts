import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, userId } = body;
    
    if (!code || !userId) {
      return NextResponse.json(
        { success: false, error: "Referral code and user ID are required" },
        { status: 400 }
      );
    }
    
    // Find the referral by code
    const referral = await prisma.referral.findUnique({
      where: { code },
    });
    
    if (!referral) {
      return NextResponse.json(
        { success: false, error: "Invalid referral code" },
        { status: 404 }
      );
    }
    
    // Update referral with the new user and increment conversion count
    const updatedReferral = await prisma.referral.update({
      where: { id: referral.id },
      data: { 
        referredUserId: userId,
        conversions: { increment: 1 } 
      },
    });
    
    return NextResponse.json({ 
      success: true, 
      data: { conversions: updatedReferral.conversions } 
    });
  } catch (error) {
    console.error("Referral conversion error:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 }
    );
  }
}