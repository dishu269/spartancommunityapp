import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { verifyToken } from "@/lib/jwt";
import { generateReferralCode } from "@/lib/utils";
import { Pool } from "pg";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

// GET - Get user's referral links
export async function GET(request: NextRequest) {
  try {
    console.log("GET referrals API called");
    
    // Get JWT token from cookies
    const token = cookies().get("auth-token")?.value;
    
    if (!token) {
      console.log("No auth token found");
      return NextResponse.json(
        { 
          success: false, 
          error: "Not authenticated", 
          message: "You must be logged in to access referrals." 
        },
        { status: 401 }
      );
    }
    
    // Verify JWT token
    const payload = await verifyToken(token);
    
    if (!payload) {
      console.log("Invalid or expired token");
      return NextResponse.json(
        { 
          success: false, 
          error: "Invalid session", 
          message: "Your session has expired. Please log in again." 
        },
        { status: 401 }
      );
    }
    
    // Connect to database
    const client = await pool.connect();
    
    try {
      // Get user's referral code
      const userResult = await client.query(
        'SELECT "referralCode" FROM "User" WHERE id = $1',
        [payload.id]
      );
      
      if (userResult.rows.length === 0) {
        return NextResponse.json(
          { 
            success: false, 
            error: "User not found", 
            message: "User not found in the database." 
          },
          { status: 404 }
        );
      }
      
      const referralCode = userResult.rows[0].referralCode;
      
      // If user doesn't have a referral code, generate one
      if (!referralCode) {
        // Get user's name
        const nameResult = await client.query(
          'SELECT name FROM "User" WHERE id = $1',
          [payload.id]
        );
        
        const name = nameResult.rows[0].name;
        
        // Generate referral code
        const newReferralCode = generateReferralCode(payload.id as string, name);
        
        // Update user with referral code
        await client.query(
          'UPDATE "User" SET "referralCode" = $1 WHERE id = $2',
          [newReferralCode, payload.id]
        );
        
        // Create referral record
        await client.query(
          `INSERT INTO "Referral" (
            id, code, clicks, conversions, "referrerId", "createdAt", "updatedAt"
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7
          )`,
          [
            `ref_${Date.now()}`, // Generate a unique ID
            newReferralCode,
            0, // clicks
            0, // conversions
            payload.id,
            new Date(), // createdAt
            new Date(), // updatedAt
          ]
        );
        
        // Get referral links
        const referralLinks = {
          general: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${newReferralCode}`,
          team: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${newReferralCode}?type=team`,
          lead: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${newReferralCode}?type=lead`
        };
        
        return NextResponse.json({ 
          success: true, 
          data: {
            referralCode: newReferralCode,
            referralLinks,
            stats: {
              clicks: 0,
              conversions: 0,
              conversionRate: 0
            }
          }
        });
      }
      
      // Get referral statistics
      const statsResult = await client.query(
        'SELECT clicks, conversions FROM "Referral" WHERE code = $1',
        [referralCode]
      );
      
      const stats = statsResult.rows.length > 0 
        ? statsResult.rows[0] 
        : { clicks: 0, conversions: 0 };
      
      // Calculate conversion rate
      const conversionRate = stats.clicks > 0 
        ? (stats.conversions / stats.clicks) * 100 
        : 0;
      
      // Get referral links
      const referralLinks = {
        general: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${referralCode}`,
        team: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${referralCode}?type=team`,
        lead: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/ref/${referralCode}?type=lead`
      };
      
      return NextResponse.json({ 
        success: true, 
        data: {
          referralCode,
          referralLinks,
          stats: {
            clicks: stats.clicks,
            conversions: stats.conversions,
            conversionRate
          }
        }
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("GET referrals API error:", error);
    return NextResponse.json(
      { 
        success: false, 
        error: "Internal server error", 
        message: "An unexpected error occurred. Please try again later." 
      },
      { status: 500 }
    );
  }
}