import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// Mark route as dynamic to prevent caching
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code } = body;
    
    if (!code) {
      return NextResponse.json(
        { success: false, error: "Referral code is required" },
        { status: 400 }
      );
    }
    
    // Find the referral by code
    const referral = await prisma.referral.findUnique({
      where: { code },
    });
    
    if (!referral) {
      return NextResponse.json(
        { success: false, error: "Invalid referral code" },
        { status: 404 }
      );
    }
    
    // Increment click count
    const updatedReferral = await prisma.referral.update({
      where: { id: referral.id },
      data: { clicks: { increment: 1 } },
    });
    
    return NextResponse.json({ 
      success: true, 
      data: { clicks: updatedReferral.clicks } 
    });
  } catch (error) {
    console.error("Referral tracking error:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 }
    );
  }
}