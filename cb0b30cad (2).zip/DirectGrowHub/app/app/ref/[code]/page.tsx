import { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Star, CheckCircle, Users, Award, TrendingUp, User } from "lucide-react";
import { Pool } from "pg";

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

export const metadata: Metadata = {
  title: "Join Spartan Community India - Referral Program",
  description: "Join our growing community of successful distributors and start your journey to financial freedom.",
};

// Generate static params for the most common referral codes
export async function generateStaticParams() {
  try {
    const client = await pool.connect();
    
    try {
      const result = await client.query(
        'SELECT code FROM "Referral" ORDER BY clicks DESC LIMIT 10'
      );
      
      return result.rows.map((row) => ({
        code: row.code,
      }));
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Error generating static params:", error);
    return [];
  }
}

// Track referral click and get referrer details
async function getReferralData(code: string, type: string = 'general') {
  try {
    const client = await pool.connect();
    
    try {
      // Find the referral by code
      const referralResult = await client.query(
        'SELECT r.*, u.name, u.role FROM "Referral" r JOIN "User" u ON r."referrerId" = u.id WHERE r.code = $1',
        [code]
      );
      
      if (referralResult.rows.length === 0) {
        return null;
      }
      
      const referral = referralResult.rows[0];
      
      // Increment click count
      await client.query(
        'UPDATE "Referral" SET clicks = clicks + 1 WHERE code = $1',
        [code]
      );
      
      // Get testimonials
      const testimonialsResult = await client.query(
        'SELECT * FROM "Testimonial" WHERE "isActive" = true ORDER BY "createdAt" DESC LIMIT 3'
      );
      
      // Get achievements
      const achievementsResult = await client.query(
        'SELECT * FROM "Achievement" WHERE "isActive" = true ORDER BY "order" ASC'
      );
      
      // Get landing page content
      const landingPageContentResult = await client.query(
        'SELECT * FROM "LandingPageContent" WHERE "isActive" = true LIMIT 1'
      );
      
      return {
        referral,
        testimonials: testimonialsResult.rows,
        achievements: achievementsResult.rows,
        landingPageContent: landingPageContentResult.rows[0] || null,
        referralType: type
      };
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Error fetching referral data:", error);
    
    // Return mock data as fallback
    return {
      referral: {
        id: "mock_referral",
        code,
        clicks: 0,
        conversions: 0,
        referrerId: "mock_user",
        name: "Distributor",
        role: "DISTRIBUTOR"
      },
      testimonials: [
        {
          id: "1",
          name: "Priya Sharma",
          role: "Team Leader",
          content: "Joining Spartan Community India was the best decision I've made. In just 6 months, I built a team of 30 distributors and doubled my monthly income!",
          imageUrl: "https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg",
          rating: 5,
        },
        {
          id: "2",
          name: "Rajesh Kumar",
          role: "Distributor",
          content: "The training and support I received helped me understand the business quickly. Now I'm earning a steady income while working flexible hours.",
          imageUrl: "https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg",
          rating: 5,
        },
        {
          id: "3",
          name: "Ananya Patel",
          role: "New Distributor",
          content: "As a college student, I was looking for a part-time opportunity. Spartan Community India provided me with the perfect platform to earn while I learn.",
          imageUrl: "https://cdn.pixabay.com/photo/2024/01/06/09/38/indian-8490981_1280.jpg",
          rating: 4,
        },
      ],
      achievements: [
        {
          id: "1",
          title: "5,000+ Active Distributors",
          description: "Join our growing community of successful entrepreneurs across India",
          imageUrl: "/icons/users.svg",
        },
        {
          id: "2",
          title: "₹10 Crore+ Monthly Sales",
          description: "Be part of our success story with impressive monthly revenue",
          imageUrl: "/icons/chart.svg",
        },
        {
          id: "3",
          title: "100+ Training Modules",
          description: "Access comprehensive training to develop your skills and knowledge",
          imageUrl: "/icons/book.svg",
        },
        {
          id: "4",
          title: "Pan-India Presence",
          description: "Connect with distributors and customers across the country",
          imageUrl: "/icons/map.svg",
        },
      ],
      landingPageContent: null,
      referralType: type
    };
  }
}

export default async function ReferralPage({ params, searchParams }: { params: { code: string }, searchParams: { type?: string } }) {
  const referralType = searchParams.type || 'general';
  const data = await getReferralData(params.code, referralType);

  // If referral code doesn't exist, show 404
  if (!data) {
    notFound();
  }

  const { referral, testimonials, achievements, landingPageContent } = data;

  // Default content if landing page content is not set
  const content = landingPageContent || {
    heroTitle: "Join Spartan Community India",
    heroSubtitle: "Start your journey to financial freedom with India's fastest growing direct selling community",
    heroImageUrl: "https://img.freepik.com/premium-photo/diverse-group-business-people-celebrate-success-cheering-with-their-arms-raised_14117-784329.jpg",
    aboutTitle: "Why Join Our Community?",
    aboutContent: "Spartan Community India provides you with the tools, training, and support you need to succeed in the direct selling industry. Join thousands of successful distributors who are building their financial future with us.",
    aboutImageUrl: "https://c8.alamy.com/comp/PXR7YX/happy-business-people-celebrate-success-looking-at-laptop-screen-in-the-office-successful-corporate-partners-and-coworkers-winners-excited-of-victor-PXR7YX.jpg",
    ctaTitle: "Ready to Start Your Journey?",
    ctaContent: "Join our community today and take the first step towards financial independence. Our proven system and supportive community will help you achieve your goals.",
    ctaButtonText: "Register Now",
  };

  // Customize content based on referral type
  let typeSpecificContent = {
    title: content.heroTitle,
    subtitle: content.heroSubtitle,
    ctaText: "Join Now"
  };

  if (referralType === 'team') {
    typeSpecificContent = {
      title: "Join Our Team at Spartan Community India",
      subtitle: `${referral.name} invites you to join their team and start your journey to success`,
      ctaText: "Join Team"
    };
  } else if (referralType === 'lead') {
    typeSpecificContent = {
      title: "Discover Spartan Community India",
      subtitle: `${referral.name} thought you might be interested in our products and opportunities`,
      ctaText: "Learn More"
    };
  }

  // Default testimonials if none exist
  const displayTestimonials = testimonials.length > 0 ? testimonials : [
    {
      id: "1",
      name: "Priya Sharma",
      role: "Team Leader",
      content: "Joining Spartan Community India was the best decision I've made. In just 6 months, I built a team of 30 distributors and doubled my monthly income!",
      imageUrl: "https://i.pinimg.com/736x/70/14/9e/70149ee939cbfd6645bf6e9d0560c118.jpg",
      rating: 5,
    },
    {
      id: "2",
      name: "Rajesh Kumar",
      role: "Distributor",
      content: "The training and support I received helped me understand the business quickly. Now I'm earning a steady income while working flexible hours.",
      imageUrl: "https://i.pinimg.com/236x/01/b8/7b/01b87b2adbbbef22236ee5c132c2351d.jpg",
      rating: 5,
    },
    {
      id: "3",
      name: "Ananya Patel",
      role: "New Distributor",
      content: "As a college student, I was looking for a part-time opportunity. Spartan Community India provided me with the perfect platform to earn while I learn.",
      imageUrl: "https://cdn.pixabay.com/photo/2024/01/06/09/38/indian-8490981_1280.jpg",
      rating: 4,
    },
  ];

  // Default achievements if none exist
  const displayAchievements = achievements.length > 0 ? achievements : [
    {
      id: "1",
      title: "5,000+ Active Distributors",
      description: "Join our growing community of successful entrepreneurs across India",
      imageUrl: "/icons/users.svg",
    },
    {
      id: "2",
      title: "₹10 Crore+ Monthly Sales",
      description: "Be part of our success story with impressive monthly revenue",
      imageUrl: "/icons/chart.svg",
    },
    {
      id: "3",
      title: "100+ Training Modules",
      description: "Access comprehensive training to develop your skills and knowledge",
      imageUrl: "/icons/book.svg",
    },
    {
      id: "4",
      title: "Pan-India Presence",
      description: "Connect with distributors and customers across the country",
      imageUrl: "/icons/map.svg",
    },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Referral Banner */}
      <div className="bg-primary text-white py-2 px-4 text-center text-sm">
        <p>
          You were invited by <span className="font-semibold">{referral.name}</span>
        </p>
      </div>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-primary to-primary-light text-white py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4 flex flex-col items-center text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">{typeSpecificContent.title}</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl">{typeSpecificContent.subtitle}</p>
          <Link 
            href={`/auth/register?ref=${params.code}&type=${referralType}`} 
            className="btn-secondary text-lg px-8 py-3"
          >
            {typeSpecificContent.ctaText} <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-16 bg-white dark:bg-background">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Our Achievements</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {displayAchievements.map((achievement, index) => (
              <div key={achievement.id} className="card p-6 text-center">
                <div className="flex justify-center mb-4">
                  {achievement.imageUrl ? (
                    <div className="relative h-16 w-16">
                      <Image 
                        src={achievement.imageUrl} 
                        alt={achievement.title}
                        fill
                        className="object-contain"
                      />
                    </div>
                  ) : (
                    <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                      {index === 0 ? (
                        <Users className="h-8 w-8 text-primary" />
                      ) : index === 1 ? (
                        <TrendingUp className="h-8 w-8 text-primary" />
                      ) : index === 2 ? (
                        <Award className="h-8 w-8 text-primary" />
                      ) : (
                        <CheckCircle className="h-8 w-8 text-primary" />
                      )}
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-semibold mb-2">{achievement.title}</h3>
                <p className="text-muted-foreground">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{content.aboutTitle}</h2>
              <p className="text-muted-foreground mb-6">{content.aboutContent}</p>
              
              <div className="space-y-3">
                <div className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2" />
                  <p>Comprehensive training and support system</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2" />
                  <p>Flexible working hours to fit your lifestyle</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2" />
                  <p>Unlimited earning potential based on your effort</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 mr-2" />
                  <p>Community of like-minded entrepreneurs</p>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2">
              <div className="relative h-64 md:h-96 w-full rounded-lg overflow-hidden">
                <Image 
                  src={content.aboutImageUrl || "https://c8.alamy.com/comp/PXR7YX/happy-business-people-celebrate-success-looking-at-laptop-screen-in-the-office-successful-corporate-partners-and-coworkers-winners-excited-of-victor-PXR7YX.jpg"} 
                  alt="About Spartan Community India"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-white dark:bg-background">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Success Stories</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {displayTestimonials.map((testimonial) => (
              <div key={testimonial.id} className="card p-6">
                <div className="flex items-center mb-4">
                  <div className="mr-4">
                    <div className="relative h-16 w-16 rounded-full overflow-hidden">
                      {testimonial.imageUrl ? (
                        <Image 
                          src={testimonial.imageUrl} 
                          alt={testimonial.name}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="h-full w-full bg-primary/10 flex items-center justify-center">
                          <User className="h-8 w-8 text-primary" />
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold">{testimonial.name}</h3>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
                
                <div className="flex mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-500 fill-yellow-500' : 'text-muted'}`} 
                    />
                  ))}
                </div>
                
                <p className="text-muted-foreground">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-primary-light text-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">{content.ctaTitle}</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">{content.ctaContent}</p>
          <Link 
            href={`/auth/register?ref=${params.code}&type=${referralType}`} 
            className="btn-secondary text-lg px-8 py-3"
          >
            {typeSpecificContent.ctaText} <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Spartan Community India. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}