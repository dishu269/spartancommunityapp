"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CheckCircle, Users, Award, BookOpen, BarChart, Shield } from "lucide-react";

export default function Home() {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [featuresRef, featuresInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [statsRef, statsInView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const [count, setCount] = useState({ users: 0, modules: 0, teams: 0 });

  useEffect(() => {
    if (statsInView) {
      const interval = setInterval(() => {
        setCount(prev => ({
          users: prev.users >= 5000 ? 5000 : prev.users + 50,
          modules: prev.modules >= 120 ? 120 : prev.modules + 1,
          teams: prev.teams >= 350 ? 350 : prev.teams + 3,
        }));
      }, 20);
      
      return () => clearInterval(interval);
    }
  }, [statsInView]);

  const features = [
    {
      icon: <BookOpen className="h-10 w-10 text-primary" />,
      title: "Structured Training",
      description: "Access micro-learning content with videos, PDFs, and infographics that you can complete at your own pace."
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Team Management",
      description: "Leaders can track team progress, provide coaching, and analyze performance metrics in real-time."
    },
    {
      icon: <Award className="h-10 w-10 text-primary" />,
      title: "Gamification",
      description: "Earn badges, certificates, and recognition as you complete training modules and achieve sales targets."
    },
    {
      icon: <BarChart className="h-10 w-10 text-primary" />,
      title: "Progress Tracking",
      description: "Monitor your growth with detailed insights on completed modules, leads generated, and earnings."
    },
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Compliance Tools",
      description: "Stay updated with mandatory compliance lessons and policy updates requiring digital acknowledgment."
    },
    {
      icon: <ArrowRight className="h-10 w-10 text-primary" />,
      title: "Lead Generation",
      description: "Create shareable referral links, QR codes, and simple landing pages to attract new prospects."
    }
  ];

  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full bg-gradient-to-b from-primary to-primary-light text-white">
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center">
          <motion.div 
            className="md:w-1/2 mb-8 md:mb-0"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Welcome to <span className="text-secondary">Spartan Community India</span>
            </h1>
            <p className="text-lg md:text-xl mb-6 opacity-90">
              Streamline your distributor journey with our mobile-first platform designed for direct-selling success in India.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/auth/register" className="btn-secondary">
                Get Started
              </Link>
              <Link href="/auth/login" className="bg-white text-primary hover:bg-gray-100 font-medium py-2 px-4 rounded-md transition-all duration-200 shadow-sm hover:shadow-md text-center">
                Login
              </Link>
            </div>
          </motion.div>
          <motion.div 
            className="md:w-1/2 relative h-[400px] md:h-[500px]"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Image 
              src="https://i.pinimg.com/736x/3a/1c/6d/3a1c6df840530f7f9e172fd5a75c15b9.jpg" 
              alt="Spartan Community India Dashboard" 
              fill
              className="object-contain rounded-lg shadow-xl"
              priority
            />
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section 
        ref={featuresRef}
        className="w-full py-16 bg-white dark:bg-background"
      >
        <div className="max-w-6xl mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={featuresInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features for Growth</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to succeed in your direct-selling business, all in one place.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="card p-6 flex flex-col items-start"
                initial={{ opacity: 0, y: 20 }}
                animate={featuresInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="mb-4 p-3 bg-primary/10 rounded-lg">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section 
        ref={statsRef}
        className="w-full py-16 bg-muted dark:bg-muted/50"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="card text-center p-8"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-4xl font-bold text-primary mb-2">{count.users.toLocaleString()}+</h3>
              <p className="text-lg text-muted-foreground">Active Distributors</p>
            </motion.div>
            <motion.div 
              className="card text-center p-8"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <h3 className="text-4xl font-bold text-primary mb-2">{count.modules}+</h3>
              <p className="text-lg text-muted-foreground">Training Modules</p>
            </motion.div>
            <motion.div 
              className="card text-center p-8"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={statsInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h3 className="text-4xl font-bold text-primary mb-2">{count.teams}+</h3>
              <p className="text-lg text-muted-foreground">Teams Growing</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Personas Section */}
      <section 
        ref={ref}
        className="w-full py-16 bg-white dark:bg-background"
      >
        <div className="max-w-6xl mx-auto px-4">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Designed for Everyone in Your Team</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Whether you're just starting or leading a team, Spartan Community India has tools tailored for your success.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, x: -20 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
              transition={{ duration: 0.5 }}
            >
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image 
                  src="https://media.istockphoto.com/id/1470128316/photo/young-indian-woman-using-two-smartphones.jpg?s=1024x1024&w=is&k=20&c=_LLJKYnwGl4R8wWSiRWG2z1ief1mR5XpDPqaCJJJsDw=" 
                  alt="New Distributor" 
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">New Distributor</h3>
              <p className="text-muted-foreground mb-4">
                Perfect for beginners like Riya (23) who primarily use smartphones and need step-by-step guidance.
              </p>
              <ul className="space-y-2">
                {["Easy mobile signup", "Guided onboarding", "Bite-sized training"].map((item, i) => (
                  <li key={i} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-2" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image 
                  src="https://c8.alamy.com/comp/2H2X2MY/two-happy-diverse-business-men-analyzing-financial-data-using-digital-tablet-2H2X2MY.jpg" 
                  alt="Team Leader" 
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">Team Leader</h3>
              <p className="text-muted-foreground mb-4">
                Designed for leaders like Arjun who manage teams of 20-50 distributors and need visibility tools.
              </p>
              <ul className="space-y-2">
                {["Team analytics dashboard", "Performance tracking", "Coaching tools"].map((item, i) => (
                  <li key={i} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-2" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, x: 20 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative h-48 mb-4 rounded-md overflow-hidden">
                <Image 
                  src="https://as2.ftcdn.net/v2/jpg/03/87/11/63/1000_F_387116344_yxApYuCOH7CxKD4vhJKJiEBER0rcKdV9.jpg" 
                  alt="Admin/Company Ops" 
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">Admin/Company Ops</h3>
              <p className="text-muted-foreground mb-4">
                Empowers administrators like Priya to manage content, compliance, and analyze macro metrics.
              </p>
              <ul className="space-y-2">
                {["Content management", "Compliance oversight", "Company-wide analytics"].map((item, i) => (
                  <li key={i} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-2" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 bg-gradient-to-r from-primary to-primary-light text-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Grow Your Business?</h2>
            <p className="text-lg md:text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Join thousands of successful distributors who are transforming their direct-selling journey with Spartan Community India.
            </p>
            <Link href="/auth/register" className="btn-secondary inline-block">
              Get Started Today
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}