const fetch = require('node-fetch');

const BASE_URL = 'http://localhost:3000';

async function testAdminEndpoints() {
  console.log('Starting Admin API endpoint tests...');
  
  const results = [];
  let authToken = '';
  
  // First login to get the auth token
  try {
    console.log('Logging in to get auth token...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'Dishantasclepius@gmail.com', password: 'Dishu@1997' }),
    });
    
    // Extract the auth token from the Set-Cookie header
    const cookies = loginResponse.headers.get('set-cookie');
    if (cookies) {
      const match = cookies.match(/auth-token=([^;]+)/);
      if (match && match[1]) {
        authToken = match[1];
        console.log('Auth token obtained successfully');
      }
    }
    
    if (!authToken) {
      console.error('Failed to obtain auth token');
      return;
    }
    
    // Define admin API endpoints to test
    const adminEndpoints = [
      { method: 'GET', url: '/api/admin/users', name: 'Get Users' },
      { method: 'GET', url: '/api/admin/referrals', name: 'Get Referrals' },
      { method: 'GET', url: '/api/admin/content', name: 'Get Content' },
    ];
    
    // Test each admin endpoint
    for (const endpoint of adminEndpoints) {
      console.log(`Testing ${endpoint.name} (${endpoint.url})...`);
      
      try {
        const response = await fetch(`${BASE_URL}${endpoint.url}`, {
          method: endpoint.method,
          headers: {
            'Content-Type': 'application/json',
            'Cookie': `auth-token=${authToken}`
          },
        });
        
        const responseText = await response.text();
        let data;
        try {
          data = JSON.parse(responseText);
        } catch (e) {
          data = { text: responseText };
        }
        
        console.log(`${endpoint.name} status: ${response.status}`);
        
        if (response.status === 200) {
          console.log(`${endpoint.name} response type:`, typeof data);
          if (Array.isArray(data)) {
            console.log(`${endpoint.name} response: Array with ${data.length} items`);
            if (data.length > 0) {
              console.log('Sample item:', JSON.stringify(data[0], null, 2));
            }
          } else {
            console.log(`${endpoint.name} response:`, JSON.stringify(data, null, 2));
          }
        } else {
          console.log(`${endpoint.name} response:`, JSON.stringify(data, null, 2));
        }
        
        results.push({
          endpoint: endpoint.url,
          status: response.status,
          success: response.status >= 200 && response.status < 300,
          data: data
        });
      } catch (error) {
        console.error(`Error testing ${endpoint.name}:`, error.message);
        results.push({
          endpoint: endpoint.url,
          status: 'Error',
          success: false,
          error: error.message
        });
      }
    }
  } catch (error) {
    console.error('Error during login:', error.message);
  }
  
  // Print summary
  console.log('\nAdmin API Test Results:');
  console.log('======================');
  
  for (const result of results) {
    console.log(`${result.endpoint}: ${result.success ? 'SUCCESS' : 'FAILED'} (Status: ${result.status})`);
  }
  
  return results;
}

testAdminEndpoints().catch(console.error);
