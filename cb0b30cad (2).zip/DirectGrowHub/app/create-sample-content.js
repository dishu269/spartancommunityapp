const { PrismaClient } = require('@prisma/client');

async function createSampleContent() {
  console.log('Creating sample content...');
  
  try {
    // Initialize Prisma client
    const prisma = new PrismaClient();
    
    // Create sample content
    const content = await prisma.content.create({
      data: {
        title: 'Welcome to Spartan Community India',
        description: 'An introduction to our community and how to get started.',
        type: 'DOCUMENT',
        format: 'PDF',
        url: 'https://example.com/welcome-guide.pdf',
        fileSize: '1.2 MB',
        uploadedBy: 'cuid_admin_user', // Admin user ID
        isActive: true
      }
    });
    
    console.log('Sample content created:', content);
    
    // Create sample testimonial
    const testimonial = await prisma.testimonial.create({
      data: {
        name: 'Rajesh Kumar',
        role: 'Team Leader',
        content: 'Joining Spartan Community has been a game-changer for my career. The support and training provided are exceptional!',
        rating: 5,
        isActive: true
      }
    });
    
    console.log('Sample testimonial created:', testimonial);
    
    // Create sample referral
    const referral = await prisma.referral.create({
      data: {
        code: 'WELCOME2025',
        clicks: 10,
        conversions: 2,
        referrerId: 'cuid_admin_user' // Admin user ID
      }
    });
    
    console.log('Sample referral created:', referral);
    
    // Close the Prisma client
    await prisma.$disconnect();
    console.log('Sample data creation completed successfully');
    
    return {
      success: true,
      content,
      testimonial,
      referral
    };
  } catch (error) {
    console.error('Sample data creation failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

createSampleContent().catch(console.error);
