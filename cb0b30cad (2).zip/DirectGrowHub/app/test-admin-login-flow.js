const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

// Function to compare passwords
async function comparePasswords(plainPassword, hashedPassword) {
  try {
    return await bcrypt.compare(plainPassword, hashedPassword);
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

// Function to find user by email using direct PostgreSQL query
async function findUserByEmail(email) {
  try {
    console.log(`Finding user with email: ${email}`);
    const client = await pool.connect();
    
    try {
      // Use case-insensitive query
      const result = await client.query(
        'SELECT * FROM "User" WHERE LOWER(email) = LOWER($1)',
        [email]
      );
      
      if (result.rows.length === 0) {
        console.log("No user found in database");
        return null;
      }
      
      console.log("User found in database");
      return result.rows[0];
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Database error when finding user:", error);
    return null;
  }
}

// Function to generate JWT token
function generateToken(payload) {
  const JWT_SECRET = process.env.JWT_SECRET || "spartan_community_india_secret_key_change_in_production";
  const TOKEN_EXPIRATION = 60 * 60 * 24 * 7; // 7 days
  
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: TOKEN_EXPIRATION
  });
}

// Test the login flow
async function testLoginFlow() {
  const email = 'Dishantasclepius@gmail.com';
  const password = 'Dishu@1997';
  
  console.log(`Testing login flow for email: ${email}`);
  
  // Step 1: Find user by email
  const user = await findUserByEmail(email);
  
  if (!user) {
    console.log("Login failed: User not found");
    return;
  }
  
  console.log(`User found: ${user.name} (${user.email}), Role: ${user.role}`);
  
  // Step 2: Verify password
  const passwordValid = await comparePasswords(password, user.password);
  
  if (!passwordValid) {
    console.log("Login failed: Invalid password");
    return;
  }
  
  console.log("Password verified successfully");
  
  // Step 3: Generate JWT token
  const token = generateToken({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role
  });
  
  console.log("JWT token generated successfully");
  console.log("Login flow completed successfully");
}

// Run the test
testLoginFlow();
