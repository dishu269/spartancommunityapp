"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Settings, 
  BarChart, 
  Bell, 
  Calendar, 
  ChevronDown, 
  ChevronRight,
  LogOut,
  Video,
  Shield,
  Key
} from "lucide-react";

const AdminSidebar = () => {
  const pathname = usePathname();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>("dashboard");

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };

  const menuItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      href: "/admin/dashboard",
      active: pathname === "/admin/dashboard",
    },
    {
      id: "users",
      label: "Users",
      icon: <Users className="h-5 w-5" />,
      href: "/admin/users",
      active: pathname?.includes("/admin/users"),
    },
    {
      id: "content",
      label: "Content",
      icon: <FileText className="h-5 w-5" />,
      href: "/admin/content",
      active: pathname?.includes("/admin/content"),
    },
    {
      id: "videos",
      label: "Videos",
      icon: <Video className="h-5 w-5" />,
      href: "/admin/videos",
      active: pathname?.includes("/admin/videos"),
    },
    {
      id: "analytics",
      label: "Analytics",
      icon: <BarChart className="h-5 w-5" />,
      href: "/admin/analytics",
      active: pathname?.includes("/admin/analytics"),
      submenu: [
        {
          label: "Team Growth",
          href: "/admin/analytics/team-growth",
          active: pathname === "/admin/analytics/team-growth",
        },
        {
          label: "Sales Performance",
          href: "/admin/analytics/sales",
          active: pathname === "/admin/analytics/sales",
        },
        {
          label: "Training Metrics",
          href: "/admin/analytics/training",
          active: pathname === "/admin/analytics/training",
        },
      ],
    },
    {
      id: "notifications",
      label: "Notifications",
      icon: <Bell className="h-5 w-5" />,
      href: "/admin/notifications",
      active: pathname?.includes("/admin/notifications"),
    },
    {
      id: "events",
      label: "Events",
      icon: <Calendar className="h-5 w-5" />,
      href: "/admin/events",
      active: pathname?.includes("/admin/events"),
    },
    {
      id: "security",
      label: "Security",
      icon: <Shield className="h-5 w-5" />,
      href: "/admin/security",
      active: pathname?.includes("/admin/security"),
      new: true,
    },
    {
      id: "settings",
      label: "Settings",
      icon: <Settings className="h-5 w-5" />,
      href: "/admin/settings",
      active: pathname?.includes("/admin/settings"),
    },
  ];

  return (
    <div className={`h-screen bg-white dark:bg-muted border-r border-border transition-all duration-300 ${isCollapsed ? "w-16" : "w-64"} fixed left-0 top-0 z-30`}>
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-border flex items-center justify-between">
          {!isCollapsed && (
            <Link href="/admin/dashboard" className="flex items-center">
              <span className="text-xl font-bold text-primary">
                Spartan <span className="text-secondary">Community</span>
              </span>
            </Link>
          )}
          <button
            onClick={toggleCollapse}
            className="p-1 rounded-md hover:bg-muted transition-colors duration-200"
          >
            {isCollapsed ? (
              <ChevronRight className="h-5 w-5" />
            ) : (
              <ChevronLeft className="h-5 w-5" />
            )}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-2 space-y-1">
            {menuItems.map((item) => (
              <div key={item.id}>
                {item.submenu ? (
                  <div>
                    <button
                      onClick={() => toggleSection(item.id)}
                      className={`w-full flex items-center justify-between p-2 rounded-md transition-colors duration-200 ${
                        item.active
                          ? "bg-primary text-white"
                          : "hover:bg-muted"
                      } ${isCollapsed ? "justify-center" : ""}`}
                    >
                      <div className="flex items-center">
                        <span className={`${isCollapsed ? "mr-0" : "mr-3"} relative`}>
                          {item.icon}
                          {item.new && !isCollapsed && (
                            <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full"></span>
                          )}
                        </span>
                        {!isCollapsed && (
                          <span className="relative">
                            {item.label}
                            {item.new && (
                              <span className="ml-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 text-xs px-1.5 py-0.5 rounded-full">
                                New
                              </span>
                            )}
                          </span>
                        )}
                      </div>
                      {!isCollapsed && (
                        <span>
                          {expandedSection === item.id ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </span>
                      )}
                    </button>
                    {expandedSection === item.id && !isCollapsed && (
                      <div className="ml-8 mt-1 space-y-1">
                        {item.submenu.map((subitem) => (
                          <Link
                            key={subitem.href}
                            href={subitem.href}
                            className={`block p-2 rounded-md transition-colors duration-200 ${
                              subitem.active
                                ? "bg-primary/10 text-primary"
                                : "hover:bg-muted"
                            }`}
                          >
                            {subitem.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className={`flex items-center p-2 rounded-md transition-colors duration-200 ${
                      item.active
                        ? "bg-primary text-white"
                        : "hover:bg-muted"
                    } ${isCollapsed ? "justify-center" : ""}`}
                  >
                    <span className={`${isCollapsed ? "mr-0" : "mr-3"} relative`}>
                      {item.icon}
                      {item.new && isCollapsed && (
                        <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full"></span>
                      )}
                    </span>
                    {!isCollapsed && (
                      <span className="relative">
                        {item.label}
                        {item.new && (
                          <span className="ml-2 bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 text-xs px-1.5 py-0.5 rounded-full">
                            New
                          </span>
                        )}
                      </span>
                    )}
                  </Link>
                )}
              </div>
            ))}
          </nav>
        </div>

        <div className="p-4 border-t border-border">
          <Link
            href="/auth/logout"
            className={`flex items-center p-2 text-danger hover:bg-danger/10 rounded-md transition-colors duration-200 ${
              isCollapsed ? "justify-center" : ""
            }`}
          >
            <LogOut className={`h-5 w-5 ${isCollapsed ? "mr-0" : "mr-3"}`} />
            {!isCollapsed && <span>Logout</span>}
          </Link>
        </div>
      </div>
    </div>
  );
};

// Import missing ChevronLeft component
const ChevronLeft = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="m15 18-6-6 6-6" />
  </svg>
);

export default AdminSidebar;