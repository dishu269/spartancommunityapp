"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { 
  Menu, 
  X, 
  User, 
  LogOut, 
  Settings, 
  ChevronDown,
  Shield,
  Bell,
  Search
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/components/ui/use-toast";
import ProfileAvatar from "@/components/profile-avatar";
import { UserRole } from "@/lib/types";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const { toast } = useToast();

  // Handle scroll event to change header style
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
    setIsProfileOpen(false);
  }, [pathname]);

  const handleLogout = async () => {
    await logout();
  };

  const showAdminInfo = () => {
    toast({
      title: "Admin Access",
      description: "Click this icon to access the admin dashboard. Only authorized administrators can log in."
    });
  };

  return (
    <header 
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled 
          ? "bg-white/80 dark:bg-background/80 backdrop-blur-md shadow-sm" 
          : "bg-white dark:bg-background"
      }`}
    >
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-xl font-bold">Spartan Community India</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {user && (
              <>
                <Link 
                  href="/dashboard" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/dashboard" || pathname.startsWith("/dashboard/")
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Dashboard
                </Link>
                <Link 
                  href="/dashboard/training" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/dashboard/training" || pathname.startsWith("/dashboard/training/")
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Training
                </Link>
                <Link 
                  href="/dashboard/leads" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/dashboard/leads" || pathname.startsWith("/dashboard/leads/")
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Leads
                </Link>
                <Link 
                  href="/dashboard/team" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/dashboard/team" || pathname.startsWith("/dashboard/team/")
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Team
                </Link>
                <Link 
                  href="/dashboard/referrals" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/dashboard/referrals" || pathname.startsWith("/dashboard/referrals/")
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Referrals
                </Link>
              </>
            )}
            
            {!user && (
              <>
                <Link 
                  href="/auth/login" 
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === "/auth/login"
                      ? "text-primary"
                      : "text-foreground hover:bg-muted"
                  }`}
                >
                  Login
                </Link>
                <Link 
                  href="/auth/register" 
                  className="btn-primary"
                >
                  Register
                </Link>
              </>
            )}
          </nav>

          {/* Desktop User Menu */}
          {user && (
            <div className="hidden md:flex items-center space-x-4">
              <button className="p-2 rounded-full hover:bg-muted transition-colors">
                <Search className="h-5 w-5 text-muted-foreground" />
              </button>
              
              <button className="p-2 rounded-full hover:bg-muted transition-colors">
                <Bell className="h-5 w-5 text-muted-foreground" />
              </button>
              
              {user.role === UserRole.ADMIN && (
                <Link 
                  href="/admin/dashboard"
                  className="p-2 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors"
                  onClick={showAdminInfo}
                >
                  <Shield className="h-5 w-5 text-primary" />
                </Link>
              )}
              
              <div className="relative">
                <button 
                  className="flex items-center space-x-2 p-1 rounded-full hover:bg-muted transition-colors"
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                >
                  <ProfileAvatar name={user.name} size="sm" />
                  <span className="text-sm font-medium">{user.name.split(' ')[0]}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </button>
                
                {isProfileOpen && (
                  <motion.div 
                    className="absolute right-0 mt-2 w-48 py-2 bg-white dark:bg-muted rounded-md shadow-lg border border-border"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="px-4 py-2 border-b border-border">
                      <p className="text-sm font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                    <Link 
                      href="/dashboard/profile" 
                      className="flex items-center px-4 py-2 text-sm hover:bg-muted/50 transition-colors"
                    >
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Link>
                    <Link 
                      href="/dashboard/settings" 
                      className="flex items-center px-4 py-2 text-sm hover:bg-muted/50 transition-colors"
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Settings
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="flex items-center px-4 py-2 text-sm text-danger hover:bg-danger/10 transition-colors w-full text-left"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </button>
                  </motion.div>
                )}
              </div>
            </div>
          )}

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              className="p-2 rounded-md hover:bg-muted transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <motion.div 
          className="md:hidden bg-white dark:bg-muted border-t border-border"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="px-4 py-3 space-y-1">
            {user ? (
              <>
                <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-md mb-2">
                  <ProfileAvatar name={user.name} size="sm" />
                  <div>
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                </div>
                
                <Link 
                  href="/dashboard" 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    pathname === "/dashboard" || pathname.startsWith("/dashboard/")
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  Dashboard
                </Link>
                <Link 
                  href="/dashboard/training" 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    pathname === "/dashboard/training" || pathname.startsWith("/dashboard/training/")
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  Training
                </Link>
                <Link 
                  href="/dashboard/leads" 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    pathname === "/dashboard/leads" || pathname.startsWith("/dashboard/leads/")
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  Leads
                </Link>
                <Link 
                  href="/dashboard/team" 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    pathname === "/dashboard/team" || pathname.startsWith("/dashboard/team/")
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  Team
                </Link>
                <Link 
                  href="/dashboard/referrals" 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    pathname === "/dashboard/referrals" || pathname.startsWith("/dashboard/referrals/")
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  Referrals
                </Link>
                
                <div className="pt-4 mt-4 border-t border-border">
                  <Link 
                    href="/dashboard/profile" 
                    className="block px-3 py-2 rounded-md text-base font-medium hover:bg-muted"
                  >
                    Profile
                  </Link>
                  <Link 
                    href="/dashboard/settings" 
                    className="block px-3 py-2 rounded-md text-base font-medium hover:bg-muted"
                  >
                    Settings
                  </Link>
                  
                  {user.role === UserRole.ADMIN && (
                    <Link 
                      href="/admin/dashboard" 
                      className="block px-3 py-2 rounded-md text-base font-medium text-primary hover:bg-primary/10"
                    >
                      Admin Dashboard
                    </Link>
                  )}
                  
                  <button 
                    onClick={handleLogout}
                    className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-danger hover:bg-danger/10 mt-2"
                  >
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link 
                  href="/auth/login" 
                  className="block px-3 py-2 rounded-md text-base font-medium hover:bg-muted"
                >
                  Login
                </Link>
                <Link 
                  href="/auth/register" 
                  className="block px-3 py-2 rounded-md text-base font-medium bg-primary text-white hover:bg-primary/90"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </motion.div>
      )}
    </header>
  );
}