"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { Home, BookOpen, Users, BarChart, User } from "lucide-react";

const MobileNavigation = () => {
  const pathname = usePathname();
  
  // Only show mobile navigation on dashboard pages
  if (!pathname?.includes("/dashboard")) {
    return null;
  }

  const navItems = [
    {
      name: "Home",
      href: "/dashboard",
      icon: <Home className="h-5 w-5" />,
      active: pathname === "/dashboard",
    },
    {
      name: "Training",
      href: "/dashboard/training",
      icon: <BookOpen className="h-5 w-5" />,
      active: pathname?.includes("/dashboard/training"),
    },
    {
      name: "Leads",
      href: "/dashboard/leads",
      icon: <BarChart className="h-5 w-5" />,
      active: pathname?.includes("/dashboard/leads"),
    },
    {
      name: "Team",
      href: "/dashboard/team",
      icon: <Users className="h-5 w-5" />,
      active: pathname?.includes("/dashboard/team"),
    },
    {
      name: "Profile",
      href: "/dashboard/profile",
      icon: <User className="h-5 w-5" />,
      active: pathname?.includes("/dashboard/profile"),
    },
  ];

  return (
    <motion.div 
      className="mobile-bottom-nav md:hidden"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className={`flex flex-col items-center justify-center ${
              item.active 
                ? "text-primary" 
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <div className="relative">
              {item.icon}
              {item.active && (
                <motion.div
                  layoutId="activeIndicator"
                  className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full"
                  transition={{ duration: 0.3 }}
                />
              )}
            </div>
            <span className="text-xs mt-1">{item.name}</span>
          </Link>
        ))}
      </div>
    </motion.div>
  );
};

export default MobileNavigation;