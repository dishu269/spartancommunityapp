"use client";

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Bell, CheckCircle, AlertCircle, Info } from "lucide-react";

export type NotificationType = "success" | "error" | "info" | "warning";

export interface NotificationProps {
  id: string;
  title: string;
  message: string;
  type?: NotificationType;
  duration?: number;
  onClose?: () => void;
}

const icons = {
  success: <CheckCircle className="h-5 w-5 text-success" />,
  error: <AlertCircle className="h-5 w-5 text-danger" />,
  warning: <AlertCircle className="h-5 w-5 text-warning" />,
  info: <Info className="h-5 w-5 text-primary" />,
};

const backgrounds = {
  success: "bg-success/10 border-success/20",
  error: "bg-danger/10 border-danger/20",
  warning: "bg-warning/10 border-warning/20",
  info: "bg-primary/10 border-primary/20",
};

export const Notification: React.FC<NotificationProps> = ({
  id,
  title,
  message,
  type = "info",
  duration = 5000,
  onClose,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleClose = () => {
    setIsVisible(false);
    if (onClose) {
      onClose();
    }
  };

  useEffect(() => {
    if (duration > 0) {
      timerRef.current = setTimeout(() => {
        handleClose();
      }, duration);
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [duration]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          key={id}
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className={`w-full max-w-sm rounded-lg border p-4 shadow-md ${backgrounds[type]}`}
          role="alert"
        >
          <div className="flex items-start">
            <div className="flex-shrink-0">{icons[type]}</div>
            <div className="ml-3 flex-1">
              <div className="text-sm font-medium">{title}</div>
              <div className="mt-1 text-sm text-muted-foreground">{message}</div>
            </div>
            <button
              onClick={handleClose}
              className="ml-4 inline-flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-md text-muted-foreground hover:text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <span className="sr-only">Close</span>
              <X className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export interface NotificationContainerProps {
  position?: "top-right" | "top-left" | "bottom-right" | "bottom-left";
  children: React.ReactNode;
}

const positionClasses = {
  "top-right": "top-0 right-0",
  "top-left": "top-0 left-0",
  "bottom-right": "bottom-0 right-0",
  "bottom-left": "bottom-0 left-0",
};

export const NotificationContainer: React.FC<NotificationContainerProps> = ({
  position = "top-right",
  children,
}) => {
  return (
    <div
      className={`fixed z-50 m-4 flex flex-col items-end space-y-2 ${positionClasses[position]}`}
    >
      {children}
    </div>
  );
};

// Notification context
interface NotificationContextType {
  showNotification: (props: Omit<NotificationProps, "id">) => string;
  closeNotification: (id: string) => void;
}

const NotificationContext = React.createContext<NotificationContextType | undefined>(undefined);

export const useNotification = () => {
  const context = React.useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotification must be used within a NotificationProvider");
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationProps[]>([]);

  const showNotification = (props: Omit<NotificationProps, "id">) => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications((prev) => [...prev, { id, ...props }]);
    return id;
  };

  const closeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id));
  };

  return (
    <NotificationContext.Provider value={{ showNotification, closeNotification }}>
      {children}
      <NotificationContainer>
        {notifications.map((notification) => (
          <Notification
            key={notification.id}
            {...notification}
            onClose={() => closeNotification(notification.id)}
          />
        ))}
      </NotificationContainer>
    </NotificationContext.Provider>
  );
};