const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    console.log('Connecting to database...');
    const adminUsers = await prisma.user.findMany({
      where: { role: 'ADMIN' }
    });
    console.log('Admin users:', JSON.stringify(adminUsers, null, 2));
  } catch (error) {
    console.error('Error connecting to database:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();