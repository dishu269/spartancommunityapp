const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
require('dotenv').config();

// Create Express app
const app = express();
const PORT = 3002;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Initialize PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

// Function to compare passwords
async function comparePasswords(plainPassword, hashedPassword) {
  try {
    return await bcrypt.compare(plainPassword, hashedPassword);
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

// Function to find user by email using direct PostgreSQL query
async function findUserByEmail(email) {
  try {
    console.log(`Finding user with email: ${email}`);
    const client = await pool.connect();
    
    try {
      // Use case-insensitive query
      const result = await client.query(
        'SELECT * FROM "User" WHERE LOWER(email) = LOWER($1)',
        [email]
      );
      
      if (result.rows.length === 0) {
        console.log("No user found in database");
        return null;
      }
      
      console.log("User found in database");
      return result.rows[0];
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Database error when finding user:", error);
    return null;
  }
}

// Function to generate JWT token
function generateToken(payload) {
  const JWT_SECRET = process.env.JWT_SECRET || "spartan_community_india_secret_key_change_in_production";
  const TOKEN_EXPIRATION = 60 * 60 * 24 * 7; // 7 days
  
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: TOKEN_EXPIRATION
  });
}

// Serve login page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login-test.html'));
});

// Login API endpoint
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    console.log(`Login attempt for email: ${email}`);
    
    // Find user by email
    const user = await findUserByEmail(email);
    
    if (!user) {
      console.log("User not found");
      return res.status(401).json({
        success: false,
        error: "Invalid credentials",
        message: "The email or password you entered is incorrect."
      });
    }
    
    // Verify password
    const passwordValid = await comparePasswords(password, user.password);
    
    if (!passwordValid) {
      console.log("Invalid password");
      return res.status(401).json({
        success: false,
        error: "Invalid credentials",
        message: "The email or password you entered is incorrect."
      });
    }
    
    console.log("Password verified successfully");
    
    // Create user object without password
    const userWithoutPassword = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    };
    
    // Generate JWT token
    const token = generateToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    });
    
    console.log("User authenticated, token generated");
    
    // Return user data and token
    return res.json({
      success: true,
      user: userWithoutPassword,
      token
    });
  } catch (error) {
    console.error("Login API error:", error);
    return res.status(500).json({
      success: false,
      error: "Internal server error",
      message: "An unexpected error occurred. Please try again later."
    });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Test admin login server running at http://localhost:${PORT}`);
});
