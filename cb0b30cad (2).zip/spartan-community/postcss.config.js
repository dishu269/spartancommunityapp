module.exports = {
  plugins: {
    'tailwindcss/plugin': {},
    autoprefixer: {},
  },
}
