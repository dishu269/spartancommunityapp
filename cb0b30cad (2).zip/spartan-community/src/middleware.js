import { NextResponse } from 'next/server';

export function middleware(request) {
  // Get the pathname of the request (e.g. /, /admin)
  const { pathname } = request.nextUrl;

  // For a production app, you would check for authentication here
  // using cookies or JWT tokens
  // For this demo, we'll allow access to admin routes directly
  
  // If the request is for any route, proceed normally
  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ['/admin/:path*'],
};
