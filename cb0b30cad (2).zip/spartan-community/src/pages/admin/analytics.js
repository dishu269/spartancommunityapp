import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/solid';

// Mock data for analytics
const mockAnalyticsData = {
  overview: {
    totalUsers: {
      value: 1897,
      change: 12.5,
      trend: 'up'
    },
    activeUsers: {
      value: 1245,
      change: 8.2,
      trend: 'up'
    },
    contentViews: {
      value: 15678,
      change: 23.7,
      trend: 'up'
    },
    averageSessionTime: {
      value: '4:32',
      change: -2.1,
      trend: 'down'
    }
  },
  userActivity: [
    { date: 'May 1', users: 120 },
    { date: 'May 2', users: 132 },
    { date: 'May 3', users: 145 },
    { date: 'May 4', users: 140 },
    { date: 'May 5', users: 158 },
    { date: 'May 6', users: 172 },
    { date: 'May 7', users: 168 },
    { date: 'May 8', users: 180 },
    { date: 'May 9', users: 190 },
    { date: 'May 10', users: 185 },
    { date: 'May 11', users: 195 },
    { date: 'May 12', users: 210 },
    { date: 'May 13', users: 215 },
    { date: 'May 14', users: 220 },
  ],
  contentPerformance: [
    { title: 'Introduction to Spartan Fitness', views: 1245, likes: 87, comments: 32 },
    { title: 'Yoga for Beginners', views: 856, likes: 42, comments: 18 },
    { title: 'High-Intensity Interval Training', views: 1532, likes: 124, comments: 45 },
    { title: 'Nutrition Tips for Athletes', views: 678, likes: 23, comments: 12 },
    { title: 'Strength Training Basics', views: 945, likes: 76, comments: 28 },
  ],
  userDemographics: {
    ageGroups: [
      { group: '18-24', percentage: 22 },
      { group: '25-34', percentage: 38 },
      { group: '35-44', percentage: 25 },
      { group: '45-54', percentage: 10 },
      { group: '55+', percentage: 5 },
    ],
    genderDistribution: [
      { gender: 'Male', percentage: 65 },
      { gender: 'Female', percentage: 33 },
      { gender: 'Other', percentage: 2 },
    ],
    topLocations: [
      { location: 'Delhi', users: 425 },
      { location: 'Mumbai', users: 380 },
      { location: 'Bangalore', users: 310 },
      { location: 'Chennai', users: 245 },
      { location: 'Hyderabad', users: 210 },
    ]
  }
};

export default function Analytics() {
  const [analyticsData, setAnalyticsData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30d');

  useEffect(() => {
    // Simulate API call to fetch analytics data
    const fetchData = async () => {
      setIsLoading(true);
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAnalyticsData(mockAnalyticsData);
      setIsLoading(false);
    };

    fetchData();
  }, [timeRange]);

  // Function to render trend indicator
  const renderTrendIndicator = (trend, change) => {
    const formattedChange = Math.abs(change).toFixed(1);
    if (trend === 'up') {
      return (
        <span className="inline-flex items-center text-green-600">
          <ArrowUpIcon className="h-4 w-4 mr-1" />
          {formattedChange}%
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center text-red-600">
          <ArrowDownIcon className="h-4 w-4 mr-1" />
          {formattedChange}%
        </span>
      );
    }
  };

  // Simple bar chart component
  const BarChart = ({ data, valueKey, labelKey, height = 200 }) => {
    const maxValue = Math.max(...data.map(item => item[valueKey]));
    
    return (
      <div className="mt-4">
        <div className="flex items-end space-x-2" style={{ height: `${height}px` }}>
          {data.map((item, index) => {
            const barHeight = (item[valueKey] / maxValue) * height;
            return (
              <div key={index} className="flex flex-col items-center flex-1">
                <div 
                  className="w-full bg-blue-500 rounded-t"
                  style={{ height: `${barHeight}px` }}
                ></div>
                <div className="text-xs mt-1 text-gray-600 truncate w-full text-center">
                  {item[labelKey]}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Analytics</h1>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="py-4">
            {/* Time range selector */}
            <div className="flex justify-end mb-4">
              <div className="inline-flex rounded-md shadow-sm">
                <button
                  type="button"
                  onClick={() => setTimeRange('7d')}
                  className={`relative inline-flex items-center rounded-l-md px-3 py-2 text-sm font-medium ${
                    timeRange === '7d'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-50'
                  } ring-1 ring-inset ring-gray-300 focus:z-10`}
                >
                  7 days
                </button>
                <button
                  type="button"
                  onClick={() => setTimeRange('30d')}
                  className={`relative -ml-px inline-flex items-center px-3 py-2 text-sm font-medium ${
                    timeRange === '30d'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-50'
                  } ring-1 ring-inset ring-gray-300 focus:z-10`}
                >
                  30 days
                </button>
                <button
                  type="button"
                  onClick={() => setTimeRange('90d')}
                  className={`relative -ml-px inline-flex items-center rounded-r-md px-3 py-2 text-sm font-medium ${
                    timeRange === '90d'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-50'
                  } ring-1 ring-inset ring-gray-300 focus:z-10`}
                >
                  90 days
                </button>
              </div>
            </div>

            {isLoading ? (
              <div className="py-10 text-center text-sm text-gray-500">
                Loading analytics data...
              </div>
            ) : (
              <>
                {/* Overview Cards */}
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-blue-500 rounded-md p-3">
                          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                        </div>
                        <div className="ml-5 w-0 flex-1">
                          <dl>
                            <dt className="text-sm font-medium text-gray-500 truncate">
                              Total Users
                            </dt>
                            <dd>
                              <div className="flex items-baseline">
                                <div className="text-2xl font-semibold text-gray-900">
                                  {analyticsData.overview.totalUsers.value.toLocaleString()}
                                </div>
                                <div className="ml-2 text-sm">
                                  {renderTrendIndicator(
                                    analyticsData.overview.totalUsers.trend,
                                    analyticsData.overview.totalUsers.change
                                  )}
                                </div>
                              </div>
                            </dd>
                          </dl>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <div className="ml-5 w-0 flex-1">
                          <dl>
                            <dt className="text-sm font-medium text-gray-500 truncate">
                              Active Users
                            </dt>
                            <dd>
                              <div className="flex items-baseline">
                                <div className="text-2xl font-semibold text-gray-900">
                                  {analyticsData.overview.activeUsers.value.toLocaleString()}
                                </div>
                                <div className="ml-2 text-sm">
                                  {renderTrendIndicator(
                                    analyticsData.overview.activeUsers.trend,
                                    analyticsData.overview.activeUsers.change
                                  )}
                                </div>
                              </div>
                            </dd>
                          </dl>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-purple-500 rounded-md p-3">
                          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                        </div>
                        <div className="ml-5 w-0 flex-1">
                          <dl>
                            <dt className="text-sm font-medium text-gray-500 truncate">
                              Content Views
                            </dt>
                            <dd>
                              <div className="flex items-baseline">
                                <div className="text-2xl font-semibold text-gray-900">
                                  {analyticsData.overview.contentViews.value.toLocaleString()}
                                </div>
                                <div className="ml-2 text-sm">
                                  {renderTrendIndicator(
                                    analyticsData.overview.contentViews.trend,
                                    analyticsData.overview.contentViews.change
                                  )}
                                </div>
                              </div>
                            </dd>
                          </dl>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <div className="ml-5 w-0 flex-1">
                          <dl>
                            <dt className="text-sm font-medium text-gray-500 truncate">
                              Avg. Session Time
                            </dt>
                            <dd>
                              <div className="flex items-baseline">
                                <div className="text-2xl font-semibold text-gray-900">
                                  {analyticsData.overview.averageSessionTime.value}
                                </div>
                                <div className="ml-2 text-sm">
                                  {renderTrendIndicator(
                                    analyticsData.overview.averageSessionTime.trend,
                                    analyticsData.overview.averageSessionTime.change
                                  )}
                                </div>
                              </div>
                            </dd>
                          </dl>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* User Activity Chart */}
                <div className="mt-8 bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">User Activity</h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Daily active users over the selected time period.
                      </p>
                    </div>
                    <BarChart 
                      data={analyticsData.userActivity.slice(-14)} 
                      valueKey="users" 
                      labelKey="date" 
                      height={200}
                    />
                  </div>
                </div>

                {/* Content Performance */}
                <div className="mt-8 bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Top Performing Content</h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Content with the highest engagement metrics.
                      </p>
                    </div>
                    <div className="mt-4 flow-root">
                      <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                          <table className="min-w-full divide-y divide-gray-300">
                            <thead>
                              <tr>
                                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0">
                                  Title
                                </th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                                  Views
                                </th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                                  Likes
                                </th>
                                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                                  Comments
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                              {analyticsData.contentPerformance.map((content, index) => (
                                <tr key={index}>
                                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-0">
                                    {content.title}
                                  </td>
                                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                    {content.views.toLocaleString()}
                                  </td>
                                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                    {content.likes.toLocaleString()}
                                  </td>
                                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                    {content.comments.toLocaleString()}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* User Demographics */}
                <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
                  {/* Age Distribution */}
                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Age Distribution</h3>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">
                          Breakdown of users by age group.
                        </p>
                      </div>
                      <BarChart 
                        data={analyticsData.userDemographics.ageGroups} 
                        valueKey="percentage" 
                        labelKey="group" 
                        height={150}
                      />
                    </div>
                  </div>

                  {/* Top Locations */}
                  <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="px-4 py-5 sm:p-6">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Top Locations</h3>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">
                          Cities with the most users.
                        </p>
                      </div>
                      <BarChart 
                        data={analyticsData.userDemographics.topLocations} 
                        valueKey="users" 
                        labelKey="location" 
                        height={150}
                      />
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
