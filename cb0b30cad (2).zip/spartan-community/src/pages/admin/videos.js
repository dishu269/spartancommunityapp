import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { PlusIcon, PencilIcon, TrashIcon, MagnifyingGlassIcon, PlayIcon } from '@heroicons/react/24/outline';

const initialVideos = [
  {
    id: 1,
    title: 'Introduction to Spartan Fitness',
    thumbnail: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Zml0bmVzc3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '5:24',
    author: 'Dishant',
    category: 'Fitness',
    status: 'Published',
    publishDate: '2023-02-15',
    views: 1245,
    likes: 87
  },
  {
    id: 2,
    title: 'Yoga for Beginners',
    thumbnail: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8eW9nYXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '12:30',
    author: 'Priya Patel',
    category: 'Yoga',
    status: 'Published',
    publishDate: '2023-03-10',
    views: 856,
    likes: 42
  },
  {
    id: 3,
    title: 'High-Intensity Interval Training',
    thumbnail: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8aGlpdHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '8:45',
    author: 'Rahul Sharma',
    category: 'Fitness',
    status: 'Published',
    publishDate: '2023-04-05',
    views: 1532,
    likes: 124
  },
  {
    id: 4,
    title: 'Nutrition Tips for Athletes',
    thumbnail: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fG51dHJpdGlvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '10:12',
    author: 'Neha Singh',
    category: 'Nutrition',
    status: 'Published',
    publishDate: '2023-03-22',
    views: 678,
    likes: 23
  },
  {
    id: 5,
    title: 'Meditation for Stress Relief',
    thumbnail: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bWVkaXRhdGlvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '15:00',
    author: 'Ananya Gupta',
    category: 'Wellness',
    status: 'Draft',
    publishDate: null,
    views: 0,
    likes: 0
  },
  {
    id: 6,
    title: 'Strength Training Basics',
    thumbnail: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8c3RyZW5ndGglMjB0cmFpbmluZ3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '7:50',
    author: 'Vikram Joshi',
    category: 'Fitness',
    status: 'Published',
    publishDate: '2023-01-30',
    views: 945,
    likes: 76
  },
  {
    id: 7,
    title: 'Healthy Cooking Demonstration',
    thumbnail: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y29va2luZ3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
    duration: '18:22',
    author: 'Meera Desai',
    category: 'Nutrition',
    status: 'Review',
    publishDate: null,
    views: 0,
    likes: 0
  },
  {
    id: 8,
    title: 'Cardio Workout for Beginners',
    thumbnail: 'https://images.unsplash.com/photo-1538805060514-97d9cc17730c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8Y2FyZGlvfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
    duration: '9:15',
    author: 'Rajesh Verma',
    category: 'Fitness',
    status: 'Published',
    publishDate: '2023-02-28',
    views: 1876,
    likes: 45
  }
];

export default function VideoManagement() {
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add', 'edit', 'delete', 'view'
  const [filterCategory, setFilterCategory] = useState('All');

  useEffect(() => {
    // Simulate loading data from API
    const timer = setTimeout(() => {
      setVideos(initialVideos);
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const filteredVideos = videos.filter(video => {
    const matchesSearch = 
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = filterCategory === 'All' || video.category === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  const videoCategories = ['All', 'Fitness', 'Yoga', 'Nutrition', 'Wellness'];

  const handleAddVideo = () => {
    setModalMode('add');
    setSelectedVideo(null);
    setIsModalOpen(true);
  };

  const handleEditVideo = (video) => {
    setModalMode('edit');
    setSelectedVideo(video);
    setIsModalOpen(true);
  };

  const handleViewVideo = (video) => {
    setModalMode('view');
    setSelectedVideo(video);
    setIsModalOpen(true);
  };

  const handleDeleteVideo = (video) => {
    setModalMode('delete');
    setSelectedVideo(video);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedVideo(null);
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'published':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Video Management</h1>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-4">
            <div className="sm:flex sm:items-center">
              <div className="sm:flex-auto">
                <p className="mt-2 text-sm text-gray-700">
                  Manage all videos on the Spartan Community India platform including fitness tutorials, yoga sessions, and nutrition guides.
                </p>
              </div>
              <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                <button
                  type="button"
                  onClick={handleAddVideo}
                  className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
                >
                  <PlusIcon className="-ml-1 mr-2 h-5 w-5" aria-hidden="true" />
                  Add Video
                </button>
              </div>
            </div>
            
            {/* Search and Filter */}
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="flex rounded-md shadow-sm">
                <div className="relative flex flex-grow items-stretch focus-within:z-10">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" aria-hidden="true" />
                  </div>
                  <input
                    type="text"
                    name="search"
                    id="search"
                    className="block w-full rounded-md border-gray-300 pl-10 focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    placeholder="Search videos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-700">Filter by category:</span>
                <div className="flex space-x-1">
                  {videoCategories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setFilterCategory(category)}
                      className={`rounded-md px-3 py-1.5 text-sm font-medium ${
                        filterCategory === category
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Videos Grid */}
            <div className="mt-8">
              {isLoading ? (
                <div className="py-10 text-center text-sm text-gray-500">
                  Loading videos...
                </div>
              ) : filteredVideos.length === 0 ? (
                <div className="py-10 text-center text-sm text-gray-500">
                  No videos found matching your search criteria.
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {filteredVideos.map((video) => (
                    <div key={video.id} className="overflow-hidden rounded-lg bg-white shadow">
                      <div className="relative">
                        <img
                          src={video.thumbnail}
                          alt={video.title}
                          className="h-48 w-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleViewVideo(video)}
                            className="rounded-full bg-white p-2 text-gray-900"
                          >
                            <PlayIcon className="h-8 w-8" aria-hidden="true" />
                          </button>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 px-2 py-1 rounded text-white text-xs">
                          {video.duration}
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between">
                          <h3 className="text-lg font-medium text-gray-900 truncate" title={video.title}>
                            {video.title}
                          </h3>
                          <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(video.status)}`}>
                            {video.status}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-gray-500">
                          {video.author} • {video.category}
                        </p>
                        {video.publishDate && (
                          <p className="mt-1 text-xs text-gray-500">
                            Published: {video.publishDate}
                          </p>
                        )}
                        <div className="mt-2 flex justify-between text-sm text-gray-500">
                          <span>{video.views} views</span>
                          <span>{video.likes} likes</span>
                        </div>
                        <div className="mt-4 flex justify-end space-x-2">
                          <button
                            onClick={() => handleEditVideo(video)}
                            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                          >
                            <PencilIcon className="mr-1 h-4 w-4" aria-hidden="true" />
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteVideo(video)}
                            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-medium text-red-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                          >
                            <TrashIcon className="mr-1 h-4 w-4" aria-hidden="true" />
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Add/Edit/Delete/View Video */}
      {isModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-screen items-end justify-center px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" onClick={handleCloseModal}></div>

            <span className="hidden sm:inline-block sm:h-screen sm:align-middle" aria-hidden="true">&#8203;</span>

            <div className="inline-block transform overflow-hidden rounded-lg bg-white text-left align-bottom shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:align-middle">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  {modalMode === 'delete' ? (
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">Delete Video</h3>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">
                          Are you sure you want to delete "{selectedVideo?.title}"? This action cannot be undone.
                        </p>
                      </div>
                    </div>
                  ) : modalMode === 'view' ? (
                    <div className="mt-3 w-full text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">{selectedVideo?.title}</h3>
                      <div className="mt-4">
                        <div className="relative">
                          <img
                            src={selectedVideo?.thumbnail}
                            alt={selectedVideo?.title}
                            className="w-full h-48 object-cover rounded"
                          />
                          <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 px-2 py-1 rounded text-white text-xs">
                            {selectedVideo?.duration}
                          </div>
                        </div>
                        
                        <div className="mt-4 mb-4">
                          <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(selectedVideo?.status)}`}>
                            {selectedVideo?.status}
                          </span>
                          <span className="ml-2 text-sm text-gray-500">{selectedVideo?.category}</span>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Author:</span> {selectedVideo?.author}
                          </p>
                          {selectedVideo?.publishDate && (
                            <p className="text-sm text-gray-500">
                              <span className="font-medium">Published:</span> {selectedVideo?.publishDate}
                            </p>
                          )}
                        </div>
                        
                        <div className="mb-4 flex space-x-4">
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Views:</span> {selectedVideo?.views}
                          </p>
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Likes:</span> {selectedVideo?.likes}
                          </p>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-gray-700">
                            This video provides valuable content for our community members. It covers important topics related to {selectedVideo?.category.toLowerCase()} and has been well-received by our audience.
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3 w-full text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">
                        {modalMode === 'add' ? 'Add New Video' : 'Edit Video'}
                      </h3>
                      <div className="mt-2">
                        <form className="space-y-4">
                          <div>
                            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                              Title
                            </label>
                            <input
                              type="text"
                              name="title"
                              id="title"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue={selectedVideo?.title || ''}
                            />
                          </div>
                          <div>
                            <label htmlFor="thumbnail" className="block text-sm font-medium text-gray-700">
                              Thumbnail URL
                            </label>
                            <input
                              type="text"
                              name="thumbnail"
                              id="thumbnail"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue={selectedVideo?.thumbnail || ''}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                                Category
                              </label>
                              <select
                                id="category"
                                name="category"
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                defaultValue={selectedVideo?.category || 'Fitness'}
                              >
                                <option>Fitness</option>
                                <option>Yoga</option>
                                <option>Nutrition</option>
                                <option>Wellness</option>
                              </select>
                            </div>
                            <div>
                              <label htmlFor="status" className="block text-sm font-medium text-gray-700">
                                Status
                              </label>
                              <select
                                id="status"
                                name="status"
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                defaultValue={selectedVideo?.status || 'Draft'}
                              >
                                <option>Draft</option>
                                <option>Review</option>
                                <option>Published</option>
                              </select>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label htmlFor="duration" className="block text-sm font-medium text-gray-700">
                                Duration (MM:SS)
                              </label>
                              <input
                                type="text"
                                name="duration"
                                id="duration"
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                defaultValue={selectedVideo?.duration || ''}
                                placeholder="e.g. 10:30"
                              />
                            </div>
                            <div>
                              <label htmlFor="author" className="block text-sm font-medium text-gray-700">
                                Author
                              </label>
                              <input
                                type="text"
                                name="author"
                                id="author"
                                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                                defaultValue={selectedVideo?.author || ''}
                              />
                            </div>
                          </div>
                          <div>
                            <label htmlFor="videoUrl" className="block text-sm font-medium text-gray-700">
                              Video URL
                            </label>
                            <input
                              type="text"
                              name="videoUrl"
                              id="videoUrl"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              placeholder="e.g. https://example.com/video.mp4"
                            />
                          </div>
                          <div>
                            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                              Description
                            </label>
                            <textarea
                              id="description"
                              name="description"
                              rows={3}
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue="This video provides valuable content for our community members."
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                {modalMode === 'delete' ? (
                  <>
                    <button
                      type="button"
                      className="inline-flex w-full justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Delete
                    </button>
                    <button
                      type="button"
                      className="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Cancel
                    </button>
                  </>
                ) : modalMode === 'view' ? (
                  <button
                    type="button"
                    className="inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto sm:text-sm"
                    onClick={handleCloseModal}
                  >
                    Close
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      className="inline-flex w-full justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      {modalMode === 'add' ? 'Add' : 'Save'}
                    </button>
                    <button
                      type="button"
                      className="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Cancel
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
