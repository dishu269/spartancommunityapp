import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { PlusIcon, PencilIcon, TrashIcon, MagnifyingGlassIcon, EyeIcon } from '@heroicons/react/24/outline';

const initialContent = [
  {
    id: 1,
    title: 'Welcome to Spartan Community India',
    type: 'Article',
    author: 'Dishant',
    status: 'Published',
    publishDate: '2023-01-10',
    views: 1245,
    likes: 87
  },
  {
    id: 2,
    title: 'Upcoming Events in Delhi',
    type: 'Event',
    author: 'Priya Patel',
    status: 'Published',
    publishDate: '2023-02-15',
    views: 856,
    likes: 42
  },
  {
    id: 3,
    title: 'Fitness Tips for Beginners',
    type: 'Article',
    author: 'Rahul Sharma',
    status: 'Published',
    publishDate: '2023-03-05',
    views: 1532,
    likes: 124
  },
  {
    id: 4,
    title: 'Community Guidelines',
    type: 'Page',
    author: 'Dishant',
    status: 'Published',
    publishDate: '2023-01-05',
    views: 678,
    likes: 23
  },
  {
    id: 5,
    title: 'Nutrition Workshop',
    type: 'Event',
    author: 'Neha Singh',
    status: 'Draft',
    publishDate: null,
    views: 0,
    likes: 0
  },
  {
    id: 6,
    title: 'Success Stories from Our Members',
    type: 'Article',
    author: 'Vikram Joshi',
    status: 'Published',
    publishDate: '2023-04-12',
    views: 945,
    likes: 76
  },
  {
    id: 7,
    title: 'Yoga for Mental Health',
    type: 'Article',
    author: 'Ananya Gupta',
    status: 'Review',
    publishDate: null,
    views: 0,
    likes: 0
  },
  {
    id: 8,
    title: 'About Spartan Community',
    type: 'Page',
    author: 'Dishant',
    status: 'Published',
    publishDate: '2023-01-02',
    views: 1876,
    likes: 45
  },
  {
    id: 9,
    title: 'Summer Fitness Challenge',
    type: 'Event',
    author: 'Rajesh Verma',
    status: 'Published',
    publishDate: '2023-05-01',
    views: 1245,
    likes: 98
  },
  {
    id: 10,
    title: 'Healthy Recipes for Athletes',
    type: 'Article',
    author: 'Meera Desai',
    status: 'Draft',
    publishDate: null,
    views: 0,
    likes: 0
  }
];

export default function ContentManagement() {
  const [content, setContent] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContent, setSelectedContent] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add', 'edit', 'delete', 'view'
  const [filterType, setFilterType] = useState('All');

  useEffect(() => {
    // Simulate loading data from API
    const timer = setTimeout(() => {
      setContent(initialContent);
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const filteredContent = content.filter(item => {
    const matchesSearch = 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === 'All' || item.type === filterType;
    
    return matchesSearch && matchesType;
  });

  const contentTypes = ['All', 'Article', 'Event', 'Page'];

  const handleAddContent = () => {
    setModalMode('add');
    setSelectedContent(null);
    setIsModalOpen(true);
  };

  const handleEditContent = (content) => {
    setModalMode('edit');
    setSelectedContent(content);
    setIsModalOpen(true);
  };

  const handleViewContent = (content) => {
    setModalMode('view');
    setSelectedContent(content);
    setIsModalOpen(true);
  };

  const handleDeleteContent = (content) => {
    setModalMode('delete');
    setSelectedContent(content);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedContent(null);
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'published':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Content Management</h1>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <div className="mt-4">
            <div className="sm:flex sm:items-center">
              <div className="sm:flex-auto">
                <p className="mt-2 text-sm text-gray-700">
                  Manage all content including articles, events, and pages on the Spartan Community India platform.
                </p>
              </div>
              <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                <button
                  type="button"
                  onClick={handleAddContent}
                  className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto"
                >
                  <PlusIcon className="-ml-1 mr-2 h-5 w-5" aria-hidden="true" />
                  Add Content
                </button>
              </div>
            </div>
            
            {/* Search and Filter */}
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="flex rounded-md shadow-sm">
                <div className="relative flex flex-grow items-stretch focus-within:z-10">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" aria-hidden="true" />
                  </div>
                  <input
                    type="text"
                    name="search"
                    id="search"
                    className="block w-full rounded-md border-gray-300 pl-10 focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    placeholder="Search content..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-700">Filter by type:</span>
                <div className="flex space-x-1">
                  {contentTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setFilterType(type)}
                      className={`rounded-md px-3 py-1.5 text-sm font-medium ${
                        filterType === type
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Content Table */}
            <div className="mt-8 flex flex-col">
              <div className="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div className="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
                  <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                            Title
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Type
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Author
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Status
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Published
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Views
                          </th>
                          <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                            Likes
                          </th>
                          <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                            <span className="sr-only">Actions</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 bg-white">
                        {isLoading ? (
                          <tr>
                            <td colSpan="8" className="py-10 text-center text-sm text-gray-500">
                              Loading content...
                            </td>
                          </tr>
                        ) : filteredContent.length === 0 ? (
                          <tr>
                            <td colSpan="8" className="py-10 text-center text-sm text-gray-500">
                              No content found matching your search criteria.
                            </td>
                          </tr>
                        ) : (
                          filteredContent.map((item) => (
                            <tr key={item.id}>
                              <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                {item.title}
                              </td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{item.type}</td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{item.author}</td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm">
                                <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(item.status)}`}>
                                  {item.status}
                                </span>
                              </td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                {item.publishDate || '-'}
                              </td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{item.views}</td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{item.likes}</td>
                              <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                                <button
                                  onClick={() => handleViewContent(item)}
                                  className="text-gray-600 hover:text-gray-900 mr-3"
                                >
                                  <EyeIcon className="h-5 w-5" aria-hidden="true" />
                                  <span className="sr-only">View {item.title}</span>
                                </button>
                                <button
                                  onClick={() => handleEditContent(item)}
                                  className="text-blue-600 hover:text-blue-900 mr-3"
                                >
                                  <PencilIcon className="h-5 w-5" aria-hidden="true" />
                                  <span className="sr-only">Edit {item.title}</span>
                                </button>
                                <button
                                  onClick={() => handleDeleteContent(item)}
                                  className="text-red-600 hover:text-red-900"
                                >
                                  <TrashIcon className="h-5 w-5" aria-hidden="true" />
                                  <span className="sr-only">Delete {item.title}</span>
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Add/Edit/Delete/View Content */}
      {isModalOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-screen items-end justify-center px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" onClick={handleCloseModal}></div>

            <span className="hidden sm:inline-block sm:h-screen sm:align-middle" aria-hidden="true">&#8203;</span>

            <div className="inline-block transform overflow-hidden rounded-lg bg-white text-left align-bottom shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:align-middle">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  {modalMode === 'delete' ? (
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">Delete Content</h3>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">
                          Are you sure you want to delete "{selectedContent?.title}"? This action cannot be undone.
                        </p>
                      </div>
                    </div>
                  ) : modalMode === 'view' ? (
                    <div className="mt-3 w-full text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">{selectedContent?.title}</h3>
                      <div className="mt-4">
                        <div className="mb-4">
                          <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(selectedContent?.status)}`}>
                            {selectedContent?.status}
                          </span>
                          <span className="ml-2 text-sm text-gray-500">{selectedContent?.type}</span>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Author:</span> {selectedContent?.author}
                          </p>
                          {selectedContent?.publishDate && (
                            <p className="text-sm text-gray-500">
                              <span className="font-medium">Published:</span> {selectedContent?.publishDate}
                            </p>
                          )}
                        </div>
                        
                        <div className="mb-4 flex space-x-4">
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Views:</span> {selectedContent?.views}
                          </p>
                          <p className="text-sm text-gray-500">
                            <span className="font-medium">Likes:</span> {selectedContent?.likes}
                          </p>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-gray-700">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3 w-full text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">
                        {modalMode === 'add' ? 'Add New Content' : 'Edit Content'}
                      </h3>
                      <div className="mt-2">
                        <form className="space-y-4">
                          <div>
                            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                              Title
                            </label>
                            <input
                              type="text"
                              name="title"
                              id="title"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue={selectedContent?.title || ''}
                            />
                          </div>
                          <div>
                            <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                              Type
                            </label>
                            <select
                              id="type"
                              name="type"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue={selectedContent?.type || 'Article'}
                            >
                              <option>Article</option>
                              <option>Event</option>
                              <option>Page</option>
                            </select>
                          </div>
                          <div>
                            <label htmlFor="status" className="block text-sm font-medium text-gray-700">
                              Status
                            </label>
                            <select
                              id="status"
                              name="status"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue={selectedContent?.status || 'Draft'}
                            >
                              <option>Draft</option>
                              <option>Review</option>
                              <option>Published</option>
                            </select>
                          </div>
                          <div>
                            <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                              Content
                            </label>
                            <textarea
                              id="content"
                              name="content"
                              rows={4}
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                              defaultValue="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                            />
                          </div>
                        </form>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                {modalMode === 'delete' ? (
                  <>
                    <button
                      type="button"
                      className="inline-flex w-full justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Delete
                    </button>
                    <button
                      type="button"
                      className="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Cancel
                    </button>
                  </>
                ) : modalMode === 'view' ? (
                  <button
                    type="button"
                    className="inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:w-auto sm:text-sm"
                    onClick={handleCloseModal}
                  >
                    Close
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      className="inline-flex w-full justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      {modalMode === 'add' ? 'Add' : 'Save'}
                    </button>
                    <button
                      type="button"
                      className="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                      onClick={handleCloseModal}
                    >
                      Cancel
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
