import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { 
  UsersIcon, 
  DocumentDuplicateIcon, 
  FilmIcon, 
  ChartPieIcon,
  BellIcon,
  CalendarIcon,
  ShieldCheckIcon,
  Cog6ToothIcon
} from '@heroicons/react/24/outline';
import Link from 'next/link';

const stats = [
  { id: 1, name: 'Total Users', stat: '1,897', icon: UsersIcon, href: '/admin/users', color: 'bg-blue-500' },
  { id: 2, name: 'Content Items', stat: '452', icon: DocumentDuplicateIcon, href: '/admin/content', color: 'bg-green-500' },
  { id: 3, name: 'Videos', stat: '86', icon: FilmIcon, href: '/admin/videos', color: 'bg-purple-500' },
  { id: 4, name: 'Events', stat: '12', icon: CalendarIcon, href: '/admin/events', color: 'bg-yellow-500' },
];

const recentActivity = [
  { id: 1, user: 'Rahul Sharma', action: 'created a new post', time: '2 hours ago' },
  { id: 2, user: 'Priya Patel', action: 'uploaded a new video', time: '5 hours ago' },
  { id: 3, user: 'Amit Kumar', action: 'registered as a new user', time: '1 day ago' },
  { id: 4, user: 'Neha Singh', action: 'commented on a post', time: '2 days ago' },
  { id: 5, user: 'Vikram Joshi', action: 'updated their profile', time: '3 days ago' },
];

export default function AdminDashboard() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Admin Dashboard</h1>
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8">
          {/* Stats */}
          <div className="mt-8">
            <h2 className="text-lg font-medium leading-6 text-gray-900">Overview</h2>
            <div className="mt-2 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((item) => (
                <Link key={item.id} href={item.href}>
                  <div className="overflow-hidden rounded-lg bg-white shadow transition-all hover:shadow-md">
                    <div className="p-5">
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 rounded-md p-3 ${item.color}`}>
                          <item.icon className="h-6 w-6 text-white" aria-hidden="true" />
                        </div>
                        <div className="ml-5 w-0 flex-1">
                          <dl>
                            <dt className="truncate text-sm font-medium text-gray-500">{item.name}</dt>
                            <dd>
                              <div className="text-lg font-medium text-gray-900">{item.stat}</div>
                            </dd>
                          </dl>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Quick Access */}
          <div className="mt-8">
            <h2 className="text-lg font-medium leading-6 text-gray-900">Quick Access</h2>
            <div className="mt-2 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              <Link href="/admin/analytics">
                <div className="overflow-hidden rounded-lg bg-white shadow transition-all hover:shadow-md">
                  <div className="p-5">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 rounded-md p-3 bg-indigo-500">
                        <ChartPieIcon className="h-6 w-6 text-white" aria-hidden="true" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="truncate text-sm font-medium text-gray-900">Analytics</dt>
                          <dd>
                            <div className="text-sm text-gray-500">View site statistics</div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
              
              <Link href="/admin/notifications">
                <div className="overflow-hidden rounded-lg bg-white shadow transition-all hover:shadow-md">
                  <div className="p-5">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 rounded-md p-3 bg-red-500">
                        <BellIcon className="h-6 w-6 text-white" aria-hidden="true" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="truncate text-sm font-medium text-gray-900">Notifications</dt>
                          <dd>
                            <div className="text-sm text-gray-500">Manage user notifications</div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
              
              <Link href="/admin/compliance">
                <div className="overflow-hidden rounded-lg bg-white shadow transition-all hover:shadow-md">
                  <div className="p-5">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 rounded-md p-3 bg-teal-500">
                        <ShieldCheckIcon className="h-6 w-6 text-white" aria-hidden="true" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="truncate text-sm font-medium text-gray-900">Compliance</dt>
                          <dd>
                            <div className="text-sm text-gray-500">Review compliance reports</div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
              
              <Link href="/admin/settings">
                <div className="overflow-hidden rounded-lg bg-white shadow transition-all hover:shadow-md">
                  <div className="p-5">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 rounded-md p-3 bg-gray-500">
                        <Cog6ToothIcon className="h-6 w-6 text-white" aria-hidden="true" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="truncate text-sm font-medium text-gray-900">Settings</dt>
                          <dd>
                            <div className="text-sm text-gray-500">Configure system settings</div>
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="mt-8">
            <h2 className="text-lg font-medium leading-6 text-gray-900">Recent Activity</h2>
            <div className="mt-2 overflow-hidden rounded-lg bg-white shadow">
              <ul role="list" className="divide-y divide-gray-200">
                {recentActivity.map((activity) => (
                  <li key={activity.id} className="px-6 py-4">
                    <div className="flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                          <span className="text-xs font-medium text-gray-700">
                            {activity.user.charAt(0)}
                          </span>
                        </div>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-gray-900">
                          {activity.user}
                        </p>
                        <p className="truncate text-sm text-gray-500">
                          {activity.action}
                        </p>
                      </div>
                      <div className="flex-shrink-0 whitespace-nowrap text-sm text-gray-500">
                        {activity.time}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="bg-gray-50 px-6 py-3">
                <div className="text-sm">
                  <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                    View all activity
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
